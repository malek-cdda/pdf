export const AUTH_LOGIN = '/auth/login';
export const LOGOUT = '/user/auth/logout';
export const GET_NEW_ACCESS_TOKEN = '/user/auth';
export const ACCESS_TOKEN_VALIDATION = '/auth/token/verify';

// MLS
export const USERS = '/users';
export const MLS_BUYER = '/users';
export const MLS_AGENT = '/agents';

// ROLE
export const ROLES = '/roles';
export const ROLE = '/role';
export const PERMISSION = '/permissions';

// SUBSCRIPTION
export const SUBSCRIPTION = '/subscriptions';

// ADMIN
// MLS

// Navigation
export const NAVIGATION = '/navigation';
