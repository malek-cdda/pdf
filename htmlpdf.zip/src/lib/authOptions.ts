import { AuthOptions } from 'next-auth';
import CredentialsProvider from 'next-auth/providers/credentials';
import { verifyCaptcha } from './verifyCaptcha';

interface Credentials {
  email: string;
  password: string;
  token: string;
}

export const authOptions: AuthOptions = {
  pages: {
    signIn: '/auth/sign-in'
  },
  providers: [
    CredentialsProvider({
      name: 'Credentials',
      credentials: {
        email: {},
        password: {}
      },
      // @ts-expect-error
      async authorize(credentials: Credentials) {
        const user = {
          first_name: 'John',
          last_name: 'Doe',
          email: 'maruf@cdda.io',
          username: 'maruf',
          password: '123456',
          refreshToken: 'loremipsumdolorsitametconsecteturadipiscingelit',
          accessToken: 'loremipsumdolorsitametconsecteturadipiscingelit3141592653'
        };

        // const { success, error }: any = verifyCaptcha(credentials.token);
        const { success, error } = await verifyCaptcha(credentials.token);

        if (!success) {
          throw new Error(error);
        } else {
          if (user.email === credentials.email && user.password === credentials.password) {
            return user;
          } else {
            throw new Error('Invalid credentials');
          }
        }
      }
    })
  ],

  secret: process.env.NEXTAUTH_SECRET as string,
  session: {
    // @ts-expect-error
    jwt: true,
    maxAge: 60 * 60 * 24 * 30 // 30 days
  },

  callbacks: {
    async jwt({ token, user }: any) {
      return { ...token, ...user };
    },
    async session({ session, token }: any) {
      session.user = token as any;

      return session;
    }
  }
};
