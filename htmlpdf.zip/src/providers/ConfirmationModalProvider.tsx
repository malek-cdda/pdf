'use client';

import React, { ReactNode } from 'react';
import useConfirmationModal from '@/hooks/useConfirmationModal';
import ConfirmationModalContext from './ConfirmationModalContext';

interface ConfirmationModalProviderProps {
  children: ReactNode;
}

const ConfirmationModalProvider: React.FC<ConfirmationModalProviderProps> = ({
  children
}: ConfirmationModalProviderProps) => {
  const confirmationModal: any = useConfirmationModal();

  return (
    <ConfirmationModalContext.Provider value={confirmationModal}>
      {children}
    </ConfirmationModalContext.Provider>
  );
};

export default ConfirmationModalProvider;
