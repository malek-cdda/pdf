'use client';

import useIdleTimeout from '@/hooks/useIdleTimeout';
import React from 'react';

const LockProvider = ({ children }: { children: React.ReactNode }) => {
  const idleTimeoutMillis = 30 * 60 * 1000; // 30 minutes
  const redirectUrl = '/lock';
  useIdleTimeout(idleTimeoutMillis, redirectUrl);
  return <>{children}</>;
};

export default LockProvider;
