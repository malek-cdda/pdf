import dynamic from 'next/dynamic';
import React, { Suspense } from 'react';
const LockProvider = dynamic(() => import('./LockProvider'));
// import LockProvider from './LockProvider';
const CSFThemeProvider = dynamic(() => import('@/theme/CSFThemeProvider'));
// import CSFThemeProvider from '@/theme/CSFThemeProvider';
import InitLoader from '@/components/common/Loader/Loader';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/authOptions';
// import SessionProvider from '@/providers/SessionProvider';
import ConfirmationModalProvider from './ConfirmationModalProvider';
import { StoreProvider } from '@/redux/StoreProvider';

const Providers = async ({ children }: { children: React.ReactNode }) => {
  const session = await getServerSession(authOptions);
  return (
    <Suspense fallback={<InitLoader />}>
      <CSFThemeProvider>
        <StoreProvider>
          <LockProvider>
            {/* <SessionProvider session={session}> */}
            <ConfirmationModalProvider>{children}</ConfirmationModalProvider>
            {/* </SessionProvider> */}
          </LockProvider>
        </StoreProvider>
      </CSFThemeProvider>
    </Suspense>
  );
};

export default Providers;
