export const permissionForm = [
  {
    id: 'type',
    name: 'type',
    type: 'select',
    placeholder: 'Select Type',
    label: 'Select Type',
    variant: 'outlined', // outlined, filled, standard
    options: [
      {
        value: 'API',
        label: 'API'
      },
      {
        value: 'PAGE',
        label: 'PAGE'
      },
      {
        value: 'COMPONENT',
        label: 'COMPONENT'
      }
    ],
    multiple: false, // if true, multiple options can be selected, if false, only one option can be selected
    defaultValue: '',
    validations: [
      {
        type: 'required',
        value: true,
        message: 'Type is required'
      }
    ]
  },
  {
    id: 'componentname',
    name: 'Component Name',
    type: 'text',
    placeholder: 'Enter label',
    label: 'Component Name',
    variant: 'outlined', // outlined, filled, standard
    defaultValue: '',
    validations: [
      {
        type: 'required',
        value: true,
        message: 'Email is required'
      }
    ]
  },
  {
    id: 'apiroute',
    name: 'api_route',
    type: 'select',
    placeholder: 'Select API Route',
    label: 'Select API Route',
    variant: 'outlined', // outlined, filled, standard
    options: [
      {
        value: 'option1',
        label: 'Option 1'
      },
      {
        value: 'option2',
        label: 'Option 2'
      },
      {
        value: 'Option 3',
        label: 'Option 3'
      }
    ],
    multiple: false, // if true, multiple options can be selected, if false, only one option can be selected
    defaultValue: '',
    validations: [
      {
        type: 'required',
        value: true,
        message: 'Type is required'
      }
    ]
  },
  {
    id: 'permission-method-list',
    name: 'permission_method_list',
    type: 'select',
    placeholder: 'Select Permission Method',
    label: 'Select Permissioin Method',
    variant: 'outlined', // outlined, filled, standard
    options: [
      {
        value: 'option1',
        label: 'Option 1'
      },
      {
        value: 'option2',
        label: 'Option 2'
      },
      {
        value: 'Option 3',
        label: 'Option 3'
      }
    ],
    multiple: true, // if true, multiple options can be selected, if false, only one option can be selected
    defaultValue: ['option1'],
    validations: [
      {
        type: 'min',
        value: 1,
        message: 'Select at least one option'
      }
    ]
  },
  {
    id: 'Description',
    name: 'description',
    type: 'text',
    placeholder: 'Enter description',
    label: 'Description',
    variant: 'outlined', // outlined, filled, standard
    defaultValue: '',
    validations: []
  }
];
