import { NextRequest, NextResponse } from 'next/server';
import { refreshAccessToken } from './utils/refreshAccessToken';
import { checkValidAccessToken } from './utils/checkValidAccessToken';

// Remove access and refresh cookies
function removeCookie(req: NextRequest) {
  const response = NextResponse.next();
  response.cookies.delete('access');
  response.cookies.delete('refresh');
  return response;
}

export default async function middleware(req: NextRequest) {
  // Get access and refresh tokens from cookies
  const accessToken = req.cookies.get('access')?.value;
  const refreshToken = req.cookies.get('refresh')?.value;
  const { valid } = (await checkValidAccessToken(accessToken)) || {};

  const isAuthenticated = !!valid;

  // define protected paths
  const protectedPaths = [
    '/',
    '/user/mls-group',
    '/user/agent',
    '/buyer',
    '/agreement',
    '/invoice',
    '/tax',
    '/role',
    '/permission',
    '/navigation',
    '/user',
    '/template/agreement',
    '/template/email',
    '/template/sms',
    '/template/invoice',
    '/template/editor',
    '/subscriptions',
    '/playground',
    '/available-page'
  ];

  // Check if user is authenticated and trying to access a public path
  if (req.nextUrl.pathname.includes('/sign-in') && isAuthenticated) {
    return NextResponse.redirect(new URL('/', req.url));
  } else {
    // Check if user is authenticated and trying to access a protected path
    if (!isAuthenticated && refreshToken) {
      const { success, accessToken: newAccessToken }: any = await refreshAccessToken(refreshToken);
      if (success) {
        const response = NextResponse.next();
        response.cookies.set('access', newAccessToken);
        return response;
      } else {
        return removeCookie(req);
      }
    } else {
      const { valid } = (await checkValidAccessToken(accessToken)) || {};

      if (!valid) {
        const { success, accessToken: newAccessToken }: any =
          await refreshAccessToken(refreshToken);
        if (success) {
          const response = NextResponse.next();
          response.cookies.set('access', newAccessToken);
          return response;
        }
      }
    }
    // Check if user is authenticated and trying to access a protected path
    if (!isAuthenticated && protectedPaths.includes(req.nextUrl.pathname)) {
      return NextResponse.redirect(
        new URL(`/auth/sign-in?callbackUrl=${encodeURIComponent(req.nextUrl.pathname)}`, req.url)
      );
    }
  }
}

// See "Matching Paths" below to learn more
export const config = {
  matcher: '/((?!api|static|.*\\..*|_next).*)'
};
