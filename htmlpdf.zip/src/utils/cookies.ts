// Type declaration for the Document object
interface DocumentCookie {
  cookie: string;
}

interface Document extends DocumentCookie {
  // Other Document properties and methods
}

declare var document: Document;

export const getCookie = (name: string): string | undefined => {
  const value = `; ${document.cookie}`;
  const parts = value.split(`; ${name}=`);
  if (parts.length === 2) return parts.pop()?.split(';').shift();
};

interface CookieOptions {
  path?: string;
  expires?: Date | string;
  [key: string]: any;
}

export const setCookie = (name: string, value: string, options: CookieOptions = {}) => {
  options = { path: '/', ...options };
  if (options.expires instanceof Date) {
    options.expires = options.expires.toUTCString();
  }
  let updatedCookie = `${name}=${value}`;
  for (let optionKey in options) {
    updatedCookie += `; ${optionKey}=${options[optionKey]}`;
  }
  document.cookie = updatedCookie;
};

export const deleteCookie = (name: string) => {
  setCookie(name, '', { expires: new Date(0) });
};
