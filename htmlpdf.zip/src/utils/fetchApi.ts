import { parseArrayToObject } from './parseArrayToObj';

export const handleApiCall = async (requestData: any) => {
//   'use server';
  const { method, url, headers, params, body } = requestData;

  try {
    let response;

    const parsedHeaders = parseArrayToObject(headers);
    const parsedParams = parseArrayToObject(params);

    let requestUrl = url;
    if (method.toLowerCase() === 'get') {
      const queryString = new URLSearchParams(parsedParams).toString();
      if (queryString) {
        requestUrl += `?${queryString}`;
      }
    }

    const fetchOptions = {
      method: method.toUpperCase(),
      headers: parsedHeaders,
      body: method.toLowerCase() !== 'get' ? JSON.stringify(body) : undefined
    };

    response = await fetch(requestUrl, fetchOptions);

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    } else {
      const data = await response.json();
      return data; // Return response data
    }
  } catch (error) {
    throw error;
  }
};
