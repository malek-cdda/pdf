export const parseArrayToObject = (array: any) => {
  if (!array || !Array.isArray(array)) return {};
  return array.reduce((acc, curr) => {
    const [key, value] = Object.entries(curr)[0];
    acc[key] = value;
    return acc;
  }, {});
};
