//@ toukir

function generateUniqueId() {
  // Get the current timestamp
  const timestamp = new Date().getTime();

  // Generate a random number between 0 and 9999
  const randomNumber = Math.floor(Math.random() * 10000);

  // Combine the timestamp and random number to create the unique ID
  const uniqueId = `${timestamp}${randomNumber}`;

  return uniqueId;
}

export default generateUniqueId;
