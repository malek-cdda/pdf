interface TokenValidationResult {
  valid: boolean;
  error?: string;
}

export async function checkValidAccessToken(
  accessToken: string | undefined
): Promise<TokenValidationResult> {
  if (!accessToken) {
    return { valid: false, error: 'No access token provided' };
  }
  try {
    const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/auth/token/verify`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${accessToken}`
      }
    });

    if (!response.ok) {
      const error = await response.json();
      return { valid: false, error: error.message };
    }

    // If the response is okay, the access token is valid
    return { valid: true };
  } catch (error) {
    return { valid: false, error: 'Error validating access token' };
  }
}
