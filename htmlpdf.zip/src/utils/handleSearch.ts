export const handleSearch = ({
  data,
  searchFieldNameItem,
  search
}: {
  data: any[];
  searchFieldNameItem: string[];
  search: string;
}) => {
  return [...data].filter((rowItem) => {
    return searchFieldNameItem?.some((fieldName: string) => {
      const fieldValue = rowItem?.[fieldName];
      if (typeof fieldValue === 'string') {
        return fieldValue.toLowerCase().includes(search?.toLowerCase());
      }
      return false;
    });
  });
};
