import { Box, Typography } from '@mui/material';
import React from 'react';

const HeaderTitle = ({ title = 'Title', description }: { title: string; description: string }) => {
  return (
    <Box>
      <Typography variant="h4">{title}</Typography>
      <Typography
        variant="body1"
        sx={{
          color: 'text.secondary',
          fontSize: '0.9rem'
        }}
      >
        {description}
      </Typography>
    </Box>
  );
};

export default HeaderTitle;
