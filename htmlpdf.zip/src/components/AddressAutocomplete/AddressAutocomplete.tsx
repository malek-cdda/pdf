import { Autocomplete, FormHelperText, Stack, TextField } from '@mui/material';
import React, { memo, useEffect } from 'react';
import AddressDetails from './AddressDetails';

const AddressAutocomplete = ({ formik, setAddressData, isDetails }: any) => {
  const [query, setQuery] = React.useState(formik.values?.address?.full_address || '');
  const [places, setPlaces] = React.useState([]);
  const [placeId, setPlaceId] = React.useState(null);
  const [address, setAddress] = React.useState(null as any);

  useEffect(() => {
    if (address) {
      formik.setValues({
        ...formik.values,
        address: {
          street: address?.street_name,
          city: address?.city,
          state: address?.state,
          zip_code: address?.postalcode,
          country: address?.country,
          full_address: address?.formatted_address,
          latitude: address?.lat,
          longitude: address?.lng
        }
      });
    }
  }, [address, setAddressData]);

  // Get address from place id
  const getAddress = async (placeId: any) => {
    try {
      const res = await fetch(
        `${process.env.NEXT_PUBLIC_API_URL}/address/autocomplete?location=${placeId.id}`
      );
      const data = await res.json();
      setAddress(data);
    } catch (err) {
      console.error(err);
    }
  };

  // Get address when place id changes
  useEffect(() => {
    if (placeId) {
      getAddress(placeId);
    } else {
      setAddress(null);
    }
  }, [placeId]);

  // Get place id from google maps api
  const getPlaceId = async () => {
    try {
      const res = await fetch(
        `${process.env.NEXT_PUBLIC_API_URL}/address/autocomplete?keyword=${query}`
      );
      const data = await res.json();

      setPlaces(data);
    } catch (err) {
      console.error(err);
    }
  };

  // Get place id when query length is greater than 3
  useEffect(() => {
    if (query.length > 3) {
      getPlaceId();
    } else {
      setPlaces([]);
    }
  }, [query]); // eslint-disable-line

  return (
    <>
      <Autocomplete
        disablePortal
        id="combo-box-demo"
        options={places}
        getOptionLabel={(option: { description: string; place_id: string }) => option?.description}
        // @ts-ignore
        defaultValue={
          places.find((place: any) => place.place_id === placeId) || {
            description: formik.values?.address?.full_address || ''
          }
        }
        onChange={(event, newValue: any) => {
          setPlaceId(newValue);
          formik.setFieldValue('address.full_address', newValue?.description);
          // formik.setValues('address.full_address', newValue?.description);
        }}
        renderInput={(params) => (
          <>
            <TextField
              {...params}
              label="Address"
              fullWidth
              value={query}
              onChange={(e) => {
                setQuery(e.target.value);
              }}
              error={
                formik.touched.address?.full_address && Boolean(formik.errors.address?.full_address)
              }
            />
            <FormHelperText
              sx={{
                color: 'red'
              }}
            >
              {formik.touched.address?.full_address && formik.errors.address?.full_address}
            </FormHelperText>
          </>
        )}
      />
      {isDetails && <AddressDetails formik={formik} />}
    </>
  );
};

export default memo(AddressAutocomplete);
