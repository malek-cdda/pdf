import { Checkbox, FormControlLabel } from '@mui/material';
import React from 'react';

const CustomCheckbox = ({
  formik,
  name,
  id,
  label
}: {
  formik: any;
  name: string;
  id: string;
  label: string;
}) => {
  return (
    <div>
      <FormControlLabel
        control={
          <Checkbox
            id={id}
            name={name}
            color="primary"
            checked={formik.values?.[name]}
            onChange={formik.handleChange}
          />
        }
        label={label}
      />
      {formik.touched?.[name] && formik.errors?.[name] ? (
        <div style={{ color: 'red' }}>{formik.errors?.[name]}</div>
      ) : null}
    </div>
  );
};

export default CustomCheckbox;
