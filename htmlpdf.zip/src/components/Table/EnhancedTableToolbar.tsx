import * as React from 'react';
import Box from '@mui/material/Box';
import TextField from '@mui/material/TextField';
import SearchIcon from '@mui/icons-material/Search';
import InputAdornment from '@mui/material/InputAdornment';
import { Button, Fab, Grid, SelectChangeEvent } from '@mui/material';
import { FaPlus } from 'react-icons/fa';
import { CiGrid41 } from 'react-icons/ci';
import { BsList } from 'react-icons/bs';
import DropDownMenu from './components/DropDownMenu';
import { formatDate } from '@/utils/dateEsFormatter';

import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { DateRangePicker } from '@mui/x-date-pickers-pro/DateRangePicker';
import { SingleInputDateRangeField } from '@mui/x-date-pickers-pro/SingleInputDateRangeField';
import { DemoContainer } from '@mui/x-date-pickers/internals/demo';

export default function PrimarySearchAppBar({
  handleOpen = () => {},
  sortingDateRange,
  searchBar,
  dateRange,
  filterName,
  gridView,
  selected,
  searchWithUniqueField,
  handleBulkControl = () => {}
}: {
  handleOpen?: any;
  sortingDateRange: any;
  searchBar: any;
  dateRange: any;
  filterName: any;
  gridView: any;
  selected: any;
  searchWithUniqueField: any;
  handleBulkControl: any;
}) {
  const [bulkValue, setBulkValue] = React.useState('');
  const handleChange = (event: SelectChangeEvent) => {
    console.log(event.target.value);
    setBulkValue(event.target.value);
  };
  let optionItem = ['delete', 'update', 'james bond'];
  return (
    <Grid
      container
      spacing={2}
      padding="16px 18px 12px"
      sx={{
        backgroundColor: (theme) => (theme.palette.mode === 'light' ? 'bg.light' : 'bg.dark')
      }}
    >
      <Grid container spacing={8} xs={4}>
        {filterName && (
          <Box
            display="flex"
            gap="10px"
            // flexBasis="4"
            // sx={{
            //   width: '50%'
            // }}
          >
            <DropDownMenu optionItem={optionItem} value={bulkValue} handleChange={handleChange} />
            <Button variant="contained" onClick={() => handleBulkControl(bulkValue)}>
              Apply
            </Button>
          </Box>
        )}
        {/* {selected.length > 0 && <Button>delete</Button>} */}
      </Grid>
      <Grid container spacing={8} xs={8}>
        <Box marginLeft={1} display="flex" justifyContent="end" gap="8px">
          {searchBar && (
            <TextField
              variant="outlined"
              placeholder="Search"
              sx={{
                width: '40%',
                color: (theme: any) =>
                  theme.palette.mode === 'light'
                    ? theme?.palette?.title?.main
                    : theme?.palette?.title.light,
                '& .MuiOutlinedInput-root': {
                  '&.Mui-focused fieldset': {
                    borderColor: '#aeabb8'
                  }
                }
              }}
              inputProps={{
                style: {
                  padding: '8px 0' // Adjust padding as needed
                }
              }}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <SearchIcon />
                  </InputAdornment>
                )
              }}
              onChange={(e) => searchWithUniqueField(e.target.value)}
            />
          )}
          {/* time range */}

          {dateRange && (
            <LocalizationProvider dateAdapter={AdapterDayjs}>
              <DemoContainer
                components={['SingleInputDateRangeField']}
                sx={{
                  margin: '0px',
                  padding: '0px',
                  // height: 'calc(40px + 2 * 2px)', // Height adjusted to include border width
                  boxSizing: 'border-box', // Adjusted height here
                  // overflow: 'hidden', // Removed overflow hidden
                  color: (theme: any) =>
                    theme.palette.mode === 'light'
                      ? theme?.palette?.title?.main
                      : theme?.palette?.title.light,
                  '& .MuiOutlinedInput-root': {
                    '&.Mui-focused fieldset': {
                      borderColor: '#aeabb8'
                    }
                  }
                }}
              >
                <DateRangePicker
                  slots={{ field: SingleInputDateRangeField }}
                  name="allowedRange"
                  sx={{
                    height: '40px',
                    padding: '0px',
                    '& .MuiInputBase-input': {
                      padding: '8px 15px'
                    }
                  }}
                  onChange={(e: any) => {
                    e[1]?.$d && sortingDateRange(formatDate(e[0]?.$d), formatDate(e[1]?.$d));
                  }}
                />
              </DemoContainer>
            </LocalizationProvider>
          )}
          {/* list view icon  */}
          {gridView && (
            <Box display="flex" gap="10px">
              <Fab
                size="small"
                sx={{
                  borderRadius: '10%',
                  cursor: 'pointer',
                  backgroundColor: '#7c808538',
                  '&:hover': {
                    backgroundColor: '#7c80858e'
                  }
                }}
              >
                <BsList fontSize={16} />
              </Fab>
              {/* grid view item  */}
              <Fab
                size="small"
                sx={{
                  borderRadius: '10%',
                  cursor: 'pointer',
                  backgroundColor: '#7c808538',
                  '&:hover': {
                    backgroundColor: '#7c80858e'
                  }
                }}
              >
                <CiGrid41 fontSize={16} />
              </Fab>
              {/* add icon  */}
              <Fab
                size="small"
                sx={{
                  borderRadius: '10%',
                  cursor: 'pointer',
                  backgroundColor: '#7c808538',
                  '&:hover': {
                    backgroundColor: '#7c80858e'
                  }
                }}
                onClick={() => handleOpen()}
              >
                <FaPlus fontSize={16} />
              </Fab>
            </Box>
          )}
        </Box>
      </Grid>
    </Grid>
  );
}
