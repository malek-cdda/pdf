import * as React from 'react';
import Box from '@mui/material/Box';
import {
  alpha,
  FormControl,
  NativeSelect,
  Stack,
  TablePagination,
  Table as TableWrapper,
  Typography
} from '@mui/material';
import TableContainer from '@mui/material/TableContainer';
import Paper from '@mui/material/Paper';
import EnhanceTableBody from './EnhanceTableBody';
import EnhanceTableHead from './EnhanceTableHead';
import { headCellsProps, rowDataProps } from './types';
import { handleSelectedClick } from './utils';
import PrimarySearchAppBar from './EnhancedTableToolbar';
import { formatDate } from '@/utils/dateEsFormatter';
import Pagination from '@mui/material/Pagination';
import { set } from 'nprogress';
import { useAppDispatch } from '@/redux/hooks';
import { apiSlice } from '@/redux/features/api/apiSlice';
import { handleSearch } from '@/utils/handleSearch';
const Table = ({
  headCells = [],
  row = [],
  filterArea = true,
  handleOpen = () => {},
  isPagination = true,
  isCheckbox,
  searchBar,
  dateRange,
  filterName,
  gridView,
  handleSelectedAllData = () => {},
  searchFieldNameItem = 'name',
  handleBulkDelete = () => {},
  page,
  setPage,
  rowsPerPage,
  setRowsPerPage,
  count,
  isLoading
}: {
  headCells: headCellsProps[];
  row: rowDataProps[];
  filterArea?: boolean;
  handleOpen?: any;

  isPagination?: boolean;
  isCheckbox?: any;
  searchBar?: boolean;
  dateRange?: any;
  filterName?: any;
  gridView?: any;
  handleSelectedAllData?: any;
  searchFieldNameItem?: string[];
  handleBulkDelete?: any;
  page?: any;
  setPage?: any;
  rowsPerPage?: any;
  setRowsPerPage?: any;
  count?: any;
  isLoading?: boolean;
}) => {
  const [dense, setDense] = React.useState(false);
  const [selected, setSelected] = React.useState<any>([]);

  const dispatch = useAppDispatch();

  // const [page, setPage] = React.useState(0);
  const [tableAllData, setTableAllData] = React.useState<any>(row);

  // console.log(tableAllData, 'tableAllData');
  //   page selected function
  React.useEffect(() => {
    if (row && row?.length) {
      setTableAllData(row);
    }
  }, [row]);

  const handleChangePage = (event: unknown, newPage: number) => {
    setPage(newPage);
  };
  // selected item function code here
  const handleSelectedClickItem = async (id: any) => {
    const selectedItem = await handleSelectedClick(id, selected);
    setSelected(selectedItem);
  };
  //  how much data showing on the table body
  const handleChangeRowsPerPage = (event: React.ChangeEvent<HTMLInputElement>) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };
  //   all item selected function code here
  const handleSelectAllClick = async (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.checked) {
      const newSelected = [...tableAllData].map((n) => n.id);
      setSelected(newSelected);
      return;
    }
    setSelected([]);
  };
  // data slice for row per page code here
  // const visibleRows = React.useMemo(
  //   () => [...tableAllData].slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage),
  //   [page, rowsPerPage]
  // );
  // console.log('visibleRows', visibleRows);
  //?! sorting logic code here
  // React.useEffect(() => {
  //   setTableAllData(visibleRows);
  // }, [visibleRows, setTableAllData, rowsPerPage]);

  const initialSortConfig = headCells.reduce((acc: any, column: any) => {
    if (column?.option?.sortable) {
      acc[column?.id] = { key: column?.id, direction: 'asc' };
    }
    return acc;
  }, {});
  // sortable function here
  const [sortConfig, setSortConfig] = React.useState(initialSortConfig);
  const handleSort = (key: string) => {
    const direction = sortConfig[key].direction === 'asc' ? 'desc' : 'asc';
    const newSortConfig = { ...sortConfig, [key]: { key, direction } };

    const resultData =
      tableAllData?.length &&
      [...tableAllData]?.sort((a: any, b: any) => {
        if (direction === 'asc') {
          return a[key] > b[key] ? 1 : -1;
        } else if (direction === 'desc') {
          return a[key] < b[key] ? 1 : -1;
        }
        return 0;
      });

    setTableAllData(resultData);
    setSortConfig(newSortConfig);
  };
  // sort by date range
  function sortingDateRange(startDate: string, endDate: string) {
    // const joinDate = new Date(item.join);
    const startDateObj = new Date(startDate);
    const endDateObj = new Date(endDate);
    setTableAllData(
      [...row].filter((a: any, b: any) => {
        const joinDate = new Date(formatDate(a.join));
        return joinDate >= startDateObj && joinDate <= endDateObj;
      })
    );
  }
  // unique field search using unique field
  function searchWithUniqueField(search: string) {
    if (search) {
      setTableAllData(handleSearch({ data: row, searchFieldNameItem, search }));
    } else {
      setTableAllData(row);
    }
  }

  const handleBulkControl = (item: any) => {
    handleBulkDelete(selected, item);
  };
  // console.log(tableAllData, 'tableAllData');
  return (
    <Box
      sx={{
        width: '100%',
        backgroundColor: (theme: any) => (theme.palette.mode === 'light' ? 'bg.light' : 'bg.dark'),
        borderRadius: '10px',
        overflow: 'hidden',
        boxShadow: (theme: any) => theme.shadows[1]
      }}
      color={(theme: any) =>
        theme.palette.mode === 'light' ? theme?.palette?.title?.light : theme?.palette?.title?.dark
      }
    >
      {isLoading ? (
        <Box
          sx={{
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            height: '60vh'
          }}
        >
          <Typography
            sx={{
              fontSize: '20px',
              color: (theme: any) =>
                theme.palette.mode === 'light'
                  ? theme?.palette?.title?.light
                  : theme?.palette?.title?.dark,
              textAlign: 'center'
            }}
          >
            Loading...
          </Typography>
        </Box>
      ) : row.length ? (
        <Paper sx={{ width: '100%' }}>
          {filterArea && (
            <PrimarySearchAppBar
              handleOpen={handleOpen}
              sortingDateRange={sortingDateRange}
              searchBar={searchBar}
              dateRange={dateRange}
              filterName={filterName}
              gridView={gridView}
              selected={selected}
              searchWithUniqueField={searchWithUniqueField}
              handleBulkControl={handleBulkControl}
            />
          )}
          <TableContainer>
            <TableWrapper
              sx={{
                minWidth: 750,
                backgroundColor: (theme: any) =>
                  theme.palette.mode === 'light' ? 'bg.light' : 'bg.dark'

                // '&::-webkit-scrollbar': {
                //   width: '6px' // Width of the scrollbar
                // },
                // '&::-webkit-scrollbar-thumb': {
                //   backgroundColor: (theme: any) =>
                //     theme.palette.mode === 'light'
                //       ? alpha(theme?.palette?.primary?.light, 0.3)
                //       : alpha(theme?.palette?.primary?.dark, 0.3), // Color of the thumb
                //   borderRadius: '10px' // Border radius of the thumb
                // },
                // '&::-webkit-scrollbar-thumb:hover': {
                //   backgroundColor: (theme: any) =>
                //     theme.palette.mode === 'light'
                //       ? alpha(theme?.palette?.primary?.light, 0.5)
                //       : alpha(theme?.palette?.primary?.dark, 0.5) // Color of the thumb on hover
                // },
                // '&::-webkit-scrollbar-track': {
                //   backgroundColor: 'rgba(0, 0, 0, 0.1)', // Color of the track
                //   borderRadius: '10px' // Border radius of the track
                // }
              }}
              size={dense ? 'small' : 'medium'}
            >
              {/* table header code here  */}
              <EnhanceTableHead
                headCells={headCells}
                onSelectAllClick={handleSelectAllClick}
                rowCount={row.length}
                numSelected={selected.length}
                handleSort={handleSort}
                sortConfig={sortConfig}
                isCheckbox={isCheckbox}
              />
              {/* table body data here  */}
              <EnhanceTableBody
                row={tableAllData}
                handleSelectClick={handleSelectedClickItem}
                selected={selected}
                headCells={headCells}
                isCheckbox={isCheckbox}
                isLoading={isLoading}
              />
            </TableWrapper>
          </TableContainer>
          {/* pagination code here  */}
          {isPagination && (
            <Box
              display="flex"
              justifyContent={'flex-end'}
              paddingY={'12px'}
              sx={{
                backgroundColor: (theme: any) =>
                  theme.palette.mode === 'light' ? 'bg.light' : 'bg.dark'
              }}
            >
              <FormControl>
                <NativeSelect
                  defaultValue={rowsPerPage}
                  inputProps={{
                    name: 'age',
                    id: 'uncontrolled-native'
                  }}
                  onChange={(e) => {
                    // console.log(e.target.value, 'e.target.value');
                    setRowsPerPage(Number(e.target.value));
                  }}
                >
                  <option value={10}>10</option>
                  <option value={20}>20</option>
                  <option value={30}>30</option>
                </NativeSelect>
              </FormControl>
              <Pagination
                count={count}
                color="primary"
                onChange={(e: any) => {
                  setPage(Number(e.target?.textContent));
                  // useAppDispatch(apiSlice.util.)
                }}
              />
            </Box>
          )}
        </Paper>
      ) : (
        <Stack direction={'column'} spacing={0} border={'1px solid gray'}>
          {/* Table Header */}
          <Stack direction={'row'} spacing={0}>
            <Box
              width={'50%'}
              borderBottom={'1px solid gray'}
              padding={'10px'}
              textAlign={'center'}
            >
              Column 1
            </Box>
            <Box
              width={'50%'}
              borderBottom={'1px solid gray'}
              padding={'10px'}
              textAlign={'center'}
            >
              Column 2
            </Box>
          </Stack>

          {/* Table Rows */}

          {isLoading ? (
            <Box
              sx={{
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'center',
                height: '80vh'
              }}
            >
              <Typography
                sx={{
                  fontSize: '20px',
                  color: (theme: any) =>
                    theme.palette.mode === 'light'
                      ? theme?.palette?.title?.light
                      : theme?.palette?.title?.dark,
                  textAlign: 'center'
                }}
              >
                Loading...
              </Typography>
            </Box>
          ) : row?.length ? null : (
            <Stack direction={'row'} spacing={0}>
              <Box
                width={'100%'}
                borderBottom={'1px solid gray'}
                padding={'10px'}
                textAlign={'center'}
              >
                No Data Found
              </Box>
            </Stack>
          )}
          {/* Add more rows as needed */}
        </Stack>
      )}
    </Box>
  );
};

export default Table;
