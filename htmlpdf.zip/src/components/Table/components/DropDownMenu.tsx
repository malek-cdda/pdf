import * as React from 'react';

import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select, { SelectChangeEvent } from '@mui/material/Select';

const DropDownMenu = ({
  optionItem,
  value,
  handleChange
}: {
  optionItem: string[] | number[];
  value: string;
  handleChange: (event: SelectChangeEvent) => void;
}) => {
  return (
    <div>
      <FormControl
        sx={{
          minWidth: 120,

          '& .MuiOutlinedInput-root': {
            '&.Mui-focused fieldset': {
              borderColor: '#aeabb8'
            }
          }
        }}
      >
        <Select
          value={value}
          onChange={handleChange}
          displayEmpty
          inputProps={{ 'aria-label': 'Without label' }}
          sx={{
            height: '40px',
            color: (theme: any) =>
              theme.palette.mode === 'light'
                ? theme?.palette?.title?.main
                : theme?.palette?.title?.light
          }}
        >
          <MenuItem value="">
            <em>None</em>
          </MenuItem>
          {optionItem.map((item: string | number, index: number) => (
            <MenuItem
              value={item}
              key={index}
              sx={{
                color: (theme) =>
                  theme.palette.mode === 'light'
                    ? theme.palette.primary.main
                    : theme.palette.primary.light
              }}
            >
              {item}
            </MenuItem>
          ))}
        </Select>
      </FormControl>
    </div>
  );
};

export default DropDownMenu;
