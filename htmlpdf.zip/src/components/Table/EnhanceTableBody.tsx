import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableRow from '@mui/material/TableRow';
import Checkbox from '@mui/material/Checkbox';

import { rowDataProps } from './types';
import React from 'react';
import { Box, Typography } from '@mui/material';
const EnhanceTableBody = ({
  row,
  handleSelectClick,
  selected,
  headCells,
  isCheckbox,
  isLoading
}: {
  row: rowDataProps[];
  handleSelectClick: any;
  selected: any;
  headCells: any;
  isCheckbox: boolean;
  isLoading?: boolean;
}) => {
  const isSelected = (id: number) => selected?.indexOf(id) !== -1;
  const [isChecked, setIsChecked] = React.useState(false);

  const handleChange = (event: any) => {
    setIsChecked(event.target.checked);
  };
  return (
    <TableBody>
      {row?.map((item: any, index: any) => {
        const isItemSelected = isSelected(item.id);
        const labelId = `enhanced-table-checkbox-${index}`;

        return (
          <TableRow
            //   hover
            //   onClick={(event) => handleClick(event, row.id)}
            //   role="checkbox"
            //   aria-checked={isItemSelected}
            //   tabIndex={-1}
            //   key={row.id}
            //   selected={isItemSelected}
            //   sx={{ cursor: 'pointer' }}
            key={item.uid}
            hover
            onClick={() => {
              // handleSelectClick(row.id);
            }}
          >
            {isCheckbox && (
              <TableCell
                padding="checkbox"
                onClick={() => {
                  handleSelectClick(item.id);
                }}
              >
                <Checkbox
                  size="small"
                  checked={isItemSelected}
                  onChange={handleChange}
                  inputProps={{
                    'aria-labelledby': '1'
                  }}
                  sx={{
                    color: (theme: any) =>
                      theme.palette.mode === 'light'
                        ? theme?.palette?.primary?.light
                        : theme?.palette?.primary?.dark,
                    '&.Mui-checked': {
                      color: (theme: any) =>
                        theme.palette.mode === 'light'
                          ? theme?.palette?.primary?.light
                          : theme?.palette?.primary?.dark
                    }
                  }}
                />
              </TableCell>
            )}

            {isLoading ? (
              <Box
                sx={{
                  display: 'flex',
                  justifyContent: 'center',
                  alignItems: 'center',
                  height: '80vh'
                }}
              >
                <Typography
                  sx={{
                    fontSize: '20px',
                    color: (theme: any) =>
                      theme.palette.mode === 'light'
                        ? theme?.palette?.title?.light
                        : theme?.palette?.title?.dark,
                    textAlign: 'center'
                  }}
                >
                  Loading...
                </Typography>
              </Box>
            ) : (
              headCells?.map((header: any, index: any) => (
                <TableCell
                  component="th"
                  id={labelId}
                  scope="row"
                  padding="none"
                  key={index}
                  sx={{
                    fontSize: '13px',
                    padding: '4px 9.5px',
                    fontWeight: 400,
                    color: (theme: any) =>
                      theme.palette.mode === 'light'
                        ? theme?.palette?.title?.light
                        : theme?.palette?.title?.dark,
                    textAlign: header?.option?.align ? header?.option?.align : 'left'
                    // color: 'red'
                  }}
                >
                  {header?.render
                    ? header?.render(item)
                    : item[header?.id]
                      ? item[header?.id]
                      : 'N/A'}
                  {/* {header?.render ? header?.render(row) : row[header?.id]} */}
                </TableCell>
              ))
            )}
          </TableRow>
        );
      })}
      {/* {emptyRows > 0 && (
          <TableRow
            style={{
              height: (dense ? 33 : 53) * emptyRows,
            }}
          >
            <TableCell colSpan={6} />
          </TableRow>
        )} */}
    </TableBody>
  );
};

export default EnhanceTableBody;
