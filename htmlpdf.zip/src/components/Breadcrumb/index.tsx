import { Breadcrumbs, Stack, Typography } from '@mui/material';
import React from 'react';

import Link from 'next/link';

import NavigateNextIcon from '@mui/icons-material/NavigateNext';

import { alpha, styled } from '@mui/material/styles';
import { usePathname } from 'next/navigation';

const BreadcrumbLink = styled(Link)(({ theme }) => ({
  color: 'inherit',
  textTransform: 'capitalize',
  textDecoration: 'none',
  '&:hover': {
    textDecoration: 'underline'
  }
}));

const Breadcrumb = () => {
  const route = usePathname();
  const pathnames = route?.split('/')?.filter((x) => x) || [];

  return (
    <Stack
      direction={'row'}
      justifyContent={'space-between'}
      px={3}
      py={1}
      sx={{
        background: (theme: any) =>
          theme?.palette?.mode === 'light'
            ? theme?.palette?.topNav?.light
            : theme?.palette?.topNav?.dark,
        boxShadow: 1
      }}
    >
      <Typography
        variant="h6"
        color={(theme: any) =>
          theme?.palette?.mode === 'light'
            ? alpha(theme?.palette?.title?.light, 0.9)
            : alpha(theme?.palette?.title?.dark, 0.9)
        }
        sx={{
          textTransform: 'capitalize'
        }}
      >
        {pathnames?.[0]?.replace(/-/g, ' ')}
      </Typography>
      <Breadcrumbs separator={<NavigateNextIcon fontSize="small" />} aria-label="breadcrumb">
        <BreadcrumbLink href="/">Home</BreadcrumbLink>
        {pathnames?.map((item, i) => (
          <BreadcrumbLink key={i} href={`/${item}`}>
            {item?.replace(/-/g, ' ')}
          </BreadcrumbLink>
        ))}
      </Breadcrumbs>
    </Stack>
  );
};

export default Breadcrumb;
