'use client';

import { Box, Typography, alpha } from '@mui/material';

type PageHeaderProps = {
  title: string;
  desc?: string;
};
const PageHeader = ({ title, desc }: PageHeaderProps) => {
  return (
    <Box
      sx={{
        width: '100%',
        padding: '0 0 20px 0',
        color: (theme: any) =>
          theme.palette.mode === 'light'
            ? alpha(theme.palette.title.light, 0.9)
            : alpha(theme.palette.title.dark, 0.9)
      }}
    >
      <Typography variant="h5">{title}</Typography>
      <Typography fontSize={14}>{desc}</Typography>
    </Box>
  );
};
export default PageHeader;
