'use client';
import * as React from 'react';
import { Box, IconButton, Stack, Toolbar } from '@mui/material';
import { styled } from '@mui/material/styles';
import MuiAppBar, { AppBarProps as MuiAppBarProps } from '@mui/material/AppBar';
import SearchBar from './components/SearchBar';
import ToggleTheme from './components/ToggleTheme';
import ProfileMenu from './components/ProfileMenu';
import Notifications from './components/Notifications';

type TopNavProps = {
  open: boolean;
  toggleDrawer: () => void;
};

interface AppBarProps extends MuiAppBarProps {
  open?: boolean;
}

const drawerWidth: number = 240;

const AppBar = styled(MuiAppBar, {
  shouldForwardProp: (prop) => prop !== 'open'
})<AppBarProps>(({ theme, open }: any) => ({
  zIndex: theme.zIndex.drawer + 1,
  transition: theme.transitions.create(['width', 'margin'], {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen
  }),
  background:
    theme.palette.mode === 'light' ? theme?.palette?.topNav?.light : theme?.palette?.topNav?.dark,
  width: `calc(100vw - ${72}px)`,
  [theme.breakpoints.down('sm')]: {
    width: theme.spacing(9)
  },
  // boxShadow: '6px 0px 8px 0px rgba(51, 49, 49, 0.19)',
  borderBottom: '1px solid rgba(173, 173, 173, 0.12)',
  boxShadow: '0px 0px 0px 0px rgba(255, 255, 255, 0)',
  ...(open && {
    marginLeft: drawerWidth,
    width: `calc(100% - ${drawerWidth}px)`,
    transition: theme.transitions.create(['width', 'margin'], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen
    })
  })
}));

function TopNav({ open, toggleDrawer }: TopNavProps) {
  return (
    <AppBar position="absolute" open={open}>
      <Toolbar
        sx={{
          pr: '24px' // keep right padding when drawer closed
        }}
      >
        {/* <IconButton
          edge="start"
          color="inherit"
          aria-label="open drawer"
          onClick={toggleDrawer}
          sx={{
            marginRight: '36px'
          }}
        >
          {open ? <ChevronLeftIcon /> : <ChevronRightIcon />}
        </IconButton> */}

        {/* left side  */}
        <Box
          sx={{
            flexGrow: 1,
            display: 'flex',
            alignItems: 'center'
          }}
        >
          {/* search  */}
          <SearchBar />
        </Box>
        <Stack spacing={1} direction="row" alignItems={'center'}>
          {/* theme mode  */}
          <ToggleTheme />
          {/* notifications */}
          <Notifications />
          {/* profile avatar */}
          <ProfileMenu />
        </Stack>
      </Toolbar>
    </AppBar>
  );
}

export default TopNav;
