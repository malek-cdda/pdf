import React from 'react';
import DarkModeIcon from '@mui/icons-material/DarkMode';
import LightModeIcon from '@mui/icons-material/LightMode';
import { Box, Fab, ToggleButtonGroup, alpha } from '@mui/material';
import { CSFThemeContext } from '@/theme/Theme';

const ToggleTheme = () => {
  const { csfTheme, setThemeMode } = React.useContext(CSFThemeContext);

  const handleThemeChange = () => {
    setThemeMode(csfTheme?.theme?.palette?.mode === 'light' ? 'dark' : 'light');
  };

  return (
    <Box>
      <ToggleButtonGroup size="small">
        <Fab
          size="small"
          onClick={handleThemeChange}
          color="inherit"
          sx={{
            ml: 3,
            bgcolor: (theme) =>
              theme.palette.mode === 'light'
                ? alpha(theme.palette.common.black, 0.05)
                : alpha(theme.palette.common.white, 0.05),
            color: (theme: any) =>
              theme.palette.mode === 'light'
                ? alpha(theme.palette.title.light, 0.9)
                : alpha(theme.palette.title.dark, 0.9),
            '&:hover': {
              bgcolor: (theme) => alpha(theme.palette.common.black, 0.1)
            }
          }}
        >
          {csfTheme?.theme?.palette?.mode === 'light' ? <LightModeIcon /> : <DarkModeIcon />}
        </Fab>
      </ToggleButtonGroup>
    </Box>
  );
};

export default ToggleTheme;
