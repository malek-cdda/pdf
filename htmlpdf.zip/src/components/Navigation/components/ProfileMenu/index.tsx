import { stringAvatar } from '@/utils/avatarString';
import { Avatar, Box, Menu, MenuItem, Skeleton, Stack, Typography, alpha } from '@mui/material';
import React from 'react';
import MenuWrapper from '../Notifications/components/MenuWrapper';
import Link from 'next/link';
import ProfileMenuList from './ProfileMenuList';
import { useSelector } from 'react-redux';

const ProfileMenu = () => {
  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
  const openm = Boolean(anchorEl);
  const handleClick = (event: any) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  const user = useSelector((state: any) => state.user);
  const { data: userdata, loading } = user || {};
  const { first_name, last_name, role, is_superuser } = userdata || {};

  // Skeleton menu
  const MenuSkeleton = (
    <Stack direction="row" gap={1} alignItems="center">
      <Skeleton variant="circular" width={30} height={30} />
      <Box>
        <Skeleton variant="text" width={100} height={10} />
        <Skeleton variant="text" width={80} height={10} />
      </Box>
    </Stack>
  );

  if (loading) return MenuSkeleton;
  return (
    <Stack
      direction="row"
      alignItems={'center'}
      sx={{
        bgcolor: (theme) =>
          theme.palette.mode === 'light'
            ? alpha(theme.palette.common.black, 0.05)
            : alpha(theme.palette.common.white, 0.05),
        '&:hover': {
          bgcolor: (theme) => alpha(theme.palette.common.black, 0.1),
          cursor: 'pointer'
        },
        color: (theme: any) =>
          theme.palette.mode === 'light'
            ? alpha(theme.palette.title.light, 0.9)
            : alpha(theme.palette.title.dark, 0.9),
        px: 1,
        py: 0.5,
        borderRadius: 1
      }}
      spacing={1}
    >
      <Avatar
        sx={{
          width: 30,
          height: 30,
          fontSize: 15
        }}
        {...stringAvatar('Kent Dodds')}
        onClick={handleClick}
      />

      <Stack component="div" direction="column" onClick={handleClick}>
        <Typography variant="body2" color="inherit">
          {first_name} {last_name}
        </Typography>
        <Typography variant="body2" sx={{ fontWeight: 400, fontSize: '12px' }} color="inherit">
          {is_superuser ? 'Super Admin' : role?.label}
        </Typography>
      </Stack>
      {/* menu list  */}
      <ProfileMenuList open={openm} anchorEl={anchorEl} handleClose={handleClose} />
    </Stack>
  );
};

export default ProfileMenu;
