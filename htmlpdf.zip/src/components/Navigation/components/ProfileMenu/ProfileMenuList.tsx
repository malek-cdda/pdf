import React, { useEffect } from 'react';
import MenuWrapper from '../Notifications/components/MenuWrapper';
import { MenuItem, alpha } from '@mui/material';
import { styled } from '@mui/material/styles';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { useSignOutMutation } from '@/app/auth/sign-in/feature/loginApi';
import { deleteCookie } from '@/utils/cookies';

type ProfileMenuListProps = {
  open: boolean;
  anchorEl: any;
  handleClose: () => void;
};

const ProfileMenuItem = styled(Link)(({ theme }) => ({
  textDecoration: 'none'
}));

const listItem = [
  { href: '/profile', text: 'Profile' },
  { href: '/account', text: 'My account' }
  // { href: '/logout', text: 'Logout' }
];

const ProfileMenuList = ({ open, anchorEl, handleClose }: ProfileMenuListProps) => {
  const [signOut, { data, error, isLoading, isSuccess }] = useSignOutMutation();
  const router = useRouter();
  const pathname = usePathname();

  // Handle the click event of the menu item
  const handleItemClick = () => {
    handleClose(); // Close the menu when an item is clicked
    signOut({}); // Call the sign-out mutation
  };

  // Redirect to the sign-in page after successful sign-out
  useEffect(() => {
    if (isSuccess) {
      const logoutChannel = new BroadcastChannel('logoutChannel');
      logoutChannel.postMessage('logout');
      deleteCookie('access');
      deleteCookie('refresh');
      router.push(`/auth/sign-in?callbackUrl=${encodeURIComponent(pathname)}`);
    }
  }, [isSuccess, router, pathname]);

  return (
    <MenuWrapper open={open} anchorEl={anchorEl} handleClose={handleClose}>
      {listItem.map((item, index) => (
        <ProfileMenuItem key={index} href={item?.href}>
          <MenuItem
            sx={{
              color: (theme) =>
                theme.palette.mode === 'light'
                  ? alpha(theme.palette.common.black, 0.7)
                  : alpha(theme.palette.common.white, 0.7)
            }}
          >
            {item?.text}
          </MenuItem>
        </ProfileMenuItem>
      ))}
      <MenuItem
        onClick={() => handleItemClick()} // Pass href to handleItemClick
        sx={{
          color: (theme) =>
            theme.palette.mode === 'light'
              ? alpha(theme.palette.common.black, 0.7)
              : alpha(theme.palette.common.white, 0.7)
        }}
      >
        Logout
      </MenuItem>
    </MenuWrapper>
  );
};

export default ProfileMenuList;
