import { Button, Stack } from '@mui/material';
import React from 'react';
import NotificationItem from './NotificationItem';

const NotificationList = () => {
  return (
    <Stack maxWidth={'262px'} gap={1}>
      {/* notification item */}
      <NotificationItem />
      <NotificationItem />
      <NotificationItem />
      <Button variant="outlined">View all Notifications</Button>
    </Stack>
  );
};

export default NotificationList;
