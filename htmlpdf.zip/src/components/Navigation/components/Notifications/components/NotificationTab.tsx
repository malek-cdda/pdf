import { Badge, Box, Stack, Tab, Tabs, Typography, alpha } from '@mui/material';
import React from 'react';
import NotificationTabPanel from './NotificationTabPanel';
import NotificationList from './NotificationList';
import NotificationsActiveIcon from '@mui/icons-material/NotificationsActive';

const NotificationTab = () => {
  const [value, setValue] = React.useState(0);

  const handleChange = (event: React.SyntheticEvent, newValue: number) => {
    setValue(newValue);
  };

  return (
    <Box sx={{ width: '100%' }}>
      <Box
        sx={{
          borderBottom: 1,
          borderColor: 'divider',
          backgroundColor: (theme) => alpha(theme.palette.primary.main, 0.3),
          borderTopRightRadius: '5px',
          borderTopLeftRadius: '5px',
          color: (theme: any) =>
            theme.palette.mode === 'light'
              ? alpha(theme.palette.title.light, 0.9)
              : alpha(theme.palette.title.dark, 0.9)
        }}
      >
        {/* header  */}
        <Stack
          px={2}
          pt={2}
          direction={'row'}
          alignItems={'center'}
          justifyContent={'space-between'}
        >
          <Typography variant="h6" color="inherit">
            Notifications
          </Typography>
          <Badge
            sx={{ bgcolor: 'primary.main', color: 'primary.contrastText', px: 1, borderRadius: 1 }}
          >
            <Typography variant="button" color="inherit">
              4 New
            </Typography>
          </Badge>
        </Stack>
        <Tabs value={value} onChange={handleChange}>
          <Tab label="All (4)" />
          <Tab label="Messages" />
          <Tab label="Alerts" />
        </Tabs>
      </Box>
      <NotificationTabPanel value={value} index={0}>
        {/* notifications items */}
        <NotificationList />
      </NotificationTabPanel>
      <NotificationTabPanel value={value} index={1}>
        <NotificationList />
      </NotificationTabPanel>
      <NotificationTabPanel value={value} index={2}>
        {/* if there is no notification show this message */}
        <Stack maxWidth={'262px'} alignItems={'center'} justifyContent={'center'}>
          <NotificationsActiveIcon sx={{ fontSize: 100, color: 'primary.main' }} />
          <Typography
            variant="h4"
            textAlign={'center'}
            color={(theme: any) =>
              theme.palette.mode === 'light'
                ? alpha(theme.palette.title.light, 0.9)
                : alpha(theme.palette.title.dark, 0.9)
            }
          >
            Hay! You have no any notifications
          </Typography>
        </Stack>
      </NotificationTabPanel>
    </Box>
  );
};

export default NotificationTab;
