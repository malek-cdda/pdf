import { Box, Stack, Typography } from '@mui/material';
import Link from 'next/link';
import React from 'react';

const SearchItem = ({ results, setOpen }: any) => {
  // Group search results by category
  const groupedResults: { [category: string]: any } = results.reduce((acc: any, result: any) => {
    acc[result.category] = acc[result.category] || [];
    acc[result.category].push(result);
    return acc;
  }, {});
  return (
    <Box>
      {Object.entries(groupedResults).map(([category, items]) => (
        <Box key={category}>
          <Typography variant="h5" mt={1}>
            {category}
          </Typography>
          {items.map((item: any, index: number) => {
            return (
              <Box
                key={index}
                mt={1}
                ml={2}
                sx={{
                  backgroundColor: (theme: any) =>
                    theme.palette.mode === 'light'
                      ? theme?.palette?.title?.dark
                      : theme?.palette?.title?.light,
                  padding: 1,
                  borderRadius: 1
                }}
              >
                <Box
                  sx={{
                    color: (theme: any) =>
                      theme.palette.mode === 'light'
                        ? theme?.palette?.title?.light
                        : theme?.palette?.title?.dark,
                    cursor: 'pointer',
                    textDecoration: 'underline'
                  }}
                >
                  <Link
                    style={{
                      color: 'inherit',
                      textDecoration: 'none'
                    }}
                    href={item.path}
                    onClick={() => {
                      setOpen(false);
                    }}
                  >
                    {item.displayText}
                  </Link>
                </Box>
              </Box>
            );
          })}
        </Box>
      ))}
    </Box>
  );
};

export default SearchItem;
