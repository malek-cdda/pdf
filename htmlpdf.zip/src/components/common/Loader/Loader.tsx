import { Stack } from '@mui/material';
import React from 'react';

const Loader = () => {
  return (
    <Stack
      sx={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        height: '100%'
      }}
    >
      <div className="loader"></div>
    </Stack>
  );
};

export default Loader;
