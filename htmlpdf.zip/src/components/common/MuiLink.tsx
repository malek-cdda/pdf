"use client"

import { styled } from '@mui/material/styles';
import Link from 'next/link';
import React from 'react';
const StyledLink = styled(Link)(({ theme }) => ({
  // textDecoration: 'none',
  color: theme?.palette?.primary?.main
}));
const MuiLink = ({ href = '', children, ...rest }: any) => {
  return (
    <StyledLink href={href} {...rest}>
      {children}
    </StyledLink>
  );
};

export default MuiLink;
