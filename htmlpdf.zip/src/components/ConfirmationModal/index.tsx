import React from 'react';
import { useConfirmationModalContext } from '@/providers/ConfirmationModalContext';
import { Box, Button, Modal, Stack, Typography } from '@mui/material';
import { PiTrashThin } from 'react-icons/pi';

interface ConfirmationModalProps {
  message?: string;
  onConfirm?: (confirmed: boolean) => void;
}

// STYLE
const style = {
  position: 'absolute' as 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: 500,
  bgcolor: 'background.paper',
  borderRadius: 2,
  boxShadow: 24,
  p: 4
};

const ConfirmationModal: React.FC<ConfirmationModalProps> = ({ open }: any) => {
  const { confirmAction, closeModal, message } = useConfirmationModalContext() as unknown as {
    confirmAction: () => void;
    closeModal: () => void;
    message: string;
  };

  console.log('isOpen', open);

  return (
    <Modal
      open={open}
      onClose={closeModal}
      aria-labelledby="modal-modal-title"
      aria-describedby="modal-modal-description"
    >
      <Box sx={style} textAlign="center">
        <PiTrashThin
          style={{
            fontSize: 80,
            color: 'red',
            border: '1px solid red',
            borderRadius: '50%',
            padding: 15
          }}
        />
        <Typography id="modal-modal-title" variant="h2">
          Are you sure?
        </Typography>
        <Typography id="modal-modal-description" sx={{ mt: 2 }}>
          {message
            ? message
            : 'Do you really want to delete this records? This process cannot be undone.'}
        </Typography>
        <Stack direction="row" gap={4} mt={4}>
          <Button fullWidth variant="contained" onClick={closeModal}>
            No
          </Button>
          <Button color="error" fullWidth variant="contained" onClick={confirmAction}>
            Yes
          </Button>
        </Stack>
      </Box>
    </Modal>
  );
};

export default ConfirmationModal;
