'use client';
import * as React from 'react';
import Toolbar from '@mui/material/Toolbar';
import TopNav from '@/components/Navigation/TopNav';
import ThemeAction from '@/components/ThemeAction/Index';
import { Box, GlobalStyles, Skeleton, alpha } from '@mui/material';
import Sidebar from '@/components/Sidebar/Sidebar';
import Breadcrumb from '@/components/Breadcrumb';
import { usePathname, useRouter } from 'next/navigation';
import { useConfirmationModalContext } from '@/providers/ConfirmationModalContext';
import ConfirmationModal from '@/components/ConfirmationModal';
import { useDispatch, useSelector } from 'react-redux';
import { useGetUserProfileQuery } from '@/app/(dashboard)/user/features/userApi';
import Loader from '@/components/common/Loader/Loader';

const Dashboard = ({ children }: { children: React.ReactNode }) => {
  const { showModal } = useConfirmationModalContext() as unknown as { showModal: boolean };
  const router = useRouter();

  // get current user profile
  useGetUserProfileQuery({});
  const user = useSelector((state: any) => state.user);

  const route = usePathname();
  const [open, setOpen] = React.useState(true);
  const toggleDrawer = () => {
    setOpen(!open);
  };

  // invoke when user click browser back/forword navigation
  React.useEffect(() => {
    window.addEventListener('popstate', function (event) {
      router.push(window.location.pathname);
    });
  }, [router, route]);

  React.useEffect(() => {
    // Function to handle logout
    const handleLogout = () => {
      // Redirect to sign-in page after logout
      router.push(`/auth/sign-in?callbackUrl=${encodeURIComponent(route)}`);
    };

    // Listen for logout messages from other tabs
    const logoutChannel = new BroadcastChannel('logoutChannel');
    logoutChannel.onmessage = (event) => {
      if (event.data === 'logout') {
        handleLogout();
      }
    };
    return () => {
      logoutChannel.close();
    };
  }, [router]);

  return (
    <>
      <Box
        sx={{
          display: 'flex'
        }}
      >
        <GlobalStyles
          styles={(theme) => ({
            '&::-webkit-scrollbar': {
              width: '6px', // Width of the scrollbar
              height: '6px' // Height of the scrollbar
            },
            '&::-webkit-scrollbar-thumb': {
              backgroundColor:
                theme.palette.mode === 'light'
                  ? alpha(theme?.palette?.primary?.light, 0.3)
                  : alpha(theme?.palette?.primary?.dark, 0.3), // Color of the thumb
              borderRadius: '10px' // Border radius of the thumb
            },
            '&::-webkit-scrollbar-thumb:hover': {
              backgroundColor:
                theme.palette.mode === 'light'
                  ? alpha(theme?.palette?.primary?.light, 0.5)
                  : alpha(theme?.palette?.primary?.dark, 0.5) // Color of the thumb on hover
            },
            '&::-webkit-scrollbar-track': {
              backgroundColor: 'rgba(0, 0, 0, 0.1)', // Color of the track
              borderRadius: '10px' // Border radius of the track
            }
          })}
        />
        <TopNav open={open} toggleDrawer={toggleDrawer} />
        <Sidebar open={open} />
        <Box
          component="main"
          sx={{
            backgroundColor: (theme: any) =>
              theme.palette.mode === 'light' ? 'bg.light' : alpha(theme.palette.bg.dark, 0.29),
            flexGrow: 1,
            height: '100vh',
            overflow: 'auto'
          }}
        >
          <Toolbar />
          {/* Breadcrumb  */}
          {route !== '/' && <Breadcrumb />}
          <Box sx={{ px: 3, py: 2 }}>{children}</Box>
        </Box>
        <ThemeAction />
      </Box>
      {/* @ts-ignore */}
      <ConfirmationModal open={showModal} />
    </>
  );
};

export default Dashboard;
