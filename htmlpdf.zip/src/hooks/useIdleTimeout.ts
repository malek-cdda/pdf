import { useEffect } from 'react';

const useIdleTimeout = (idleTimeoutMillis: number, redirectUrl: string): void => {
  useEffect(() => {
    let idleTime = 0;
    let timeout: NodeJS.Timeout;

    const resetIdleTime = () => {
      idleTime = 0;
    };

    const incrementIdleTime = () => {
      idleTime += 1000;
    };

    const handleIdleTimeout = () => {
      if (idleTime >= idleTimeoutMillis) {
        window.location.href = redirectUrl;
      }
    };

    const startIdleTimeout = () => {
      timeout = setInterval(() => {
        incrementIdleTime();
        handleIdleTimeout();
      }, 1000);
    };

    const clearIdleTimeout = () => {
      clearInterval(timeout);
    };

    const handleUserActivity = () => {
      resetIdleTime();
      clearIdleTimeout();
      startIdleTimeout();
    };

    document.addEventListener('mousemove', handleUserActivity);
    document.addEventListener('keypress', handleUserActivity);

    startIdleTimeout();

    return () => {
      document.removeEventListener('mousemove', handleUserActivity);
      document.removeEventListener('keypress', handleUserActivity);
      clearIdleTimeout();
    };
  }, [idleTimeoutMillis, redirectUrl]);
};

export default useIdleTimeout;
