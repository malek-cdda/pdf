import { useEffect, useRef, useState } from 'react';

// Declare the grecaptcha and onRecaptchaLoad properties on the Window interface
declare global {
  // eslint-disable-next-line no-unused-vars
  interface Window {
    grecaptcha: {
      // eslint-disable-next-line no-unused-vars
      render: (element: HTMLElement, options: any) => void;
    };
    onRecaptchaLoad?: () => void;
  }
}

// Custom hook to handle reCAPTCHA
const useReCaptcha = (siteKey: string) => {
  const recaptchaRef = useRef<HTMLDivElement>(null);
  const [token, setToken] = useState<string | null>(null);

  useEffect(() => {
    let isRendered = false;

    const renderCaptcha = () => {
      if (!window.grecaptcha) {
        const script = document.createElement('script');
        script.src =
          'https://www.google.com/recaptcha/api.js?onload=onRecaptchaLoad&render=explicit';
        script.async = true;
        script.defer = true;

        // Add an event listener to handle the onload event
        window.onRecaptchaLoad = () => {
          renderReCaptcha();
        };

        document.head.appendChild(script);
      } else {
        renderReCaptcha();
      }
    };

    const renderReCaptcha = () => {
      if (!isRendered && recaptchaRef.current) {
        window &&
          window.grecaptcha.render(recaptchaRef.current, {
            sitekey: siteKey,
            callback: (token: string) => {
              setToken(token);
            }
          });
        isRendered = true;
      }
    };

    renderCaptcha();

    return () => {
      // Reset isRendered when unmounting
      isRendered = false;
    };
  }, [siteKey]);

  return { recaptchaRef, token };
};

export default useReCaptcha;
