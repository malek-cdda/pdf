// app/api/pages/route.ts
import { globby } from 'globby';
import { join } from 'path';

export async function GET(request: Request) {
  // Get all pages from the src/app directory
  const pagesDir = join(process.cwd(), 'src/app');

  //   remove the api and components directories
  const pages = await globby(['**/*.tsx', '!_*/**', '!api/**', '!components/**'], {
    cwd: pagesDir
  });

  // Sanitize the pages to remove the .tsx extension and index
  const sanitizedPages = pages.map((page: any) => {
    const path = page.replace(/\.(tsx)$/, '').replace(/\/index$/, '');
    return path === '' ? '/' : `/${path}`;
  });

  // Filter out the pages that are not part of the pages directory
  const filteredPages = sanitizedPages
    .filter((page) => page.includes('page') && !page.includes('components'))
    .map((page) => page.replace('/page', ''))
    .map((page) => page.replace(/\/\(dashboard\)/, '')) // Remove /(dashboard) and preceding slash
    .map((page) => (page === '' ? '/' : page)); // Replace empty string with '/'

  // Return the filtered pages
  return new Response(JSON.stringify(filteredPages), {
    status: 200,
    headers: {
      'Content-Type': 'application/json'
    }
  });
}
