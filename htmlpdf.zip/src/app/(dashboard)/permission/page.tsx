'use client';

import Table from '@/components/Table/Table';
import { headCellsProps, rowDataProps } from '@/components/Table/types';
import { alpha, Box, Button, Fab, Stack } from '@mui/material';
import React, { useState } from 'react';
import { CiEdit } from 'react-icons/ci';
import { MdOutlineDeleteOutline } from 'react-icons/md';

import PageHeader from '@/components/PageHeader/PageHeader';
import GlobalModal from '@/components/Modal/GlobalModal';
import HeaderTitle from '@/components/HeaderTitle/HeaderTitle';
import AddEditPermission from './components/AddEditPermission';
import { useDeletePermissionMutation, useGetPermissionsQuery } from './features/permissionApi';
import { useConfirmationModalContext } from '@/providers/ConfirmationModalContext';
const Home = () => {
  const [page, setPage] = useState(10);
  const { data, isSuccesss, isError, isLoading } = useGetPermissionsQuery({
    limit: 1000000000
  });

  const [deletePermission, { isDeleteSuccess, isDeleteError }] = useDeletePermissionMutation();

  const [open, setOpen] = useState(false);

  // single row data delete
  const handleDeleteAction = (row: any) => {
    showConfirmationModal({
      onConfirm: () => handleDelete(row),
      message: `Do you really want to delete this records? This process cannot be undone.`
    });
    // console.log(row, selectedAction);
  };

  const handleDelete = async (data: { uid: any }) => {
    // Your delete logic goes here
    try {
      await deletePermission(data?.uid);
      // closeModal();
    } catch (error) {
      console.log(error);
    } // Close the modal after the delete action
  };
  // confirmation modal for bulk delete
  const { showConfirmationModal, closeModal } = useConfirmationModalContext() as unknown as {
    showModal: boolean;
    closeModal: () => void;
    showConfirmationModal: (props: { onConfirm: () => void; message: string }) => void;
  };

  const headCells: headCellsProps[] = [
    {
      id: 'api_route',
      numeric: false,
      disablePadding: false,
      label: 'api_route',
      option: {
        sortable: false
      }
    },
    {
      id: 'page_route',
      numeric: false,
      disablePadding: false,
      label: 'page_route',
      option: {
        sortable: false
      }
    },

    {
      id: 'description',
      numeric: false,
      disablePadding: false,
      label: 'description',
      option: {
        align: 'left'
      }
    },
    {
      id: 'type',
      numeric: false,
      disablePadding: false,
      label: 'Type',
      option: {
        align: 'left'
      }
    },
    {
      id: 'permission_method',
      numeric: false,
      disablePadding: false,
      label: 'permission_method',
      option: {
        align: 'left'
      },
      render: (value: any) => {
        return <span>{value.permission_method.map((item: any) => item.name).join(', ')}</span>;
      }
    },

    {
      id: 'actions',
      numeric: false,
      disablePadding: false,
      label: 'Actions',
      option: {
        align: 'right'
      },
      render: (row: any) => {
        // console.log("row", row)
        return (
          <Box
            sx={{
              display: 'flex',
              justifyContent: 'end',
              alignItems: 'center',
              width: '100%',
              color: (theme) => (theme.palette.mode === 'light' ? 'title.light' : 'title.dark')
            }}
          >
            <Fab
              size="small"
              sx={{
                color: (theme: any) =>
                  theme.palette.mode === 'light'
                    ? theme?.palette?.secondary?.light
                    : theme?.palette?.secondary?.dark,
                backgroundColor: 'transparent',
                cursor: 'pointer',

                padding: '0px',
                '&:hover': {
                  backgroundColor: (theme: any) =>
                    theme.palette.mode === 'light'
                      ? alpha(theme?.palette?.secondary?.light, 0.4)
                      : alpha(theme?.palette?.secondary?.dark, 0.4)
                }
              }}
            >
              <CiEdit
                fontSize={20}
                onClick={() =>
                  handleOpen({
                    componentType: <AddEditPermission {...{ setOpen }} data={row} isEdit />,
                    title: 'Edit Permission'
                  })
                }
              />
            </Fab>
            <Fab
              size="small"
              sx={{
                color: (theme: any) =>
                  theme.palette.mode === 'light'
                    ? theme?.palette?.error?.light
                    : theme?.palette?.error?.dark,
                backgroundColor: 'transparent',
                cursor: 'pointer',
                '&:hover': {
                  backgroundColor: (theme: any) =>
                    theme.palette.mode === 'light'
                      ? alpha(theme?.palette?.error?.light, 0.4)
                      : alpha(theme?.palette?.error?.dark, 0.4)
                }
              }}
            >
              <MdOutlineDeleteOutline fontSize={20} onClick={() => handleDeleteAction(row)} />
            </Fab>
          </Box>
        );
      }
    }
  ];
  const rowData: rowDataProps[] = [
    {
      id: 1,
      img: '/image/buyer.png',
      route: '/404',
      active: 'Yes',
      type: 'Page',
      permission: 0
    },
    {
      id: 1,
      img: '/image/buyer.png',
      route: '/500',
      active: 'Yes',
      type: 'Page',
      permission: 0
    },
    {
      id: 1,
      img: '/image/buyer.png',
      route: '/colors',
      active: 'Yes',
      type: 'Page',
      permission: 0
    },
    {
      id: 1,
      img: '/image/buyer.png',
      route: '/app/help',
      active: 'Yes',
      type: 'Page',
      permission: 4
    }
  ];

  // states for add/edit modal
  const [componentType, setComponentType] = useState(null);
  const [title, setTitle] = useState('');
  // handlers
  const handleOpen = ({ componentType, title = '' }: { componentType: any; title: string }) => {
    setTitle(title);
    setComponentType(componentType);
    setOpen(true);
  };
  return (
    <>
      <Stack direction="row" justifyContent="space-between" alignItems="center" mb={2}>
        <HeaderTitle
          title="Permissions"
          description="Manage all the agent users here. You can add, edit and delete the agent users."
        />
        <Button
          variant="contained"
          onClick={() =>
            handleOpen({
              componentType: <AddEditPermission {...{ setOpen }} />,
              title: 'Add Permission'
            })
          }
        >
          Add New Permission
        </Button>
      </Stack>
      <Table
        headCells={headCells}
        row={data?.data ? data?.data : data?.filter((item: any) => item.enable)}
        handleOpen={handleOpen}
        searchBar
        isPagination={false}
        setPage={setPage}
        setRowsPerPage={setPage}
        isLoading={isLoading}
        // searchFieldNameItem="description"
        searchFieldNameItem={[
          'api_route',
          'page_route',
          'description',
          'type',
          'permission_method'
        ]}
      />
      {/* <AutoComplete /> */}
      <GlobalModal setOpen={setOpen} open={open} title={title}>
        {/* <div>welcome to back hitman</div> */}
        {componentType}
      </GlobalModal>
    </>
  );
};

export default Home;
