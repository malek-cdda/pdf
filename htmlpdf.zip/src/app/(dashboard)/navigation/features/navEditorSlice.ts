// @Toukir
import type { PayloadAction } from '@reduxjs/toolkit';
import { createAppSlice } from '@/redux/createAppSlice';
import { removeNavItem, updateNavItem } from '../utils';

export interface NavEditorState {
  userRoles: any[];
  positions: any[];
  paths: any;
  navigation: any;
  selectedRole?: any;
  selectedPosition?: any;
  expandNavList: any;
}

const initialState: NavEditorState = {
  userRoles: [],
  positions: [],
  paths: [],
  navigation: [],
  selectedRole: undefined,
  selectedPosition: undefined,
  expandNavList: null
};

// If you are not using async thunks you can use the standalone `createSlice`.
export const navEditorSlice = createAppSlice({
  name: 'navEditor',
  // `createSlice` will infer the state type from the `initialState` argument
  initialState,
  // The `reducers` field lets us define reducers and generate associated actions
  reducers: (create) => ({
    fetchUserRoles: create.reducer((state, action: PayloadAction<any[]>) => {
      state.userRoles = action.payload;
    }),

    fetchPositions: create.reducer((state, action: PayloadAction<any[]>) => {
      state.positions = action.payload;
    }),

    fetchPaths: create.reducer((state, action: PayloadAction<any>) => {
      state.paths = action.payload;
    }),

    // set navigation item in navigation array
    setNavigation: create.reducer((state, action: PayloadAction<any[]>) => {
      state.navigation = action.payload;
    }),

    // update navigation item in navigation array
    updateNavPathItem: create.reducer((state, action: PayloadAction<any>) => {
      state.navigation = updateNavItem(state.navigation, action.payload);
    }),

    // remove navigation item from navigation array
    removeNavPath: create.reducer((state, action: PayloadAction<any>) => {
      state.navigation = removeNavItem(state.navigation, action.payload);
    }),

    // select user role
    selectRole: create.reducer((state, action: PayloadAction<any>) => {
      state.selectedRole = action.payload;
    }),

    // select nav link position
    selectPosition: create.reducer((state, action: PayloadAction<any>) => {
      state.selectedPosition = action.payload;
    }),

    // toggle nav editor accordion
    toggleNavAccordion: create.reducer((state, action: PayloadAction<any>) => {
      state.expandNavList = action.payload;
    })
  }),
  // You can define your selectors here. These selectors receive the slice
  // state as their first argument.
  selectors: {
    navigationList: (state) => state.navigation
    // selectCount: (counter) => counter.value,
    // selectStatus: (counter) => counter.status
  }
});

// Action creators are generated for each case reducer function.
export const {
  fetchUserRoles,
  fetchPaths,
  fetchPositions,
  setNavigation,
  updateNavPathItem,
  removeNavPath,
  selectPosition,
  selectRole,
  toggleNavAccordion
} = navEditorSlice.actions;

// Selectors returned by `slice.selectors` take the root state as their first argument.
export const { navigationList } = navEditorSlice.selectors;
