function removeNavItem(array: any, idToRemove: any) {
  return array.filter((item: any) => {
    if (item.id === idToRemove) {
      return false; // Exclude the item with the specified ID
    } else if (item.children && item.children.length) {
      // Recursively remove the item from children arrays
      item.children = removeNavItem(item.children, idToRemove);
    }
    return true; // Include all other items
  });
}

export default removeNavItem;
