import { Box, Button, Fab, InputBase, alpha } from '@mui/material';
import SyncIcon from '@mui/icons-material/Sync';
import AddIcon from '@mui/icons-material/Add';

import React from 'react';
import NavigationLayout from './NavigationLayout';
import { useSelector } from 'react-redux';
import { useAppDispatch, useAppSelector } from '@/redux/hooks';
import { useFetchPathListQuery } from '../features/navEditorApi';
import ToastAlert from '@/components/common/ToastAlert';
import Loader from '@/components/common/Loader/Loader';
import DataNotAvailabel from '@/components/common/DataNotAvailabel';
import { navigationList, setNavigation } from '../features/navEditorSlice';
import generateUniqueId from '@/utils/generateUniqueId';
import { navPathChecker } from '../utils';

const Paths = () => {
  const dispatch = useAppDispatch();
  const navigation: any = useAppSelector(navigationList);
  const { selectedRole, selectedPosition } = useAppSelector((state: any) => state.navEditor);

  const { data: pathList, isLoading, isError } = useFetchPathListQuery({});

  const handleAddPathToNav = (item: any) => {
    if (!selectedRole || !selectedPosition) {
      alert('Please select role and position');
      return;
    }

    // if permission is already added then return
    if (navPathChecker(navigation, item.id)) {
      alert('Path already added');
    } else {
      dispatch(
        setNavigation([
          ...navigation,
          {
            // id is uniqueid in number by timestamp
            id: generateUniqueId(),
            label: item.page_route,
            icon: null,
            permission: item?.id,
            children: []
          }
        ])
      );
    }
  };

  let content = null;

  if (isError && !isLoading) {
    content = <ToastAlert message="Something went wrong!" />;
  }

  if (!isError && isLoading) {
    content = <Loader />;
  }

  if (!isError && !isLoading && pathList.length === 0) {
    content = <DataNotAvailabel />;
  }

  if (!isError && !isLoading && pathList && pathList.length > 0) {
    content = pathList?.map((path: any, index: number) => (
      <Box
        key={index}
        component={'div'}
        sx={{
          display: 'flex',
          gap: 1,
          alignItems: 'center',
          justifyContent: 'space-between'
        }}
      >
        <InputBase
          defaultValue={path?.page_route}
          sx={{
            width: '100%',
            borderRadius: 1,
            position: 'relative',
            backgroundColor: (theme: any) =>
              theme.palette.mode === 'light'
                ? alpha(theme.palette.common.black, 0.04)
                : 'rgba(255, 255, 255, 0.09)',
            border: '1px solid',
            borderColor: (theme: any) => (theme.palette.mode === 'light' ? '#E0E3E7' : '#2D3843'),
            fontSize: 16,
            padding: '2px 10px',
            transition: (theme: any) =>
              theme.transitions.create(['border-color', 'background-color', 'box-shadow']),
            '&:focus': {
              boxShadow: (theme: any) => `${alpha(theme.palette.primary.main, 0.25)} 0 0 0 0.2rem`,
              borderColor: (theme: any) => theme.palette.primary.main
            }
          }}
        />
        <Fab
          sx={{
            height: '38px',
            width: '38px',
            borderRadius: 1,
            backgroundColor: (theme: any) =>
              theme.palette.mode === 'light'
                ? alpha(theme?.palette?.primary?.light, 0.5)
                : alpha(theme?.palette?.primary?.dark, 0.5),
            '&:hover': {
              backgroundColor: (theme: any) =>
                theme.palette.mode === 'light'
                  ? alpha(theme?.palette?.primary?.light, 0.7)
                  : alpha(theme?.palette?.primary?.dark, 0.7)
            },
            color: 'primary.contrastText'
          }}
          onClick={() => handleAddPathToNav(path)}
        >
          <AddIcon />
        </Fab>
      </Box>
    ));
  }

  return (
    <NavigationLayout title="Paths">
      {/* Paths */}
      <Box
        component={'div'}
        sx={{
          pt: 0.5,
          display: 'flex',
          gap: 0.5,
          alignItems: 'center',
          justifyContent: 'space-between'
        }}
      >
        <InputBase
          sx={{
            width: '100%',
            borderRadius: 1,
            position: 'relative',
            backgroundColor: (theme: any) =>
              theme.palette.mode === 'light'
                ? alpha(theme.palette.common.black, 0.04)
                : 'rgba(255, 255, 255, 0.09)',
            border: '1px solid',
            borderColor: (theme: any) => (theme.palette.mode === 'light' ? '#E0E3E7' : '#2D3843'),
            fontSize: 16,
            padding: '2px 10px',
            transition: (theme: any) =>
              theme.transitions.create(['border-color', 'background-color', 'box-shadow']),
            '&:focus': {
              boxShadow: (theme: any) => `${alpha(theme.palette.primary.main, 0.25)} 0 0 0 0.2rem`,
              borderColor: (theme: any) => theme.palette.primary.main
            }
          }}
          placeholder="Search paths"
        />
        <Button variant="contained" sx={{ height: '38px', width: '38px', borderRadius: 1 }}>
          <SyncIcon />
        </Button>
      </Box>
      {/* contents here */}
      {content}
    </NavigationLayout>
  );
};

export default Paths;
