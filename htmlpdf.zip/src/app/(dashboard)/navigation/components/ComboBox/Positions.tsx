import { Autocomplete, Chip, TextField } from '@mui/material';
import React from 'react';
import { useAppDispatch, useAppSelector } from '@/redux/hooks';
import { selectPosition } from '../../features/navEditorSlice';

const Positions = () => {
  const dispatch = useAppDispatch();
  const positions = useAppSelector((state: any) => state.navEditor?.positions);

  const selectedPosition = useAppSelector((state: any) => state.navEditor?.selectedPosition);
  return (
    <>
      <Autocomplete
        disablePortal
        id="combo-box"
        options={positions || []}
        size="small"
        sx={{
          width: 300,
          '& .MuiOutlinedInput-root': {
            '&:hover fieldset': {
              borderColor: 'primary.main'
            }
          }
        }}
        onChange={(event, newValue: any) => {
          dispatch(selectPosition(newValue?.value));
        }}
        // isOptionEqualToValue={(option, value) => option?.value === value?.value}
        renderTags={(value, getTagProps) =>
          value.map((option, index) => (
            <>
              <Chip
                variant="outlined"
                label={option}
                {...getTagProps({ index })}
                // disabled={disabled}
              />
            </>
          ))
        }
        renderInput={(params) => <TextField {...params} label="Positions" />}
      />
    </>
  );
};

export default Positions;
