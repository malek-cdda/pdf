import React from 'react';
import { TbDragDrop } from 'react-icons/tb';
const cssCenter = {
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  overflow: 'hidden'
};
const handlerStyles = {
  width: '2rem',
  height: '100%',
  cursor: 'pointer',

  borderRight: '0px solid Gainsboro'
};
const Handler = () => {
  return (
    <div style={{ ...cssCenter, ...handlerStyles }}>
      <TbDragDrop style={{ cursor: 'move' }} />
    </div>
  );
};

export default Handler;
