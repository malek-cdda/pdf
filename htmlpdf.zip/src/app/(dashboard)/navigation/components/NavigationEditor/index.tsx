// @toukir

import { Button, CircularProgress, Stack } from '@mui/material';
import React, { useEffect, useState } from 'react';
import dynamic from 'next/dynamic';
import SaveIcon from '@mui/icons-material/Save';
import SyncIcon from '@mui/icons-material/Sync';
import 'react-nestable/dist/styles/index.css';
import NavigationLayout from '../NavigationLayout';
import UserRoles from '../ComboBox/UserRoles';
import Positions from '../ComboBox/Positions';
const Nestable = dynamic(() => import('react-nestable'), { ssr: false });
import RenderItem from './RenderItem';
import Collapser from './Collapser';
import Handler from './Handler';
import {
  navEditorApi,
  useFetchDraggableNavListQuery,
  useUpdateNavigationsMutation
} from '../../features/navEditorApi';
import { handleUpdateNavigation, recursiveFind } from '../../utils';
import { useAppDispatch, useAppSelector } from '@/redux/hooks';
import DataNotAvailabel from '@/components/common/DataNotAvailabel';
import ToastAlert from '@/components/common/ToastAlert';
import Loader from '@/components/common/Loader/Loader';
import { navigationList, setNavigation } from '../../features/navEditorSlice';
import NestableComponent from './NestableComponent';

const navigationsData = [
  {
    id: 1,
    label: 'Users',
    icon: null,
    index: 1,
    permission: 2,
    children: [
      {
        id: 2,
        label: 'Agents',
        icon: null,
        index: 2,
        permission: 2,
        children: [
          {
            id: 6,
            label: 'Buyers',
            icon: null,
            index: 3,
            permission: 2,
            children: null
          },
          {
            id: 7,
            label: 'Toukirs',
            icon: null,
            index: 4,
            permission: 2,
            children: null
          },
          {
            id: 8,
            label: 'Toukirs',
            icon: null,
            index: 5,
            permission: 2,
            children: null
          }
        ]
      }
    ]
  }
];
const NavigationEditor = () => {
  const dispatch = useAppDispatch();
  const { paths, selectedRole, selectedPosition } = useAppSelector((state: any) => state.navEditor);
  const navigation = useAppSelector(navigationList);

  // fetch navigation list
  const {
    data: navList,
    isLoading,
    error,
    isError,
    isSuccess
  } = useFetchDraggableNavListQuery(
    {
      roleId: selectedRole?.uid,
      position: selectedPosition
    },
    { skip: !selectedRole || !selectedPosition }
  );

  //update navigation
  const [updateNavigations, { isSuccess: updateSuccess }] = useUpdateNavigationsMutation();

  // after selected role and position fetch navigation list
  useEffect(() => {
    if (selectedRole && selectedPosition) {
      // fetch navigation list
      navEditorApi.endpoints.fetchDraggableNavList.initiate({
        roleId: selectedRole.uid,
        position: selectedPosition
      });
    }
  }, [selectedRole, selectedPosition]);

  //handle save nav
  const handleSave = () => {
    updateNavigations({
      roleId: selectedRole.uid,
      position: selectedPosition,
      data: navigation
    });
  };

  const handleReset = () => {
    // setNavigation(navigationsData);
  };

  let content;

  if (isError && !isLoading) {
    content = <ToastAlert message="Something went wrong!" />;
  }

  if (!isError && isLoading) {
    content = <Loader />;
  }

  if (!isError && !isLoading && navigation.length === 0) {
    content = <DataNotAvailabel />;
  }

  if (!isError && !isLoading && navigation && navigation.length > 0 && navigation[0].id) {
    content = <NestableComponent navigation={navigation} />;
  }

  return (
    <NavigationLayout
      title="Navigation Editor"
      actions={
        // header actions for navigation editor
        <Stack direction="row" alignItems={'center'} spacing={2} pr={3}>
          <Stack direction="row" spacing={2} justifyContent={'space-between'} alignItems="center">
            <Stack direction="row" spacing={2}>
              <UserRoles />
              <Positions />
            </Stack>
          </Stack>
          <Stack direction="row" spacing={2}>
            <Button
              onClick={handleReset}
              variant="contained"
              sx={{ borderRadius: 1, display: 'flex', gap: '5px', px: 1 }}
            >
              <SyncIcon />
              Reset
            </Button>
            <Button
              variant="contained"
              color="success"
              sx={{ borderRadius: 1 }}
              onClick={handleSave}
            >
              <SaveIcon />
            </Button>
          </Stack>
        </Stack>
      }
    >
      {content}
    </NavigationLayout>
  );
};

export default NavigationEditor;
