import React from 'react';
import { alpha, styled } from '@mui/material/styles';

import ArrowForwardIosSharpIcon from '@mui/icons-material/ArrowForwardIosSharp';
import MuiAccordion, { AccordionProps } from '@mui/material/Accordion';
import MuiAccordionSummary, { AccordionSummaryProps } from '@mui/material/AccordionSummary';
import MuiAccordionDetails from '@mui/material/AccordionDetails';
import { useDispatch, useSelector } from 'react-redux';
import { Stack, Typography } from '@mui/material';
import NavItem from './NavItem';
import MuiIconWrapper from '@/components/IconHandler/MuiIconWrapper';
import { toggleNavAccordion } from '../../features/navEditorSlice';

const Accordion = styled((props: AccordionProps) => (
  <MuiAccordion disableGutters elevation={0} square {...props} />
))(({ theme }) => ({
  border: `1px solid ${theme.palette.divider}`,
  '&:not(:last-child)': {
    borderBottom: 0
  },
  '&::before': {
    display: 'none'
  }
}));

const AccordionSummary = styled((props: AccordionSummaryProps) => (
  <MuiAccordionSummary
    expandIcon={<ArrowForwardIosSharpIcon sx={{ fontSize: '0.9rem' }} />}
    {...props}
  />
))(({ theme }) => ({
  backgroundColor:
    theme.palette.mode === 'dark' ? 'rgba(255, 255, 255, .05)' : 'rgba(0, 0, 0, .03)',
  flexDirection: 'row',
  '& .MuiAccordionSummary-expandIconWrapper.Mui-expanded': {
    transform: 'rotate(90deg)'
  }
  // '& .MuiAccordionSummary-content': {
  //   cursor: 'move'
  // }
}));

const AccordionDetails = styled(MuiAccordionDetails)(({ theme }) => ({
  padding: 0,
  borderTop: '1px solid rgba(0, 0, 0, .125)'
}));

type NavigationItemProps = {
  item: any;
  selectedRole: any;
  setNavigation: any;
  selectedPosition: any;
  expanded: any;
  setExpanded: any;
};

const CollapsableNavItem = ({ item }: NavigationItemProps | any) => {
  const dispatch = useDispatch();
  const expandNavListId = useSelector((state: any) => state.navEditor.expandNavList);
  console.log(item, 'item');
  return (
    <Accordion
      expanded={expandNavListId === item?.id}
      onChange={() => dispatch(toggleNavAccordion(item?.id === expandNavListId ? null : item?.id))}
    >
      <AccordionSummary aria-controls="panel1d-content" id="panel1d-header">
        <Stack
          direction="row"
          spacing={2}
          alignItems="center"
          sx={{
            color: (theme: any) =>
              theme.palette.mode === 'light'
                ? alpha(theme.palette.title.light, 0.9)
                : alpha(theme.palette.title.dark, 0.9)
          }}
        >
          <MuiIconWrapper>{item?.icon}</MuiIconWrapper>
          <Typography variant="h6">{item?.label}</Typography>
        </Stack>
      </AccordionSummary>
      <AccordionDetails>
        <NavItem item={item} />
      </AccordionDetails>
    </Accordion>
  );
};

export default CollapsableNavItem;
