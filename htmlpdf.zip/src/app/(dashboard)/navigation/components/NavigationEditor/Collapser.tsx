import React from 'react';
import { BiMinus, BiPlus } from 'react-icons/bi';
const cssCenter = {
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  overflow: 'hidden'
};
const handlerStyles = {
  width: '2rem',
  height: '100%',
  cursor: 'pointer',

  borderRight: '0px solid Gainsboro'
};
const Collapser = ({ isCollapsed }: any) => {
  return (
    <div style={{ ...cssCenter, ...handlerStyles }}>{isCollapsed ? <BiPlus /> : <BiMinus />}</div>
  );
};

export default Collapser;
