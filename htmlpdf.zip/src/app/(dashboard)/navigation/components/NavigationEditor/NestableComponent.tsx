import React, { useEffect } from 'react';
import Nestable from 'react-nestable';
import RenderItem from './RenderItem';
import Handler from './Handler';
import Collapser from './Collapser';
import { useAppDispatch } from '@/redux/hooks';
import { setNavigation } from '../../features/navEditorSlice';

const NestableComponent = ({ navigation }: any) => {
  const dispatch = useAppDispatch();

  useEffect(() => {}, [navigation]);
  return (
    <Nestable
      items={navigation}
      renderItem={RenderItem}
      handler={<Handler />}
      renderCollapseIcon={({ isCollapsed }) => <Collapser isCollapsed={isCollapsed} />}
      // collapsed={collapseAll}
      onChange={(items: any) => dispatch(setNavigation(items?.items))}
    />
  );
};

export default NestableComponent;
