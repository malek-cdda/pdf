import { Box, Stack, alpha } from '@mui/material';
import React from 'react';
import CollapsableNavItem from './CollapsableNavItem';

const RenderItem = (props: any) => {
  const { item, index, collapseIcon, handler, label } = props;

  return (
    <Stack direction={'row'} width={'100%'}>
      <Box
        display={'flex'}
        sx={{
          background: (theme: any) =>
            theme.palette.mode === 'light'
              ? alpha(theme.palette.primary.light, 0.3)
              : alpha(theme.palette.primary.dark, 0.3)
        }}
      >
        {handler}
        {collapseIcon}
      </Box>
      <Box width={'100%'}>
        <CollapsableNavItem item={item} />
      </Box>
    </Stack>
  );
};

export default RenderItem;
