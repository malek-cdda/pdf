// @Toukir
import { Box, List, Stack, Typography, alpha } from '@mui/material';
import React from 'react';
import NavigationLayout from './NavigationLayout';
import { useAppDispatch, useAppSelector } from '@/redux/hooks';
import { selectRole } from '../features/navEditorSlice';

const UserRoles = () => {
  const dispatch = useAppDispatch();
  const userRoles = useAppSelector((state: any) => state.navEditor?.userRoles);
  const selectedRole = useAppSelector((state: any) => state.navEditor?.selectedRole);
  return (
    <NavigationLayout title="User Roles">
      {userRoles?.map((role: any, index: number) => (
        <List
          onClick={() => {
            dispatch(selectRole(role));
          }}
          key={index}
          sx={{
            bgcolor: (theme: any) =>
              theme.palette.mode === 'light'
                ? role?._id === selectedRole?._id
                  ? alpha(theme?.palette?.primary?.light, 1)
                  : alpha(theme?.palette?.primary?.light, 0.2)
                : role?._id === selectedRole?._id
                  ? alpha(theme?.palette?.primary?.dark, 1)
                  : alpha(theme?.palette?.primary?.dark, 0.2),

            color: (theme: any) =>
              role?._id === selectedRole?._id
                ? theme.palette.primary.contrastText
                : theme.palette.subtitle.main,

            borderRadius: 1,
            px: 2,
            py: 0.5,
            '&:hover': {
              cursor: 'pointer',
              bgcolor: (theme: any) =>
                theme.palette.mode === 'light'
                  ? alpha(theme?.palette?.primary?.light, 0.8)
                  : alpha(theme?.palette?.primary?.dark, 0.8),
              color: 'primary.contrastText'
            }
          }}
        >
          {role?.label}
        </List>
      ))}
    </NavigationLayout>
  );
};

export default UserRoles;
