import { List, alpha } from '@mui/material';
import React from 'react';
import NavigationLayout from './NavigationLayout';
import { useAppDispatch, useAppSelector } from '@/redux/hooks';
import { selectPosition } from '../features/navEditorSlice';
// const positions = [
//   'Side nav top',
//   'Side nav bottom',
//   'Top nav left',
//   'Top nav right',
//   'Footer left',
//   'Footer right',
//   'Settings',
//   'Profile menu',
//   'Core Settings'
// ];
const Positions = () => {
  const dispatch = useAppDispatch();
  const positions = useAppSelector((state: any) => state.navEditor?.positions);
  const selectedPosition = useAppSelector((state: any) => state.navEditor?.selectedPosition);
  return (
    <NavigationLayout title="Positions">
      {positions?.data?.map((position: any, index: number) => (
        <List
          onClick={() => {
            dispatch(selectPosition(position));
          }}
          key={index}
          sx={{
            bgcolor: (theme: any) =>
              theme.palette.mode === 'light'
                ? position?.value === selectedPosition?.value
                  ? alpha(theme?.palette?.primary?.light, 1)
                  : alpha(theme?.palette?.primary?.light, 0.2)
                : position?.value === selectedPosition?.value
                  ? alpha(theme?.palette?.primary?.dark, 1)
                  : alpha(theme?.palette?.primary?.dark, 0.2),

            color: (theme: any) =>
              position?.value === selectedPosition?.value
                ? theme.palette.primary.contrastText
                : theme.palette.subtitle.main,

            borderRadius: 1,
            px: 2,
            py: 0.5,

            '&:hover': {
              cursor: 'pointer',
              bgcolor: (theme: any) =>
                theme.palette.mode === 'light'
                  ? alpha(theme?.palette?.primary?.light, 0.8)
                  : alpha(theme?.palette?.primary?.dark, 0.8),
              color: 'primary.contrastText'
            }
          }}
        >
          {position?.label}
        </List>
      ))}
    </NavigationLayout>
  );
};

export default Positions;
