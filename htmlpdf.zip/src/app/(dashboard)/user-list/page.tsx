'use client';
import Table from '@/components/Table/Table';
import { headCellsProps, rowDataProps } from '@/components/Table/types';
import { alpha, Avatar, Badge, Box, Fab, Typography } from '@mui/material';
import React from 'react';
import { BsThreeDotsVertical } from 'react-icons/bs';
import { GrView } from 'react-icons/gr';
import { MdOutlineDeleteOutline } from 'react-icons/md';

const page = () => {
  const handleDeleteAction = (row: any) => {
    window.confirm('Are you sure you want to delete this row?');
  };
  const handleBulkDelete = (data: any) => {
    console.log(data);
  };
  const headCells: headCellsProps[] = [
    {
      id: 'name',
      numeric: false,
      disablePadding: false,
      label: 'USER',
      option: {
        sortable: false
      },
      render: (user: rowDataProps) => (
        <Box
          display="flex"
          alignItems="center"
          color={(theme: any) =>
            theme.palette.mode === 'light'
              ? theme?.palette?.title?.light
              : theme?.palette?.title?.dark
          }
        >
          <Avatar sx={{ width: 38, height: 38 }} alt="Remy Sharp" src={user?.img} />
          <Box marginLeft="10px" display="flex" flexDirection="column">
            {' '}
            <Typography
              sx={{
                fontSize: '13px'
              }}
            >
              {user?.name}
            </Typography>
            <Typography
              sx={{
                fontSize: '13px'
              }}
            >
              {user?.email}
            </Typography>
          </Box>
        </Box>
      )
    },
    {
      id: 'role',
      numeric: false,
      disablePadding: false,
      label: 'ROLE',
      render: (user: rowDataProps) => (
        <Box display="flex" alignItems="center">
          <Avatar sx={{ width: 24, height: 24 }} alt="Remy Sharp" src={user?.img} />
          <Box marginLeft="10px" display="flex" flexDirection="column">
            {' '}
            <Typography
              sx={{
                fontSize: '13px',
                color: (theme: any) =>
                  theme.palette.mode === 'light'
                    ? theme?.palette?.title?.light
                    : theme?.palette?.title?.dark
              }}
            >
              {user?.role}
            </Typography>
          </Box>
        </Box>
      )
    },
    {
      id: 'plan',
      numeric: false,
      disablePadding: false,
      label: 'PLAN'
    },
    {
      id: 'billing',
      numeric: false,
      disablePadding: false,
      label: 'BILLING'
    },
    {
      id: 'status',
      numeric: false,
      disablePadding: false,
      label: 'STATUS',
      render: (user: rowDataProps) => (
        <Badge
          badgeContent={user?.status}
          color={user?.status === 'Active' ? 'success' : 'error'}
          sx={{
            margin: '0px 0px 0px 25px',
            '& .MuiBadge-dot': {
              width: 10,
              height: 10,
              borderRadius: '50%'
            }
          }}
        />
      )
    },

    {
      id: 'actions',
      numeric: false,
      disablePadding: false,
      label: 'ACTIONS',
      option: {
        align: 'right'
      },
      render: (row: any) => (
        <Box
          sx={{
            display: 'flex',
            justifyContent: 'end',
            alignItems: 'center',
            width: '100%',
            color: (theme: any) =>
              theme.palette.mode === 'light'
                ? theme?.palette?.title?.light
                : theme?.palette?.title?.dark
          }}
        >
          <Fab
            size="small"
            sx={{
              color: (theme: any) =>
                theme.palette.mode === 'light'
                  ? theme?.palette?.secondary?.light
                  : theme?.palette?.secondary?.dark,
              backgroundColor: 'transparent',
              cursor: 'pointer',
              '&:hover': {
                backgroundColor: (theme: any) =>
                  theme.palette.mode === 'light'
                    ? alpha(theme?.palette?.secondary?.light, 0.4)
                    : alpha(theme?.palette?.secondary?.dark, 0.4)
              }
            }}
          >
            <GrView fontSize={20} />
          </Fab>
          <Fab
            size="small"
            sx={{
              color: (theme: any) =>
                theme.palette.mode === 'light'
                  ? theme?.palette?.error?.light
                  : theme?.palette?.error?.dark,
              backgroundColor: 'transparent',
              cursor: 'pointer',
              '&:hover': {
                backgroundColor: (theme: any) =>
                  theme.palette.mode === 'light'
                    ? alpha(theme?.palette?.error?.light, 0.4)
                    : alpha(theme?.palette?.error?.dark, 0.4)
              }
            }}
            onClick={() => handleDeleteAction(row)}
          >
            <MdOutlineDeleteOutline fontSize={20} />
          </Fab>
          <Fab
            size="small"
            sx={{
              color: (theme: any) =>
                theme.palette.mode === 'light'
                  ? theme?.palette?.secondary?.light
                  : theme?.palette?.secondary?.dark,
              backgroundColor: 'transparent',
              cursor: 'pointer',

              padding: '0px',
              '&:hover': {
                backgroundColor: (theme: any) =>
                  theme.palette.mode === 'light'
                    ? alpha(theme?.palette?.secondary?.light, 0.4)
                    : alpha(theme?.palette?.secondary?.dark, 0.4)
              }
            }}
            // onClick={() => handleOpen()}
          >
            <BsThreeDotsVertical fontSize={20} />
          </Fab>
        </Box>
      )
    }
  ];
  const rowData: rowDataProps[] = [
    {
      id: 1,
      img: '/image/buyer.png',
      email: '@tbruntjeni@sitemeter.com',
      name: 'Travus Bruntjen',
      role: 'Admin',
      plan: 'Enterprise',
      billing: 'Manual - Cash',
      status: 'Active',
      join: '', // Add the missing property 'join'
      agent: '', // Add the missing property 'agent'
      buyer: '' // Add the missing property 'buyer'
    },
    {
      id: 2,
      img: '/image/buyer.png',
      email: '@shebblethwaite10@arizona.edu',
      name: 'Skip Hebblethwaite',
      role: 'Admin',
      plan: 'Company',
      billing: 'Manual - Cash',
      status: 'Inactive',
      join: '', // Add the missing property 'join'
      agent: '', // Add the missing property 'agent'
      buyer: '' // Add the missing property 'buyer'
    },
    {
      id: 3,
      img: '/image/buyer.png',
      email: '@remerw@blogtalkradio.com',
      name: ' Rochette Emer',
      role: 'Admin',
      plan: 'Basic',
      billing: 'Auto Debit',
      status: 'Active',
      join: '', // Add the missing property 'join'
      agent: '', // Add the missing property 'agent'
      buyer: '' // Add the missing property 'buyer'
    }
  ];
  return (
    <div>
      <Table
        headCells={headCells}
        row={rowData}
        // handleOpen={handleOpen}
        filterName
        searchBar
        // dateRange
        // gridView
        // isCheckbox
        handleBulkDelete={handleBulkDelete}
      />
    </div>
  );
};

export default page;
