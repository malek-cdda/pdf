'use client';

import React, { useEffect } from 'react';
import UrlHeader from './components/UrlHeader';
import { Box, Typography } from '@mui/material';
import Options from './components/Options';
import Response from './components/Response';
import { useDispatch, useSelector } from 'react-redux';
import { handleApiCall } from '@/utils/fetchApi';
import { addResponse } from './features/playgroundSlice';

const Main = ({ data }: any) => {
  const dispatch = useDispatch();
  const state = useSelector((state: any) => state.playground) || {};

  useEffect(() => {
    if (state) {
      // eslint-disable-next-line react-hooks/exhaustive-deps
      data = state;
    }
  }, [data, state]);

  console.log('state', state);

  // HANDLE API CALL
  const handleSubmit = async () => {
    try {
      const response = await handleApiCall(state);
      console.log('Response:', response);
      dispatch(addResponse(response));
    } catch (error: any) {
      console.error('Error:', error.message);
    }
  };

  return (
    <Box
      display="flex"
      flexDirection="column"
      justifyContent="space-between"
      height="100%"
      padding="10px"
      sx={{
        backgroundColor: (theme: any) =>
          theme?.palette?.mode === 'light'
            ? theme?.palette?.card?.light
            : theme?.palette?.card?.dark,
        borderRadius: '5px'
      }}
    >
      <Box>
        <Typography variant="h4" component="h1" gutterBottom>
          Api Playground
        </Typography>
        <UrlHeader handleSubmit={handleSubmit} />
        <Options />
      </Box>
      <Response />
    </Box>
  );
};

export default Main;
