import React from 'react';
import Main from './Main';
import { Box, Stack } from '@mui/material';
import ApiSidebar from './components/sidebar/ApiSidebar';
import Document from './components/document/Document';

const page = () => {
  const data = null;
  return (
    <Stack
      direction={'row'}
      spacing={0}
      height={`calc(100vh - 140px)`}
      // border={'1px solid gray'}
      borderRadius={'5px'}
      boxShadow={1}
    >
      <Box width={'16%'} borderRight={'1px solid gray'}>
        <ApiSidebar />
      </Box>
      <Box width={'46%'} borderRight={'1px solid gray'} overflow={'auto'}>
        <Document />
      </Box>
      <Box width={'38%'}>
        <Main data={data} />
      </Box>
    </Stack>
  );
};

export default page;
