import { Autocomplete, Stack, TextField } from '@mui/material';
import React from 'react';

const AutoCompleteField = () => {
  return (
    <Autocomplete
      //   fullWidth={true}
      sx={{
        width: '30%'
      }}
      id="free-solo-demo"
      freeSolo
      options={top100Films.map((option) => option.title)}
      renderInput={(params) => (
        <TextField
          {...params}
          placeholder=""
          inputProps={{
            sx: { height: '10px' }
          }}
        />
      )}
    />
  );
};

export default AutoCompleteField;
const top100Films = [
  { title: 'The Shawshank Redemption', year: 1994 },
  { title: 'The Godfather', year: 1972 }
];
