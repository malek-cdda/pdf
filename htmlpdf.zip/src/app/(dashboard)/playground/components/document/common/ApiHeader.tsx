import { alpha, Box } from '@mui/material';
import React from 'react';

const ApiHeader = ({ children, ...rest }: any) => {
  return (
    <Box
      fontSize={'30px'}
      color={(theme: any) =>
        theme.palette.mode === 'light'
          ? alpha(theme.palette.title.light, 0.9)
          : alpha(theme.palette.title.dark, 0.9)
      }
      {...rest}
    >
      {children}
    </Box>
  );
};

export default ApiHeader;
