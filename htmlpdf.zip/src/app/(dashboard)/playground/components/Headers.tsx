import { useEffect, useState } from 'react';
import KeyValueInputs from './KeyValue';
import { Box, Typography } from '@mui/material';

const Headers = () => {
  const [headersValue, setHeadersValue] = useState<Array<{ key: string; value: string }>>([
    {
      key: '',
      value: ''
    }
  ]);
  return (
    <Box>
      <KeyValueInputs title="Header" inputs={headersValue} setInputs={setHeadersValue} />
    </Box>
  );
};

export default Headers;
