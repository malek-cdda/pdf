import { useEffect, useState } from 'react';
import KeyValueInputs from './KeyValue';
import { Typography } from '@mui/material';

const Params = () => {
  const [paramValue, setParamValue] = useState<Array<{ key: string; value: string }>>([
    {
      key: '',
      value: ''
    }
  ]);
  return (
    <div>
      <KeyValueInputs title="Query params" inputs={paramValue} setInputs={setParamValue} />
    </div>
  );
};

export default Params;
