import { TextField, Button, Box, Stack, Typography } from '@mui/material';
import { useState } from 'react';
import { BiPlus, BiMinus } from 'react-icons/bi';

export interface State {
  inputs: Array<{ key: string; value: string }>;
  setInputs: (value: Array<{ key: string; value: string }>) => void;
  title: string;
}

const KeyValueInputs = ({ inputs, setInputs, title }: State) => {
  const [key, setKey] = useState('');
  const [value, setValue] = useState('');

  const addInput = () => {
    setInputs([...inputs, { key, value }]);
    setKey('');
    setValue('');
  };

  const removeInput = (index: number) => {
    setInputs(inputs.filter((_, i) => i !== index));
  };

  return (
    <Box>
      <Stack spacing={2} direction="row" justifyContent="space-between" alignItems="center" mb={1}>
        <Typography
          sx={{
            fontSize: '14px',
            fontWeight: 'bold',
            margin: '5px 0'
          }}
        >
          {title}
        </Typography>
        <Button variant="contained" color="primary" onClick={addInput}>
          <BiPlus />
        </Button>
      </Stack>
      <Stack spacing={2}>
        {inputs?.map((pair, index) => (
          <Box
            key={index}
            sx={{
              display: 'flex',
              width: '100%',
              gap: '10px'
            }}
          >
            <TextField
              sx={{
                width: '47%'
              }}
              fullWidth
              size="small"
              label="Key"
              value={pair.key}
              inputProps={{ style: { fontSize: 12 } }}
              InputLabelProps={{ style: { fontSize: 12 } }}
              onChange={(e) =>
                setInputs(inputs.map((o, i) => (i === index ? { ...o, key: e.target.value } : o)))
              }
            />
            <TextField
              sx={{
                width: '47%'
              }}
              fullWidth
              size="small"
              label="Value"
              value={pair.value}
              inputProps={{ style: { fontSize: 12 } }}
              InputLabelProps={{ style: { fontSize: 12 } }}
              onChange={(e) =>
                setInputs(inputs.map((o, i) => (i === index ? { ...o, value: e.target.value } : o)))
              }
            />
            <Button variant="contained" color="secondary" onClick={() => removeInput(index)}>
              <BiMinus />
            </Button>
          </Box>
        ))}
      </Stack>
    </Box>
  );
};

export default KeyValueInputs;
