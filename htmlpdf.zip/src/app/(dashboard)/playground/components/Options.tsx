import React from 'react';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Box from '@mui/material/Box';
import Params from './Params';
import Headers from './Headers';
import Body from './Body';
import CustomTabPanel from '../../profile/components/rightside/CustomTabPanel';

const options = [
  {
    label: 'Params',
    value: 'params'
  },
  {
    label: 'Headers',
    value: 'headers'
  },
  {
    label: 'Body',
    value: 'body'
  },
  {
    label: 'Authorization',
    value: 'authorization'
  }
];

const Options = () => {
  const [value, setValue] = React.useState(0);

  const handleChange = (event: React.SyntheticEvent, newValue: number) => {
    setValue(newValue);
  };

  return (
    <Box sx={{ width: '100%' }}>
      <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
        <Tabs value={value} onChange={handleChange}>
          {options.map((option, index) => (
            <Tab key={index} label={option.label} />
          ))}
        </Tabs>
      </Box>
      <CustomTabPanel value={value} index={0}>
        <Params />
      </CustomTabPanel>
      <CustomTabPanel value={value} index={1}>
        <Headers />
      </CustomTabPanel>
      <CustomTabPanel value={value} index={2}>
        <Body />
      </CustomTabPanel>
      {/* <CustomTabPanel value={value} index={3}>
        Item Four
      </CustomTabPanel> */}
    </Box>
  );
};

export default Options;
