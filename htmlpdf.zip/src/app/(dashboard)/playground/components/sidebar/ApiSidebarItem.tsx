import {
  Badge,
  Box,
  Collapse,
  List,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Typography,
  alpha
} from '@mui/material';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import React, { useState } from 'react';
import KeyboardArrowRightIcon from '@mui/icons-material/KeyboardArrowRight';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
type Props = {
  item: any;
};
const ApiSidebarItem = ({ item }: Props) => {
  const pathName = usePathname();
  const [open, setOpen] = useState(true);
  console.log(item?.sidebarData?.method);
  return item?.name ? (
    <>
      {/* <ListItemButton
        onClick={() => setOpen(!open)}
        
        sx={{
          '&: hover': {
            backgroundColor: (theme) => alpha(theme.palette.primary.main, 0.4)
          },
          padding: '3px 0px',
          display: 'flex',
          justifyContent: 'center'
          // paddingX: '20px'
        }}
      >
        <ListItemIcon
          sx={{
            color: (theme: any) =>
              theme.palette.mode === 'light'
                ? alpha(theme.palette.title.light, 0.9)
                : alpha(theme.palette.title.dark, 0.9)
          }}
        >
          {item.child && <>{!open ? <KeyboardArrowRightIcon /> : <KeyboardArrowDownIcon />}</>}
        </ListItemIcon>
        <ListItemText
          disableTypography
          primary={
            <Typography
              sx={{
                paddingY: '2px 1px',
                color: (theme: any) =>
                  theme.palette.mode === 'light'
                    ? alpha(theme?.palette?.title?.light, 0.9)
                    : alpha(theme?.palette?.title?.dark, 0.9),
                fontWeight: 600
              }}
            >
              {item?.sidebarProps?.displayText && item?.sidebarProps?.displayText}
            </Typography>
          }
        />
        {item?.sidebarProps?.method && (
          <Badge
            color="primary"
            variant="dot"
            invisible={pathName !== item?.path}
            sx={{ marginLeft: 'auto' }}
          >
            {item?.sidebarProps?.method}
          </Badge>
        )}
      </ListItemButton> */}
      <ListItemButton
        onClick={() => setOpen(!open)}
        component={Link}
        href={item.path}
        sx={{
          '&: hover': {
            backgroundColor: (theme) => alpha(theme.palette.primary.main, 0.4)
          },
          padding: '2px 4px',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          borderRadius: '8px'
        }}
      >
        <Box>
          <ListItemIcon
            sx={{
              color: (theme: any) =>
                theme.palette.mode === 'light'
                  ? alpha(theme.palette.title.light, 0.9)
                  : alpha(theme.palette.title.dark, 0.9),
              display: 'flex',
              justifyContent: 'flex-start',
              alignItems: 'center'
            }}
          >
            {item.child && <>{!open ? <KeyboardArrowRightIcon /> : <KeyboardArrowDownIcon />}</>}
            <ListItemText
              disableTypography
              primary={
                <Typography
                  sx={{
                    // paddingY: '2px 1px',
                    color: (theme: any) =>
                      theme.palette.mode === 'light'
                        ? alpha(theme?.palette?.title?.light, 0.9)
                        : alpha(theme?.palette?.title?.dark, 0.9),
                    fontWeight: 600,
                    fontSize: '14px'
                  }}
                >
                  {item?.sidebarProps?.displayText && item?.sidebarProps?.displayText}
                </Typography>
              }
            />
          </ListItemIcon>
        </Box>

        <ListItemIcon
          sx={{
            color: (theme: any) =>
              theme.palette.mode === 'light'
                ? alpha(theme.palette.title.light, 0.9)
                : alpha(theme.palette.title.dark, 0.9)
          }}
        >
          {item?.sidebarProps?.method ? (
            <Badge
              variant="dot"
              invisible={pathName !== item?.path}
              sx={{
                marginLeft: 'auto',
                fontSize: '12px',
                padding: '1px 12px',
                borderRadius: '16px',
                color: (theme: any) =>
                  theme.palette.mode === 'light'
                    ? alpha(theme?.palette?.title?.light, 0.9)
                    : alpha(theme?.palette?.title?.dark, 0.9),
                background: (theme) => alpha(theme?.palette?.primary?.main, 0.4)
              }}
            >
              {item?.sidebarProps?.method}
            </Badge>
          ) : (
            <Box
              sx={{
                marginLeft: 'auto',
                fontSize: '12px',
                padding: '1px 12px',
                borderRadius: '16px',
                color: (theme: any) =>
                  theme.palette.mode === 'light'
                    ? alpha(theme?.palette?.title?.light, 0.9)
                    : alpha(theme?.palette?.title?.dark, 0.9)
                // background: (theme) => alpha(theme?.palette?.primary?.main, 0.4)
              }}
            >
              {item?.sidebarProps?.icon}
            </Box>
          )}
        </ListItemIcon>
      </ListItemButton>
      {item.child && (
        <Collapse in={open} timeout="auto">
          <List sx={{ ml: 1 }}>
            {item?.child?.map(
              (route: { sidebarProps: any; child: any }, index: null | undefined) =>
                route.sidebarProps ? (
                  route.child ? (
                    <ApiSidebarItem item={route} key={index} />
                  ) : (
                    <ApiSidebarItem item={route} key={index} />
                  )
                ) : null
            )}
          </List>
        </Collapse>
      )}
    </>
  ) : null;
};

export default ApiSidebarItem;
