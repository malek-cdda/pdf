import {
  Collapse,
  List,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Typography,
  alpha
} from '@mui/material';
import { Key, useEffect, useState } from 'react';
import ExpandLessOutlinedIcon from '@mui/icons-material/ExpandLessOutlined';
import ExpandMoreOutlinedIcon from '@mui/icons-material/ExpandMoreOutlined';
import ApiSidebarItem from './ApiSidebarItem';

const ApiSidebarItemCollapse = ({ item }: any) => {
  const [open, setOpen] = useState(true);
  //   const { appState } = useSelector((state: RootState) => state.appState);
  //   useEffect(() => {
  //     if (appState.includes(item.state)) {
  //       setOpen(true);
  //     }
  //   }, [appState, item]);
  console.log(item);
  return item.name ? (
    <>
      <ListItemButton
        sx={{
          '&: hover': {
            backgroundColor: 'transparent'
          },
          paddingY: '0px',
          paddingX: '0px',
          cursor: 'context-menu'

          // paddingX: '20px'
        }}
      >
        <ListItemText
          disableTypography
          primary={
            <Typography
              sx={{
                color: (theme: any) =>
                  theme.palette.mode === 'light'
                    ? alpha(theme.palette.title.light, 0.9)
                    : alpha(theme.palette.title.dark, 0.9),
                fontWeight: 600
              }}
            >
              {item?.name}
            </Typography>
          }
        />
        {/* {open ? <ExpandLessOutlinedIcon /> : <ExpandMoreOutlinedIcon />} */}
      </ListItemButton>
      <ApiSidebarItem item={item?.sidebarData} />
    </>
  ) : null;
};

export default ApiSidebarItemCollapse;
