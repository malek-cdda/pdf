'use client';

import { alpha, Box, Button, List, Typography } from '@mui/material';
import React from 'react';
import { Stack, Toolbar } from '@mui/material';

import { styled } from '@mui/material/styles';
import MuiDrawer from '@mui/material/Drawer';

import DashboardOutlinedIcon from '@mui/icons-material/DashboardOutlined';
import ArticleOutlinedIcon from '@mui/icons-material/ArticleOutlined';

import TripOriginIcon from '@mui/icons-material/TripOrigin';
import RemoveIcon from '@mui/icons-material/Remove';
import SettingsSuggestIcon from '@mui/icons-material/SettingsSuggest';
import CollectionsBookmarkIcon from '@mui/icons-material/CollectionsBookmark';
import ApiSidebarItemCollapse from './ApiSidebarItemCollapse';
import ApiSidebarItem from './ApiSidebarItem';
import OpenInNewIcon from '@mui/icons-material/OpenInNew';
const ApiSidebar = ({ handleOpenModal }: any) => {
  const appRoutes = [
    {
      name: 'PROPERTY APIS',
      sidebarData: {
        name: 'Property Search Api',
        path: '/Property-Search-Api',
        sidebarProps: {
          displayText: 'Property Search Field Guide',
          method: 'post',
          icon: <DashboardOutlinedIcon />
        },
        child: [
          {
            name: 'Getting Started-2',
            path: '/docs/getting-started',
            sidebarProps: {
              displayText: 'Getting Started-2',
              icon: <OpenInNewIcon />,
              method: 'get'
            }
          },

          {
            name: 'API Reference',
            path: '/docs/api-reference',
            sidebarProps: {
              displayText: 'API Reference',
              icon: <OpenInNewIcon />
            }
          }
        ]
      }
    }
  ];
  return (
    <div>
      <Box
        height={`calc(100vh - 140px)`}
        sx={{
          overflow: 'hidden',
          backgroundColor: (theme: any) =>
            theme?.palette?.mode === 'light'
              ? theme?.palette?.card?.light
              : theme?.palette?.card?.dark,
          color: (theme: any) =>
            theme.palette.mode === 'light'
              ? alpha(theme.palette.title.light, 0.9)
              : alpha(theme.palette.title.dark, 0.9),

          width: '100%',
          // borderRadius: '6px',
          borderBottomLeftRadius: '6px',
          borderTopLeftRadius: '6px',
          padding: '0px 6px 6px 6px',
          fontSize: '14px'
          // boxShadow: (theme) => theme.shadows[1]
        }}
      >
        {/* popup open for click this button  */}
        {/* <Button
          fullWidth
          sx={{
            marginBottom: '15px',
            // marginLeft: '14px',
            display: 'flex',
            justifyContent: 'space-between',
            color: (theme: any) =>
              theme.palette.mode === 'light'
                ? alpha(theme.palette.title.light, 0.9)
                : alpha(theme.palette.title.dark, 0.9),
            fontSize: '10px',
            border: 'solid',
            borderWidth: '1px',
            borderColor: (theme: any) =>
              theme.palette.mode === 'light'
                ? alpha(theme.palette.title.light, 0.5)
                : alpha(theme.palette.title.dark, 0.5),
            '&:hover': {
              borderColor: (theme: any) =>
                theme.palette.mode === 'light'
                  ? alpha(theme.palette.title.light, 0.9)
                  : alpha(theme.palette.title.dark, 0.9),
              background: 'transparent'
            }
          }}
          onClick={() => handleOpenModal()}
        >
          <Typography component="span" fontSize={10}>
            JUMP TO
          </Typography>
          <Typography
            component="span"
            fontSize={10}
            sx={{
              border: '1px solid white',
              padding: '3px 6px',
              borderRadius: '6px',
              background: (theme: any) =>
                theme.palette.mode === 'light'
                  ? alpha(theme.palette.title.light, 0.1)
                  : alpha(theme.palette.title.dark, 0.1),
              borderColor: (theme: any) =>
                theme.palette.mode === 'light'
                  ? alpha(theme.palette.title.light, 0.5)
                  : alpha(theme.palette.title.dark, 0.5)
            }}
          >
            CTRL-/
          </Typography>
        </Button> */}

        <Box
          component={'div'}
          sx={{
            marginTop: '0px',
            height: `calc(100vh - 140px)`,
            overflowY: 'auto',
            '&::-webkit-scrollbar': { display: 'none' }
          }}
        >
          <List component="nav">
            {appRoutes.map((route, index) =>
              route.sidebarData ? (
                <ApiSidebarItemCollapse item={route} key={index} />
              ) : (
                <ApiSidebarItem item={route} key={index} />
              )
            )}
          </List>
        </Box>
      </Box>
    </div>
  );
};

export default ApiSidebar;
