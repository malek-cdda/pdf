import { Box } from '@mui/material';
import React, { useState } from 'react';
import EditorPanel from './editor/Editor';
const Body = () => {
  const [codeValue, setCodeValue] = useState(undefined);
  const handleSchemaValueChange = (value: any) => {
    setCodeValue(value);
  };

  console.log('schemaValue', codeValue);

  return (
    <>
      <EditorPanel
        language="json"
        title="Json Schema Editor"
        path="test.json"
        defaultValue="// your comment"
        // isSchemaSampleDataOn={false}
        onChange={handleSchemaValueChange}
      />
    </>
  );
};

export default Body;
