import { Box, Typography } from '@mui/material';
import React from 'react';
import { useSelector } from 'react-redux';

const Response = () => {
  const { response } = useSelector((state: any) => state.playground) || {};
  return (
    <Box>
      <Typography
        sx={{
          fontSize: '14px',
          fontWeight: 'bold',
          margin: '5px 0'
        }}
      >
        RESPONSE:
      </Typography>
      <Box
        sx={{
          height: '230px',
          backgroundColor: '#1f1e1b',
          color: '#00ba38',
          borderRadius: '5px',
          padding: '10px',
          overflow: 'auto'
        }}
      >
        {<pre>{JSON.stringify(response, null, 2)}</pre>}
      </Box>
    </Box>
  );
};

export default Response;
