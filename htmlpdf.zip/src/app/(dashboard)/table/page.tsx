'use client';

import GlobalModal from '@/components/Modal/GlobalModal';
import Table from '@/components/Table/Table';
import { headCellsProps, rowDataProps } from '@/components/Table/types';
import { Avatar, Box, Button, Fab, Typography } from '@mui/material';
import React, { useState } from 'react';
import { CiEdit } from 'react-icons/ci';
import { MdOutlineDeleteOutline } from 'react-icons/md';
import { GrView } from 'react-icons/gr';
import AutoComplete from '@/components/AutoComplete/AutoComplete';
import { formatDate } from '@/utils/dateEsFormatter';
const Home = () => {
  const [open, setOpen] = useState(false);
  const handleOpen = () => setOpen(true);
  const headCells: headCellsProps[] = [
    {
      id: 'name',
      numeric: false,
      disablePadding: false,
      label: 'Name',
      option: {
        sortable: false
      },
      render: (user: rowDataProps) => (
        <Box display="flex" alignItems="center">
          <Avatar
            // sx={{ width: 24, height: 24 }}
            alt="Remy Sharp"
            src={user?.img}
          />
          <Box marginLeft="10px" display="flex" flexDirection="column">
            {' '}
            <Typography
              sx={{
                fontSize: '13px',
                color: (theme) =>
                  theme.palette.mode === 'light'
                    ? theme.palette.primary.main
                    : theme.palette.primary.light
              }}
            >
              {user.name}
            </Typography>
            <Typography
              sx={{
                fontSize: '13px',
                color: (theme) =>
                  theme.palette.mode === 'light'
                    ? theme.palette.primary.main
                    : theme.palette.primary.light
              }}
            >
              {user.address}
            </Typography>
          </Box>
        </Box>
      )
    },
    {
      id: 'status',
      numeric: false,
      disablePadding: false,
      label: 'Status'
    },
    {
      id: 'join',
      numeric: false,
      disablePadding: false,
      label: 'Joining Date',
      render: (data: any) => <>{formatDate(data.join)}</>
    },
    {
      id: 'agent',
      numeric: false,
      disablePadding: false,
      label: 'Agent'
    },
    {
      id: 'buyer',
      numeric: false,
      disablePadding: false,
      label: 'Buyer',
      option: {
        align: 'left'
      }
    },
    {
      id: 'actions',
      numeric: false,
      disablePadding: false,
      label: 'Actions',
      option: {
        align: 'right'
      },
      render: () => (
        <Box
          sx={{
            display: 'flex',
            justifyContent: 'end',
            alignItems: 'center',
            width: '100%',
            color: (theme) => (theme.palette.mode === 'light' ? 'title.light' : 'title.dark')
          }}
        >
          <Fab
            size="small"
            sx={{
              color: (theme) =>
                theme.palette.mode === 'light'
                  ? theme.palette.primary.main
                  : theme.palette.primary.light,
              backgroundColor: 'transparent',
              cursor: 'pointer',
              '&:hover': {
                backgroundColor: '#7c80858e'
              }
            }}
          >
            <GrView fontSize={16} />
          </Fab>
          <Fab
            size="small"
            sx={{
              color: (theme) =>
                theme.palette.mode === 'light'
                  ? theme.palette.primary.main
                  : theme.palette.primary.light,
              backgroundColor: 'transparent',
              cursor: 'pointer',

              padding: '0px',
              '&:hover': {
                backgroundColor: '#586285a9'
              }
            }}
            onClick={() => handleOpen()}
          >
            <CiEdit fontSize={16} />
          </Fab>
          <Fab
            size="small"
            sx={{
              color: (theme) =>
                theme.palette.mode === 'light'
                  ? theme.palette.primary.main
                  : theme.palette.primary.light,
              backgroundColor: 'transparent',
              cursor: 'pointer',
              '&:hover': {
                backgroundColor: '#f0644880'
              }
            }}
          >
            <MdOutlineDeleteOutline fontSize={16} />
          </Fab>
        </Box>
      )
    }
  ];
  const rowData: rowDataProps[] = [
    {
      id: 1,
      img: '/image/buyer.png',
      name: 'Mellisa Wolf',
      status: 'Active',
      join: '2021-01-01',
      agent: 'None',
      buyer: 'Pyreactor',
      address: 'Sarasota florida'
    },
    {
      id: 2,
      img: '/image/buyer.png',
      name: 'Toukir Raju',
      status: 'Inactive',
      join: '2021-01-01',
      agent: 'Aionline',
      buyer: 'Mijan',
      address: 'New York'
    },
    {
      id: 3,
      img: '/image/buyer.png',
      name: 'Jhon Don',
      status: 'Suspended',
      join: '2024-01-03',
      agent: 'None',
      buyer: 'The Rock',
      address: 'Sarasota florida'
    },
    {
      id: 3,
      img: '/image/buyer.png',
      name: 'Jhon Don',
      status: 'Suspended',
      join: '2024-01-03',
      agent: 'None',
      buyer: 'The Rock',
      address: 'Sarasota florida'
    }
  ];
  return (
    <>
      <Table
        headCells={headCells}
        row={rowData}
        handleOpen={handleOpen}
        filterName
        searchBar
        // dateRange
        // gridView
        // isCheckbox
      />
      {/* <AutoComplete /> */}
      <GlobalModal setOpen={setOpen} open={open} />
    </>
  );
};

export default Home;
