import React, { useState } from 'react';
import Table from '@/components/Table/Table';
import { Box, Fab, alpha } from '@mui/material';
import { MdOutlineDeleteOutline } from 'react-icons/md';
import { BiEdit } from 'react-icons/bi';
import AddUserForm from './AddUserForm';
import GlobalModal from '@/components/Modal/GlobalModal';
import { useConfirmationModalContext } from '@/providers/ConfirmationModalContext';
import InitLoader from '@/app/loading';
import DataNotAvailabel from '@/components/common/DataNotAvailabel';
import { useDeleteUserMutation, useGetUsersQuery } from '../features/userApi';

const UserList = ({ mls }: { mls?: boolean }) => {
  const [open, setOpen] = useState(false);
  const [editData, setEditData] = useState({});

  const {
    data: agentList,
    isLoading,
    isError,
    error
  } = useGetUsersQuery({ role__name: mls ? 'MLS' : 'AGENT' });
  const [deleteUser] = useDeleteUserMutation();

  // confirmation modal context for delete action confirmation
  const { showConfirmationModal, closeModal } = useConfirmationModalContext() as unknown as {
    showModal: boolean;
    closeModal: () => void;
    showConfirmationModal: (props: { onConfirm: () => void; message: string }) => void;
  };

  // handle delete action
  const handleDeleteAction = (row: any) => {
    deleteUser(row?.uid);
  };

  // handle delete click with confirmation
  const handleDeleteClick = (row: any) => {
    showConfirmationModal({
      onConfirm: () => handleDeleteAction(row),
      message: `Do you really want to delete this records? This process cannot be undone.`
    });
  };

  // table header cells
  const headerCells: any = [
    {
      id: 'uid',
      label: 'ID',
      numeric: false,
      disablePadding: true
    },
    {
      id: 'first_name',
      label: 'FIRST NAME',
      numeric: false,
      disablePadding: true
    },
    {
      id: 'email',
      label: 'EMAIL',
      numeric: false,
      render: (row: any) => row.email
    },
    {
      id: 'status',
      label: 'STATUS',
      numeric: false,
      render: (row: any) => row.status
    },
    {
      id: 'role',
      label: 'ROLE',
      numeric: false,
      render: (row: any) => row.role.name
    },
    {
      id: 'actions',
      numeric: false,
      disablePadding: false,
      label: 'ACTIONS',
      option: {
        align: 'right'
      },
      render: (row: any) => {
        return (
          <Box
            sx={{
              display: 'flex',
              justifyContent: 'end',
              alignItems: 'center',
              width: '100%',
              color: (theme: any) =>
                theme.palette.mode === 'light'
                  ? theme?.palette?.title?.light
                  : theme?.palette?.title?.dark
            }}
          >
            {/* <Fab
              size="small"
              sx={{
                color: (theme: any) =>
                  theme.palette.mode === 'light'
                    ? theme?.palette?.secondary?.light
                    : theme?.palette?.secondary?.dark,
                backgroundColor: 'transparent',
                cursor: 'pointer',
                '&:hover': {
                  backgroundColor: (theme: any) =>
                    theme.palette.mode === 'light'
                      ? alpha(theme?.palette?.secondary?.light, 0.4)
                      : alpha(theme?.palette?.secondary?.dark, 0.4)
                }
              }}
              //   onClick={() => handleOpen({ componentType: <View />, title: '' })}
            >
              <GrView fontSize={20} />
            </Fab> */}
            <Fab
              size="small"
              sx={{
                color: (theme: any) =>
                  theme.palette.mode === 'light'
                    ? theme?.palette?.error?.light
                    : theme?.palette?.error?.dark,
                backgroundColor: 'transparent',
                cursor: 'pointer',
                '&:hover': {
                  backgroundColor: (theme: any) =>
                    theme.palette.mode === 'light'
                      ? alpha(theme.palette.error.light, 0.4)
                      : alpha(theme.palette.error.dark, 0.4)
                }
              }}
              onClick={() => handleDeleteClick(row)}
            >
              <MdOutlineDeleteOutline fontSize={20} />
            </Fab>
            <Fab
              size="small"
              sx={{
                color: (theme: any) =>
                  theme.palette.mode === 'light'
                    ? theme?.palette?.secondary?.light
                    : theme?.palette?.secondary?.dark,
                backgroundColor: 'transparent',
                cursor: 'pointer',

                padding: '0px',
                '&:hover': {
                  backgroundColor: (theme: any) =>
                    theme.palette.mode === 'light'
                      ? alpha(theme?.palette?.secondary?.light, 0.4)
                      : alpha(theme?.palette?.secondary?.dark, 0.4)
                }
              }}
              onClick={() => {
                setOpen(true);
                setEditData(row);
              }}
            >
              <BiEdit fontSize={20} />
            </Fab>
          </Box>
        );
      }
    }
  ];

  let content = null;
  if (isLoading) content = <InitLoader />;
  if (!agentList?.length && !isLoading) content = <DataNotAvailabel />;
  if (agentList?.length)
    content = <Table headCells={headerCells} row={agentList} isPagination={false} />;
  return (
    <>
      {content}
      {open && (
        <GlobalModal
          title={mls ? 'Edit MLS User' : 'Edit Agent User'}
          setOpen={setOpen}
          open={open}
        >
          <AddUserForm
            setOpen={setOpen}
            isEdit
            data={editData}
            setEditData={setEditData}
            mls={mls}
          />
        </GlobalModal>
      )}
    </>
  );
};

export default UserList;
