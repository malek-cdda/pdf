'use client';

import GlobalModal from '@/components/Modal/GlobalModal';
import React, { useState } from 'react';
import { Box, Button, Stack, Typography } from '@mui/material';
import HeaderTitle from '@/components/HeaderTitle/HeaderTitle';
import AddUserForm from './AddUserForm';
import UserList from './AgentUserList';

const Users = ({ mls, agent }: { mls?: boolean; agent?: boolean }) => {
  const [open, setOpen] = useState(false);
  return (
    <Box>
      <Stack direction="row" justifyContent="space-between" alignItems="center" mb={2}>
        <HeaderTitle
          title={mls ? 'MLS Users' : 'Agent Users'}
          description={
            mls
              ? 'Manage all the mls users here. You can add, edit and delete the mls users.'
              : 'Manage all the agent users here. You can add, edit and delete the agent users.'
          }
        />
        <Button variant="contained" onClick={() => setOpen(true)}>
          Add New {mls ? 'MLS' : 'Agent'}
        </Button>
      </Stack>
      {open && (
        <GlobalModal
          title={
            <Typography variant="h5" component="div">
              Add New {mls ? 'MLS' : 'Agent'}
            </Typography>
          }
          setOpen={setOpen}
          open={open}
        >
          <AddUserForm setOpen={setOpen} mls={mls} />
        </GlobalModal>
      )}
      <UserList mls={mls} />
    </Box>
  );
};

export default Users;
