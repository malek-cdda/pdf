import React from 'react';
import Users from '../components/Users';

const AgentUser = () => {
  return <Users />;
};

export default AgentUser;
