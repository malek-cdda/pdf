import { Box } from '@mui/material';
import TabPnale from './components/rightside/TabPnale';
import LeftSide from './components/leftside/LeftSide';

function Page() {
  return (
    <Box
      sx={{
        width: '100%',
        display: 'flex',
        justifyContent: 'space-between',
        gap: '1rem'
      }}
      component="section"
    >
      {/* User Details left side */}
      <LeftSide />
      {/* Right side tab panale */}
      <TabPnale />
    </Box>
  );
}

export default Page;
