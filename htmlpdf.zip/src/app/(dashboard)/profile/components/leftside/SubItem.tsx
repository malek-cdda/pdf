import { Box, Typography } from '@mui/material';
import React from 'react';

function SubItem({ data }: any) {
  return (
    <Box
      color={'inherit'}
      sx={{
        display: 'flex',
        gap: '.5rem',
        padding: '.3rem 0'
      }}
    >
      <Typography
        variant="body2"
        sx={{
          fontWeight: 600,
          textTransform: 'capitalize'
        }}
      >
        {data?.name}:
      </Typography>
      <Typography variant="subtitle2">{data?.value}</Typography>
    </Box>
  );
}

export default SubItem;
