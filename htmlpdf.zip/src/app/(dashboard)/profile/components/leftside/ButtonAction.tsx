import { Box } from '@mui/material';
import { alpha } from '@mui/system';
import Button from '@mui/material/Button';
import React from 'react';

function ButtonAction() {
  return (
    <Box
      sx={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        gap: '1.5rem',
        marginTop: '1rem'
      }}
    >
      <Button variant="contained" color="primary">
        Edit
      </Button>
      <Button variant="contained" color="error">
        Suspend
      </Button>
    </Box>
  );
}

export default ButtonAction;
