import { Box } from '@mui/material';

import React from 'react';
import UserProfile from './UserProfile';

function LeftSide() {
  return (
    <Box
      sx={{
        width: '25%',
        display: 'flex',
        flexDirection: 'column',
        gap: '1rem',
        borderRadius: '5px'
      }}
      component="section"
    >
      {/* User Card */}
      <UserProfile />
    </Box>
  );
}

export default LeftSide;
