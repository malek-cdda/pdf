'use client';
import { Avatar, Box, Typography, alpha } from '@mui/material';
import BsicInfo from './BsicInfo';
import Subcribe from './Subcribe';
import DetailsMoreInfo from './DetailsMoreInfo';
import ButtonAction from './ButtonAction';

const UserProfile = () => {
  return (
    <Box
      sx={{
        bgcolor: (theme: any) =>
          theme.palette?.mode === 'light'
            ? alpha(theme?.palette?.card?.light, 0.5)
            : theme?.palette?.card?.dark,
        padding: '1rem',
        borderRadius: '5px',
        boxShadow: 1
      }}
    >
      <Typography
        color={(theme: any) =>
          theme.palette.mode === 'light'
            ? alpha(theme.palette.title.light, 0.9)
            : alpha(theme.palette.title.dark, 0.9)
        }
        variant="h2"
        sx={{ textAlign: 'center' }}
      >
        MLS
      </Typography>
      {/* profile image */}
      <Avatar
        sx={{
          width: 100,
          height: 100,
          margin: '15px auto'
        }}
        alt="Eshak"
        src="/15.png"
      />
      <Typography
        color={(theme: any) =>
          theme.palette.mode === 'light'
            ? alpha(theme.palette.title.light, 0.9)
            : alpha(theme.palette.title.dark, 0.9)
        }
        variant="subtitle1"
        sx={{ textAlign: 'center' }}
      >
        Test name
      </Typography>
      {/* info */}
      <BsicInfo />
      {/* Subcribe */}
      <Subcribe />
      {/* Details info */}
      <DetailsMoreInfo />
      {/* Button */}
      <ButtonAction />
    </Box>
  );
};
export default UserProfile;
