'use client';
import { Box, alpha } from '@mui/material';
import React from 'react';
import MyTabs from './MyTabs';

function TabPnale() {
  return (
    <Box
      sx={{
        bgcolor: (theme: any) =>
          theme.palette?.mode === 'light'
            ? alpha(theme?.palette?.card?.light, 0.5)
            : theme?.palette?.card?.dark,
        width: '75%',
        padding: '1rem',
        borderRadius: '5px',
        boxShadow: 1
      }}
      component="section"
    >
      <MyTabs />
    </Box>
  );
}

export default TabPnale;
