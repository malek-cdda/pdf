'use client';
import { alpha, Box, Button, Grid, Paper, styled, Typography } from '@mui/material';
import React, { useState } from 'react';
import { RxCopy } from 'react-icons/rx';
import { IconButton } from '@mui/material';
import Image from 'next/image';
import Avatar from '@mui/material/Avatar';
import AvatarGroup from '@mui/material/AvatarGroup';
import AddEditRole from './AddEditRole';
import { MdDelete } from 'react-icons/md';

const Card = ({
  handleOpen,
  setOpen,
  data,
  handleDeleteAction
}: {
  handleOpen: ({ componentType, title }: { componentType: React.ReactNode; title: string }) => void;
  setOpen: any;
  data: any[];
  handleDeleteAction: (row: any) => void;
}) => {
  return (
    <Grid container spacing={2}>
      {data?.map((item, index) => (
        <Grid key={index} item spacing={8} xs={4}>
          <Box
            sx={{
              padding: '24px',
              borderRadius: '12px',
              bgcolor: (theme: any) =>
                theme.palette?.mode === 'light'
                  ? alpha(theme?.palette?.card?.light, 0.5)
                  : theme?.palette?.card?.dark,
              boxShadow: (theme: any) => theme.shadows[1],
              maxHeight: '140px'
            }}
            display="flex"
            flexDirection="column"
          >
            <Box display="flex" justifyContent="space-between" alignItems="center">
              <Typography
                variant="h6"
                fontSize="15px"
                sx={{
                  color: (theme: any) =>
                    theme.palette.mode === 'light'
                      ? alpha(theme?.palette?.title?.light, 0.9)
                      : alpha(theme?.palette?.title?.dark, 0.9)
                }}
              >
                Total 0 users
              </Typography>
              {/* direction change avatargroup code here  */}

              {/* avatar group code here  */}
              <AvatarGroup
                renderSurplus={(surplus) => (
                  <span style={{ fontSize: '13px' }}>+{surplus.toString()[0]}k</span>
                )}
                total={4341}
                sx={{
                  // writingMode: 'vertical-rl',
                  ' & > .MuiAvatar-root:nth-child(1)': {
                    zIndex: 10
                  },
                  ' & > .MuiAvatar-root:nth-child(2)': {
                    zIndex: 9
                  },
                  ' & > .MuiAvatar-root:nth-child(3)': {
                    zIndex: 8
                  },
                  ' & > .MuiAvatar-root:nth-child(4)': {
                    zIndex: 7
                  },
                  '& .MuiAvatarGroup-avatar': {
                    width: '28px',
                    height: '28px'
                  }
                }}
              >
                {[1, 2, 3].map((item, key) => (
                  <Avatar
                    key={key}
                    alt="Remy Sharp"
                    src="/static/images/avatar/1.jpg"
                    sx={{
                      ':hover': {
                        '&:hover': {
                          transition: '.2s',
                          cursor: 'pointer',
                          marginTop: '-2px',
                          zIndex: 12
                        }
                      }
                    }}
                  />
                ))}
              </AvatarGroup>
            </Box>
            <Box display="flex" justifyContent="space-between" alignItems="end" marginTop="4px">
              <Box>
                <Typography
                  variant="h4"
                  sx={{
                    color: (theme) =>
                      theme.palette.mode === 'light' ? 'subtitle.light' : 'subtitle.dark'
                  }}
                >
                  {item?.label}
                </Typography>

                <Box display="flex" gap="8px">
                  <Typography
                    variant="button"
                    color={(theme: any) =>
                      theme.palette.mode === 'light'
                        ? alpha(theme?.palette?.primary?.light, 0.9)
                        : alpha(theme?.palette?.primary?.dark, 0.9)
                    }
                    onClick={() =>
                      handleOpen({
                        componentType: <AddEditRole data={item} setOpen={setOpen} edit />,
                        title: 'Edit Role'
                      })
                    }
                  >
                    Edit
                  </Typography>
                </Box>
              </Box>
              <IconButton onClick={() => handleDeleteAction(item)}>
                <MdDelete />
              </IconButton>
            </Box>
          </Box>
        </Grid>
      ))}
      <Grid item spacing={8} xs={4}>
        <Box
          sx={{
            padding: '24px 0px 0px ',
            borderRadius: '12px',
            bgcolor: (theme: any) =>
              theme.palette?.mode === 'light'
                ? alpha(theme?.palette?.card?.light, 0.5)
                : theme?.palette?.card?.dark,
            boxShadow: (theme: any) => theme.shadows[1],
            maxHeight: '140px',
            overflow: 'hidden'
          }}
          display="flex"
          flexDirection="row"
          justifyContent="space-around"
        >
          <Image
            src="/assets/images/roles/add-new-roles.png"
            alt="Picture of the author"
            width={83}
            height={118}
          />
          <Box
            textAlign="right"
            sx={{
              padding: '12px'
            }}
          >
            <Button
              variant="contained"
              sx={{
                marginBottom: '8px'
              }}
              onClick={() =>
                handleOpen({ componentType: <AddEditRole {...{ setOpen }} />, title: 'Add Role' })
              }
            >
              Add New Role
            </Button>
            <Typography
              color={(theme) =>
                theme.palette.mode === 'light' ? 'subtitle.light' : 'subtitle.dark'
              }
              sx={{
                marginTop: '4px'
              }}
            >
              Add role, if it does not exist
            </Typography>
          </Box>
        </Box>
      </Grid>
    </Grid>
  );
};

export default Card;
