'use client';

import { Box, alpha } from '@mui/material';
import React from 'react';

const PreviewContent = ({ value }: { value: string }) => {
  return (
    <Box
      sx={{
        // background: (theme: any) => {
        //   return theme.palette.mode === 'light'
        //     ? alpha(theme.palette.card.light, 1)
        //     : alpha(theme.palette.card.dark, 1);
        // },
        borderRadius: '5px',
        width: '100%',
        padding: '10px'
      }}
    >
      <div
        dangerouslySetInnerHTML={{
          __html: `${value}`
        }}
      />
    </Box>
  );
};

export default PreviewContent;
