'use client';

import { formatDate } from '@/utils/dateEsFormatter';
import { Box, Button, IconButton, Menu, MenuItem, Stack, Typography, alpha } from '@mui/material';
import Link from 'next/link';
import React from 'react';
import { BsThreeDotsVertical } from 'react-icons/bs';

const List = ({ item, handleUid, handleDeleteAgreement }: any) => {
  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
  const open = Boolean(anchorEl);
  const handleClick = (event: React.MouseEvent<HTMLButtonElement>) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  return (
    <Stack
      direction="row"
      justifyContent="space-between"
      sx={{
        cursor: 'pointer',
        padding: '10px 10px',
        borderRadius: '5px',
        background: (theme: any) =>
          theme.palette.mode === 'light'
            ? alpha(theme.palette.card.light, 1)
            : alpha(theme.palette.card.dark, 1)
      }}
      onClick={() => handleUid(item.uid)}
    >
      <Box>
        <Stack direction="row" gap={1} alignItems="center">
          <Typography
            variant="h6"
            color={(theme: any) =>
              theme.palette.mode === 'light'
                ? alpha(theme.palette.title.light, 0.9)
                : alpha(theme.palette.title.dark, 0.9)
            }
          >
            {item.name}
          </Typography>
          <Typography
            fontSize={12}
            bgcolor="#12a6fc"
            sx={{
              color: (theme: any) =>
                theme.palette.mode === 'light' ? 'white' : alpha(theme.palette.title.light, 1),
              padding: '1px 5px',
              borderRadius: '2px'
            }}
          >
            {item.label}
          </Typography>
        </Stack>
        <Typography
          color={(theme: any) =>
            theme.palette.mode === 'light'
              ? alpha(theme.palette.subtitle.light, 0.9)
              : alpha(theme.palette.subtitle.dark, 0.9)
          }
          fontSize={14}
        >
          Created at: {formatDate(item.created_at, '/')}
        </Typography>
      </Box>
      <Box>
        <div>
          <IconButton size="small" onClick={handleClick}>
            <BsThreeDotsVertical />
          </IconButton>
          <Menu id="basic-menu" anchorEl={anchorEl} open={open} onClose={handleClose}>
            <MenuItem onClick={handleClose}>
              <Link
                style={{
                  textDecoration: 'none',
                  color: 'inherit'
                }}
                href={`/template/${item?.uid}`}
              >
                Edit
              </Link>
            </MenuItem>
            <MenuItem
            //  onClick={() => handleDeleteAgreement(item?.uid)}
            >
              Delete
            </MenuItem>
          </Menu>
        </div>
      </Box>
    </Stack>
  );
};

export default List;
