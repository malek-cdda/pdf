import { apiSlice } from '@/redux/features/api/apiSlice';

export const agreementApi: any = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    getAgreements: builder.query({
      query: () => ({
        url: `/template/agreement`
      }),
      providesTags: ['Agreement']
    }),

    getAgreement: builder.query({
      query: (uid) => ({
        url: `/template/agreement/${uid}`
      }),
      providesTags: (result, error, uid) => [{ type: 'Agreement', uid }]
    }),
    editAgreement: builder.mutation({
      query: ({ uid, data }) => ({
        url: `/template/agreement/${uid}`,
        method: 'PUT',
        body: data
      }),
      // In this case, `getPost` will be re-run. `getPosts` *might*  rerun, if this id was under its results.
      invalidatesTags: (result, error, { uid }) => [{ type: 'Agreement', uid }],

      async onQueryStarted({ uid, data }, { dispatch, queryFulfilled }) {
        try {
          const { data: role } = await queryFulfilled;

          // also update getPermission's cache

          //   dispatch(
          //     apiSlice.util.updateQueryData('getPermissions', undefined, (draft) => {
          //       return draft.map((item) => (item?.uid === uid ? role : item));
          //     })
          //   );
        } catch (err) {
          console.log(err);
        }
      }
    }),
    stateAgreement: builder.query({
      query: () => ({
        url: `/template/states`
      }),
      // In this case, `getPost` will be re-run. `getPosts` *might*  rerun, if this id was under its results.
      invalidatesTags: (result, error, { uid }) => [{ type: 'Agreement', uid }]
    }),
    userMacros: builder.query({
      query: () => ({
        url: `/template/model-fields?model=user`
      }),
      // In this case, `getPost` will be re-run. `getPosts` *might*  rerun, if this id was under its results.
      invalidatesTags: (result, error, { uid }) => [{ type: 'Agreement', uid }]
    }),
    agreementModel: builder.query({
      query: () => ({
        url: `/template/models`
      }),
      // In this case, `getPost` will be re-run. `getPosts` *might*  rerun, if this id was under its results.
      invalidatesTags: (result, error, { uid }) => [{ type: 'Agreement', uid }]
    }),
    deleteAgreement: builder.mutation({
      query: (uid) => ({
        url: `/template/agreement/${uid}`,
        method: 'DELETE'
      }),
      invalidatesTags: (result, error, { uid }) => ['Agreement']
    }),
    createAgreement: builder.mutation({
      query: (data) => ({
        url: '/template/agreement',
        method: 'POST',
        body: data
      }),
      invalidatesTags: ['Agreement']
    })
  })
});

export const {
  useGetAgreementsQuery,
  useGetAgreementQuery,
  useEditAgreementMutation,
  useStateAgreementQuery,
  useDeleteAgreementMutation,
  useUserMacrosQuery,
  useAgreementModelQuery,
  useCreateAgreementMutation
} = agreementApi;
