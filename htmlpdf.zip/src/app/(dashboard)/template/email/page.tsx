import React from 'react'

const EmailTemplate = () => {
  return (
    <div>EmailTemplate</div>
  )
}

export default EmailTemplate