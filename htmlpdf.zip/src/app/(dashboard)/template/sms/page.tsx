import React from 'react';

const SmsTemplate = () => {
  return <div>SmsTemplate</div>;
};

export default SmsTemplate;
