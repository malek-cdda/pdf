import {
  Button,
  Checkbox,
  CircularProgress,
  Input,
  InputLabel,
  Stack,
  TextField
} from '@mui/material';
import { useFormik } from 'formik';
import React, { useEffect } from 'react';
import * as Yup from 'yup';
import {
  useCreateSubscriptionMutation,
  useGetSubscriptionByIdQuery,
  useUpdateSubscriptionMutation
} from '../features/subscriptionApi';
import { Text } from '@/components/Fields';
import { toast } from 'react-toastify';
const validationSchema = Yup.object().shape({
  label: Yup.string().required('Label is required'),
  name: Yup.string().required('Name is required'),
  description: Yup.string().required('Description is required'),
  price: Yup.number().required('Price is required').min(1, 'Price must be greater than 0'),
  duration: Yup.number().required('Duration is required').min(1, 'Duration must be greater than 0'),
  max_request: Yup.number()
    .required('Max Request is required')
    .min(1, 'Max Request must be greater than 0'),
  metered: Yup.boolean(),
  per_request_fee: Yup.number().when('metered', {
    is: (value: any) => value === true,
    then: (schema) =>
      schema
        .required('Per Request Fee is required')
        .min(1, 'Per Request Fee must be greater than 0'),
    otherwise: (schema) => schema
  }),
  trial: Yup.boolean(),
  trial_days: Yup.number().when('trial', {
    is: (value: any) => value === true,
    then: (schema) =>
      schema.required('Trial Days is required').min(1, 'Trial days must be greater than 0'),
    otherwise: (schema) => schema
  }),
  trial_description: Yup.string().when('trial', {
    is: (value: any) => value === true,
    then: (schema) => schema.required('Trial description is required'),
    otherwise: (schema) => schema
  })
  // feature_items: Yup.array().of(
  //   Yup.object().shape({
  //     content: Yup.string().required('Feature Item is required'),
  //     enable: Yup.boolean()
  //   })
  // )
});
const SubscriptionForm = ({ setModalClose, editData, setEditData }: any) => {
  const [createSubscription, { isLoading }] = useCreateSubscriptionMutation();
  console.log(editData, 'editData');
  const [updateSubscription, { isLoading: updateLoading }] = useUpdateSubscriptionMutation();

  const {
    data: subscription,
    isSuccess,
    isLoading: singleSubscriptionLoading
  } = useGetSubscriptionByIdQuery({ id: editData?.id }, { skip: !editData });

  // define formik form with initial values and validation schema
  const formik = useFormik({
    initialValues: {
      label: '',
      name: '',
      description: '',
      price: 0,
      duration: 0,
      max_request: 0,
      metered: true,
      per_request_fee: 0, // if metered true
      trial: true,
      trial_days: 0, // if trial true
      trial_description: '' // if trial true
      //   icon_image: null
      // feature_items: [
      //   {
      //     content: '',
      //     enable: true
      //   }
      // ]
    },
    validationSchema,
    onSubmit: async (values: any, { setSubmitting, resetForm }) => {
      try {
        if (editData?.id) {
          // update subscription
          await updateSubscription({ id: editData.id, data: values }).then(() => {
            toast.success('Subscription updated successfully');
            setModalClose(false);
            resetForm();
          });
        } else {
          // create subscription
          createSubscription(values).then(() => {
            toast.success('Subscription created successfully');
            setModalClose(false);
            resetForm();
          });
        }
      } catch (error: any) {
        console.log('Error occurred during fetch request:', error);
      }
      // Set formik submitting to false
      setSubmitting(false);
    },
    // Enable reinitialize to update the form values
    enableReinitialize: true
  });

  useEffect(() => {
    if (isSuccess) {
      formik.setValues(subscription);
    }
  }, [subscription]);

  // updated data loading
  if (singleSubscriptionLoading) {
    return (
      <Stack justifyContent={'center'} alignItems={'center'}>
        <CircularProgress />
      </Stack>
    );
  }

  return (
    <form
      onSubmit={formik.handleSubmit}
      style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}
    >
      <Text
        id="label"
        name="label"
        label="Label"
        variant="outlined"
        type="text"
        formik={formik}
        key={'label'}
        animation
      />
      <Text
        id="name"
        name="name"
        label="Name"
        variant="outlined"
        type="text"
        formik={formik}
        key={'name'}
        animation
      />
      <Text
        id="description"
        name="description"
        label="Description"
        variant="outlined"
        type="text"
        formik={formik}
        key={'description'}
        animation
      />
      <Text
        id="price"
        name="price"
        label="Price"
        variant="outlined"
        type="number"
        formik={formik}
        key={'price'}
        animation
      />
      <Text
        id="duration"
        name="duration"
        label="Duration"
        variant="outlined"
        type="number"
        formik={formik}
        key={'duration'}
        animation
      />
      <Text
        id="max_request"
        name="max_request"
        label="Max Request"
        variant="outlined"
        type="number"
        formik={formik}
        key={'max_request'}
        animation
      />
      {/* metered */}
      <Stack direction="row" spacing={0.5} alignItems={'center'}>
        <Checkbox
          id="metered"
          name="metered"
          checked={formik.values.metered}
          onChange={(e) => formik.setFieldValue('metered', e.target.checked)}
          inputProps={{ 'aria-label': 'controlled' }}
        />
        <InputLabel
          htmlFor="metered"
          sx={{ cursor: 'pointer' }}
          error={formik.touched?.['metered'] && Boolean(formik.errors?.['metered'])}
        >
          Metered{' '}
        </InputLabel>
      </Stack>
      {formik?.values?.metered && (
        <Text
          id="per_request_fee"
          name="per_request_fee"
          label="Per Req Fee"
          variant="outlined"
          type="number"
          formik={formik}
          key={'per_request_fee'}
          animation
        />
      )}
      {/* trial */}
      <Stack direction="row" spacing={0.5} alignItems={'center'}>
        <Checkbox
          id="trial"
          name="trial"
          checked={formik.values.trial}
          onChange={(e) => formik.setFieldValue('trial', e.target.checked)}
          inputProps={{ 'aria-label': 'controlled' }}
        />
        <InputLabel htmlFor="trial" sx={{ cursor: 'pointer' }}>
          Trial{' '}
        </InputLabel>
      </Stack>
      {formik.values.trial && (
        <>
          <Text
            id="trial_days"
            name="trial_days"
            label="Trial Days"
            variant="outlined"
            type="number"
            formik={formik}
            key={'trial_days'}
            animation
          />

          <Text
            id="trial_description"
            name="trial_description"
            label="Trial Description"
            variant="outlined"
            type="text"
            formik={formik}
            key={'trial_description'}
            animation
          />
        </>
      )}

      <Button type="submit" variant="contained" disabled={isLoading}>
        Submit {isLoading && <CircularProgress size={20} />}
      </Button>
    </form>
  );
};

export default SubscriptionForm;
