import InitLoader from '@/app/loading';
import DataNotAvailabel from '@/components/common/DataNotAvailabel';
import { useConfirmationModalContext } from '@/providers/ConfirmationModalContext';
import { Box, Fab, Typography, alpha } from '@mui/material';
import React, { useState } from 'react';
import { BiEdit } from 'react-icons/bi';
import { MdOutlineDeleteOutline } from 'react-icons/md';
import {
  useDeleteSubscriptionMutation,
  useGetAvailableSubscriptionQuery
} from '../features/subscriptionApi';
import Table from '@/components/Table/Table';
import GlobalModal from '@/components/Modal/GlobalModal';
import SubscriptionForm from './SubscriptionForm';
import { toast } from 'react-toastify';

const SubscriptionList = () => {
  const [open, setOpen] = useState(false);
  const [editData, setEditData] = useState({});
  const { data: subscriptionList, isLoading } = useGetAvailableSubscriptionQuery({});
  const [deleteSubscription] = useDeleteSubscriptionMutation();

  // confirmation modal context for delete action confirmation
  const { showConfirmationModal, closeModal } = useConfirmationModalContext() as unknown as {
    showModal: boolean;
    closeModal: () => void;
    showConfirmationModal: (props: { onConfirm: () => void; message: string }) => void;
  };

  // handle delete action
  const handleDeleteAction = (row: any) => {
    //   deleteUser(row?.uid);
    deleteSubscription({ id: row?.id }).finally(() => {
      toast.success('Subscription deleted successfully');
    });
  };

  // handle delete click with confirmation
  const handleDeleteClick = (row: any) => {
    showConfirmationModal({
      onConfirm: () => handleDeleteAction(row),
      message: `Do you really want to delete this records? This process cannot be undone.`
    });
  };

  // table header cells
  const headerCells: any = [
    {
      id: 'label',
      label: 'Label'
    },
    {
      id: 'name',
      label: 'Name'
    },
    {
      id: 'description',
      label: 'Description'
    },
    {
      id: 'price',
      label: 'Price'
    },
    {
      id: 'duration',
      label: 'Duration'
    },
    {
      id: 'metered',
      label: 'Metered'
    },
    {
      id: 'per_request_fee',
      label: 'Per Request Fee'
    },
    {
      id: 'trial',
      label: 'Trial'
    },
    {
      id: 'trial_days',
      label: 'Trial Days'
    },
    {
      id: 'trial_description',
      label: 'Trial Description'
    },
    {
      id: 'actions',
      numeric: false,
      disablePadding: false,
      label: 'ACTIONS',
      option: {
        align: 'right'
      },
      render: (row: any) => {
        return (
          <Box
            sx={{
              display: 'flex',
              justifyContent: 'end',
              alignItems: 'center',
              width: '100%',
              color: (theme: any) =>
                theme.palette.mode === 'light'
                  ? theme?.palette?.title?.light
                  : theme?.palette?.title?.dark
            }}
          >
            {/* <Fab
                size="small"
                sx={{
                  color: (theme: any) =>
                    theme.palette.mode === 'light'
                      ? theme?.palette?.secondary?.light
                      : theme?.palette?.secondary?.dark,
                  backgroundColor: 'transparent',
                  cursor: 'pointer',
                  '&:hover': {
                    backgroundColor: (theme: any) =>
                      theme.palette.mode === 'light'
                        ? alpha(theme?.palette?.secondary?.light, 0.4)
                        : alpha(theme?.palette?.secondary?.dark, 0.4)
                  }
                }}
                //   onClick={() => handleOpen({ componentType: <View />, title: '' })}
              >
                <GrView fontSize={20} />
              </Fab> */}
            <Fab
              size="small"
              sx={{
                color: (theme: any) =>
                  theme.palette.mode === 'light'
                    ? theme?.palette?.error?.light
                    : theme?.palette?.error?.dark,
                backgroundColor: 'transparent',
                cursor: 'pointer',
                '&:hover': {
                  backgroundColor: (theme: any) =>
                    theme.palette.mode === 'light'
                      ? alpha(theme.palette.error.light, 0.4)
                      : alpha(theme.palette.error.dark, 0.4)
                }
              }}
              onClick={() => handleDeleteClick(row)}
            >
              <MdOutlineDeleteOutline fontSize={20} />
            </Fab>
            <Fab
              size="small"
              sx={{
                color: (theme: any) =>
                  theme.palette.mode === 'light'
                    ? theme?.palette?.secondary?.light
                    : theme?.palette?.secondary?.dark,
                backgroundColor: 'transparent',
                cursor: 'pointer',

                padding: '0px',
                '&:hover': {
                  backgroundColor: (theme: any) =>
                    theme.palette.mode === 'light'
                      ? alpha(theme?.palette?.secondary?.light, 0.4)
                      : alpha(theme?.palette?.secondary?.dark, 0.4)
                }
              }}
              onClick={() => {
                setOpen(true);
                setEditData(row);
              }}
            >
              <BiEdit fontSize={20} />
            </Fab>
          </Box>
        );
      }
    }
  ];

  let content = null;
  if (isLoading) content = <InitLoader />;
  if (!subscriptionList?.length && !isLoading) content = <DataNotAvailabel />;
  if (subscriptionList?.length)
    content = <Table headCells={headerCells} row={subscriptionList} isPagination={false} />;
  return (
    <div>
      {content}
      {open && (
        <GlobalModal
          title={
            <Typography variant="h5" component="div">
              Edit Subscription
            </Typography>
          }
          setOpen={setOpen}
          open={open}
        >
          {/* // Add Subscription Form */}
          <SubscriptionForm setModalClose={setOpen} editData={editData} setEditData={setEditData} />
        </GlobalModal>
      )}
    </div>
  );
};

export default SubscriptionList;
