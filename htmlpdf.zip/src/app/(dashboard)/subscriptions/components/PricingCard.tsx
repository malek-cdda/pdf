import { Box, Card, Typography, Button } from '@mui/material';
import TaskAltOutlinedIcon from '@mui/icons-material/TaskAltOutlined';
import React from 'react';
type SubscriptionCardProps = {
  title: string;
  price: number;
  features: string[];
  description?: string;
};
function PricingCard({ title, price, features, description }: SubscriptionCardProps) {
  return (
    <Card
      sx={{
        width: '100%',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        padding: '1rem',
        gap: '1rem',
        borderRadius: '8px',
        boxShadow: 2
      }}
    >
      <Typography variant="h1">{title}</Typography>
      <Typography variant="h1">${price}</Typography>
      <Typography variant="body2">{description}</Typography>
      <Box>
        {features.map((feature) => (
          <Typography
            variant="body2"
            sx={{
              display: 'flex',
              gap: '0.5rem',
              alignItems: 'center'
            }}
            key={feature}
          >
            <TaskAltOutlinedIcon
              sx={{
                color: 'primary.main',
                fontSize: '1.2rem'
              }}
            />{' '}
            {feature}
          </Typography>
        ))}
      </Box>
      <Button variant="contained">Subscribe</Button>
    </Card>
  );
}

export default PricingCard;
