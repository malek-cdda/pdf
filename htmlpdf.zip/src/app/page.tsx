'use client';
import IconSearch from '@/components/IconHandler/IconSearch';
import MuiIconWrapper from '@/components/IconHandler/MuiIconWrapper';
import { Dashboard } from '@/layouts';
import { useConfirmationModalContext } from '@/providers/ConfirmationModalContext';
import { Box, Button, Stack, Typography, alpha } from '@mui/material';
import React, { useState } from 'react';

function getGreeting() {
  const currentTime = new Date();
  const currentHour = currentTime.getHours();

  let greeting;

  if (currentHour >= 5 && currentHour < 12) {
    greeting = 'Good morning';
  } else if (currentHour >= 12 && currentHour < 17) {
    greeting = 'Good afternoon';
  } else if (currentHour >= 17 && currentHour < 21) {
    greeting = 'Good evening';
  } else {
    greeting = 'Good night';
  }
  return greeting;
}

// or with custom SVG
const Home = () => {
  const [selectedIcon, setSelectedIcon] = useState('');
  // const HomeIcon = createSvgIcon(<CustomReactIcon nameIcon={selectedIcon} />, selectedIcon);

  // HERE IS THE FUNCTIONALITY MODAL OF CONFIRMATION TO DELETE AN ITEM
  const { showConfirmationModal, closeModal } = useConfirmationModalContext() as unknown as {
    showModal: boolean;
    closeModal: () => void;
    showConfirmationModal: (props: { onConfirm: () => void; message: string }) => void;
  };

  const handleDelete = () => {
    // Your delete logic goes here
    console.log('Item deleted!');
    closeModal(); // Close the modal after the delete action
  };

  const handleDeleteClick = () => {
    showConfirmationModal({
      onConfirm: handleDelete,
      message: `Do you really want to delete this records? This process cannot be undone.`
    });
  };

  return (
    <Dashboard>
      <Box>
        {/* header  */}
        <Stack spacing={2} direction={'row'} justifyContent={'space-between'}>
          {/* left side */}
          <Stack>
            <Typography
              color={(theme: any) =>
                theme.palette.mode === 'light'
                  ? alpha(theme.palette.title.light, 0.9)
                  : alpha(theme.palette.title.dark, 0.9)
              }
              variant={'h4'}
            >
              {getGreeting()}, Kent Dodds! 👋
            </Typography>
            <Typography
              color={(theme: any) =>
                theme.palette.mode === 'light'
                  ? alpha(theme.palette.title.light, 0.9)
                  : alpha(theme.palette.title.dark, 0.9)
              }
              variant={'caption'}
            >
              Heres whats happening with your store today.
            </Typography>

            {selectedIcon && (
              <MuiIconWrapper
                sx={{
                  color: (theme: any) =>
                    theme.palette.mode === 'light'
                      ? alpha(theme.palette.title.light, 0.9)
                      : alpha(theme.palette.title.dark, 0.9)
                }}
              >
                {selectedIcon}
              </MuiIconWrapper>
            )}
          </Stack>
          {/* right side */}
        </Stack>

        {/* widgets */}

        <Box>
          <IconSearch
            label="Select Icon"
            selectedIcon={selectedIcon}
            setSelectedIcon={setSelectedIcon}
          />
        </Box>

        {/* TEST COMPONENTS */}
        <Box mt={5}>
          <Button onClick={handleDeleteClick} variant="contained" color="primary">
            DELETE
          </Button>
        </Box>
      </Box>
    </Dashboard>
  );
};

export default Home;
