'use client';
import React, { useEffect } from 'react';
import AuthTextField from '../components/AuthTextField';
import Image from 'next/image';
import { Box, Button, Paper, Typography } from '@mui/material';
import MuiLink from '@/components/common/MuiLink';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import { useSignInMutation } from './feature/loginApi';
import { useRouter, useSearchParams } from 'next/navigation';

const SignIn = () => {
  const [signIn, { data, error, isLoading, isSuccess }] = useSignInMutation();
  const queryParams = useSearchParams();
  const callBackUrl = queryParams.get('callbackUrl');
  const router = useRouter();

  const formik = useFormik({
    initialValues: {
      username: '+8801111111111',
      password: 'admin'
    },

    // Validation Schema
    validationSchema: Yup.object({
      username: Yup.string().required('Username is required'),
      password: Yup.string().required('Password is required')
    }),

    // Submit Handler
    onSubmit: async (values) => {
      signIn(values);
    }
  });

  // Redirect to the callback URL after successful login
  useEffect(() => {
    if (isSuccess) {
      if (callBackUrl) {
        router.push(callBackUrl);
      } else router.push('/');
    }
  }, [callBackUrl, isSuccess, router]);

  return (
    <div>
      <Box
        color={(theme: any) =>
          theme.palette.mode === 'light'
            ? theme?.palette?.title?.light
            : theme?.palette?.title?.dark
        }
        sx={{
          height: '100vh',
          display: 'flex',
          minWidth: 0,
          flex: 'auto',
          flexDirection: 'column',
          alignItems: 'center',

          justifyContent: 'center',
          '& > :not(style) + :not(style)': {
            marginTop: '16px'
          },
          '@media (min-width: 600px)': {
            justifyContent: 'center'
          }
        }}
      >
        <Paper
          sx={{
            minHeight: 'full',
            width: 'full',
            paddingX: '16px',
            paddingY: '32px',
            borderRadius: '24px',
            background: (theme: any) =>
              theme.palette.mode === 'light'
                ? theme?.palette?.card?.light
                : theme?.palette?.card?.dark,
            '@media (min-width: 600px)': {
              minHeight: 'auto',
              width: 'auto',
              padding: '48px',
              boxShadow: 'sm'
            }
          }}
        >
          <Box
            sx={{
              marginLeft: 'auto',
              marginRight: 'auto',
              width: 'full',
              maxWidth: '320px',

              '@media (min-width: 600px)': {
                marginLeft: 0,
                marginRight: 0,
                width: '320px'
              }
            }}
          >
            <Image
              width={50}
              height={50}
              className="w-48"
              style={{
                width: '48px',
                height: '48px'
              }}
              src="/assets/images/auth/logo.svg"
              alt="logo"
            />

            <Typography
              sx={{
                marginTop: '32px',
                fontSize: '2.25rem', // 4xl
                fontWeight: '800', // font-extrabold
                lineHeight: '1.125', // leading-tight
                letterSpacing: '-0.025em' // tracking-tight
              }}
              color={(theme: any) =>
                theme.palette.mode === 'light'
                  ? theme?.palette?.title?.light
                  : theme?.palette?.title?.dark
              }
            >
              Sign in
            </Typography>
            <Box
              sx={{
                marginTop: '2px',
                display: 'flex',
                alignItems: 'baseline',
                fontWeight: '500', // font-medium
                color: (theme: any) =>
                  theme.palette.mode === 'light'
                    ? theme?.palette?.secondary?.light
                    : theme?.palette?.secondary?.dark
              }}
            >
              <Typography
                color={(theme: any) =>
                  theme.palette.mode === 'light'
                    ? theme?.palette?.subtitle?.light
                    : theme?.palette?.subtitle?.dark
                }
              >
                Don&apos;t have an account?
              </Typography>
              <MuiLink href=""> Sign up</MuiLink>
            </Box>

            <form
              onSubmit={formik.handleSubmit}
              name="loginForm"
              noValidate
              style={{
                marginTop: '15px',
                display: 'flex',
                width: '100%',
                flexDirection: 'column',
                justifyContent: 'center'
              }}
            >
              <AuthTextField
                label="Username"
                placeholder="hi@example.com"
                type="username"
                name="username"
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                value={formik.values.username}
                error={formik.touched.username ? formik.errors.username : ('' as any)}
                variant="outlined"
              />
              <Typography
                fontSize={14}
                color={(theme: any) =>
                  theme.palette.mode === 'light'
                    ? theme?.palette?.primary?.light
                    : theme?.palette?.primary?.dark
                }
              >
                Username: +8801942504420
              </Typography>

              <AuthTextField
                label="Password"
                placeholder="Enter password"
                type="password"
                name="password"
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                value={formik.values.password}
                error={formik.touched.password ? formik.errors.password : ('' as any)}
                sx={{
                  marginTop: '16px'
                }}
              />
              <Typography
                fontSize={14}
                color={(theme: any) =>
                  theme.palette.mode === 'light'
                    ? theme?.palette?.primary?.light
                    : theme?.palette?.primary?.dark
                }
              >
                Pass: admin
              </Typography>
              {error && (
                <Typography
                  color="error"
                  sx={{
                    marginTop: '16px',
                    fontSize: '14px',
                    fontStyle: 'italic'
                  }}
                >
                  {/*
                  // @ts-ignore */}
                  {error?.data?.detail}
                </Typography>
              )}
              <Button
                variant="contained"
                // color="red"
                sx={{
                  marginTop: '16px',
                  width: '100%',
                  borderRadius: '30px',
                  fontSize: '15px',
                  textTransform: 'capitalize'
                }}
                aria-label="Sign in"
                type="submit"
              >
                Sign In
              </Button>

              <Box
                sx={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  marginTop: '16px'
                }}
              >
                <MuiLink href="">Forgot password?</MuiLink>
                <MuiLink href="">Resend OTP</MuiLink>
              </Box>
            </form>
          </Box>
        </Paper>
      </Box>
    </div>
  );
};

export default SignIn;
