import { Box, TextField } from '@mui/material';
import React, { useState } from 'react';
import { inputLabelClasses } from '@mui/material';
import IconButton from '@mui/material/IconButton';
import Visibility from '@mui/icons-material/Visibility';
import VisibilityOff from '@mui/icons-material/VisibilityOff';

type authFieldProps = {
  label: string;
  type: string;
  name: string;
  placeholder: string;
};

const AuthTextField = (authField: authFieldProps | any) => {
  const { name, label, type, placeholder, ...rest } = authField || {};

  const textFieldStyle = {
    inputField: {
      color: (theme: any) =>
        theme.palette.mode === 'light' ? theme?.palette?.title?.light : theme?.palette?.title?.dark,
      '&:hover .MuiOutlinedInput-notchedOutline': {
        borderColor: (theme: any) =>
          theme.palette.mode === 'light'
            ? theme?.palette?.primary?.light
            : theme?.palette?.primary?.dark
      },
      '& .MuiOutlinedInput-root': {
        '&.Mui-focused fieldset': {
          borderColor: (theme: any) =>
            theme.palette.mode === 'light'
              ? theme?.palette?.primary?.light
              : theme?.palette?.primary?.dark
        }
      },
      position: 'relative'
    },
    labelArea: {
      sx: {
        [`&.${inputLabelClasses.shrink}`]: {
          color: (theme: any) =>
            theme.palette.mode === 'light'
              ? theme?.palette?.primary?.light
              : theme?.palette?.primary?.dark
        }
      }
    }
  };
  const [showPassword, setShowPassword] = useState(false);
  const [password, setPassword] = useState('');

  const handleTogglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  // const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
  //   setPassword(e.target.value);
  // };
  return (
    <Box
      sx={{
        position: 'relative'
        // backgroundColor: 'red'
      }}
    >
      <TextField
        sx={{ ...textFieldStyle.inputField }}
        InputLabelProps={{
          ...textFieldStyle.labelArea
        }}
        variant="outlined"
        required
        fullWidth
        name={name}
        label={label}
        placeholder={placeholder}
        type={type === 'password' && showPassword ? 'text' : type}
        {...rest}
      />
      {type === 'password' && (
        <IconButton
          onClick={handleTogglePasswordVisibility}
          sx={{
            position: 'absolute',
            right: '3px',
            top: '24px'
            // borderRadius: '5px'
          }}
        >
          {showPassword ? <VisibilityOff /> : <Visibility />}
        </IconButton>
      )}
    </Box>
  );
};

export default AuthTextField;
