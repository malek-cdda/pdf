import { Box, Checkbox, FormControl, FormControlLabel } from '@mui/material';
import React from 'react';

const AuthCheckBox = () => {
  return (
    <Box
      sx={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        '@media (min-width: 600px)': {
          flexDirection: 'row',
          justifyContent: 'space-between'
        }
      }}
    >
      <FormControl>
        <FormControlLabel
          label="I agree to the Terms of Service and Privacy Policy"
          //  i want to label color change when checked

          sx={{
            '& .MuiFormControlLabel-label': {
              color: (theme: any) =>
                theme.palette.mode === 'light'
                  ? theme?.palette?.subtitle?.light
                  : theme?.palette?.subtitle?.dark
            }
          }}
          control={
            <Checkbox
              size="small"
              sx={{
                '&.Mui-checked': {
                  color: (theme: any) =>
                    theme.palette.mode === 'light'
                      ? theme?.palette?.primary?.light
                      : theme?.palette?.primary?.dark
                }
              }}
            />
          }
        />
      </FormControl>
    </Box>
  );
};

export default AuthCheckBox;
