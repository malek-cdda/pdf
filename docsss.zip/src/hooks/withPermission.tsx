import { useState, ComponentType } from 'react';

type UserRole = 'admin' | 'manager' | 'user' | 'superadmin';

const withPermission = <P extends {}>(
  WrappedComponent: ComponentType<P>,
  allowedRoles: UserRole[],
  componentName: string
) => {
  console.log(`permisstion/check?component=${componentName}`);
  const WrapperComponent: React.FC<P> = (props) => {
    const [userRole, setUserRole] = useState<UserRole | null>('manager');
    if (userRole === null) {
      return null;
    }
    if (!allowedRoles.includes(userRole)) {
      return null;
    }
    return <WrappedComponent {...props} />;
  };
  return WrapperComponent;
};

export default withPermission;
