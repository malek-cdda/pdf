'use client';

import { createContext, useContext } from 'react';

const ConfirmationModalContext = createContext(null);

export const useConfirmationModalContext = () => {
  return useContext(ConfirmationModalContext);
};

export default ConfirmationModalContext;
