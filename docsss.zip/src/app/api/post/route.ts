// app/api/api.ts
import { v4 as uuidv4 } from 'uuid';

let posts: Post[] = [
  { id: '1', title: 'Post 1' },
  { id: '2', title: 'Post 2' }
];

export interface Post {
  id: string;
  title: string;
}

export const GET = async (request: Request) => {
  return new Response(JSON.stringify(posts));
};

export const POST = async (request: Request) => {
  const { title }: { title: string } = await request.json();
  const newPost: Post = { id: uuidv4(), title };
  posts.push(newPost);
  return new Response(JSON.stringify(newPost), { status: 201 });
};

export const PUT = async (request: Request) => {
  const { id, title: updatedTitle }: { id: string; title: string } = await request.json();
  const postIndex = posts.findIndex((post) => post.id === id);
  if (postIndex === -1) {
    return new Response(JSON.stringify({ message: 'Post not found' }), { status: 404 });
  }
  posts[postIndex] = { ...posts[postIndex], title: updatedTitle };
  return new Response(JSON.stringify(posts[postIndex]));
};

export const DELETE = async (request: Request) => {
  const { searchParams } = new URL(request.url);
  const deleteId = searchParams.get('id');
  posts = posts.filter((post) => post.id !== deleteId);
  return new Response(JSON.stringify({ message: 'Post deleted' }));
};
