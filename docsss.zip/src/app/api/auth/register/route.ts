import { NextResponse } from 'next/server';
// import bcrypt from 'bcrypt';
export async function POST(request: Request) {
  try {
    const { first_name, last_name, email, confirmPassword } = await request.json();
    console.log({ first_name, last_name, email, confirmPassword });

    // const hashedPassword = await bcrypt.hash(confirmPassword, 10);
    // console.log(hashedPassword);
  } catch (e) {
    console.log({ e });
  }

  return NextResponse.json({ message: 'success' });
}
