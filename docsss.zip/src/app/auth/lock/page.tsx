'use client';

import { Box, Button, Paper, TextField, Typography } from '@mui/material';
import Image from 'next/image';
import AuthTextField from '../components/AuthTextField';
import MuiLink from '@/components/common/MuiLink';

function UnlockSession() {
  return (
    <Box
      sx={{
        height: '100vh',
        display: 'flex',
        minWidth: 0,
        flex: 'auto',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        '& > :not(style) + :not(style)': {
          marginTop: '16px'
        },
        '@media (min-width: 600px)': {
          justifyContent: 'center'
        }
      }}
    >
      <Paper
        sx={{
          minHeight: 'full',
          width: 'full',

          paddingX: '16px',
          paddingY: '32px',
          borderRadius: '24px',
          background: (theme: any) =>
            theme.palette.mode === 'light'
              ? theme?.palette?.card?.light
              : theme?.palette?.card?.dark,
          '@media (min-width: 600px)': {
            minHeight: 'auto',
            width: 'auto',
            borderRadius: '2xl',
            padding: '48px',
            boxShadow: 'sm'
          }
        }}
      >
        <Box
          sx={{
            marginLeft: 'auto',
            marginRight: 'auto',
            width: 'full',
            maxWidth: '320px',
            '@media (min-width: 600px)': {
              marginLeft: 0,
              marginRight: 0,
              width: '320px'
            }
          }}
        >
          <Image
            width={50}
            height={50}
            className="w-48"
            style={{
              width: '48px',
              height: '48px'
            }}
            src="/assets/images/auth/logo.svg"
            alt="logo"
          />

          <Typography
            sx={{
              marginTop: '32px',
              fontSize: '32px', // 4xl
              fontWeight: '800', // font-extrabold
              lineHeight: '1.125', // leading-tight
              letterSpacing: '-0.025em' // tracking-tight
            }}
            color={(theme: any) =>
              theme.palette.mode === 'light'
                ? theme?.palette?.title?.light
                : theme?.palette?.title?.dark
            }
          >
            Unlock your session
          </Typography>
          <Box
            sx={{
              marginTop: '2px',
              display: 'flex',
              alignItems: 'baseline',
              fontWeight: '500' // font-medium
            }}
            color={(theme: any) =>
              theme.palette.mode === 'light'
                ? theme?.palette?.subtitle?.light
                : theme?.palette?.subtitle?.dark
            }
          >
            <Typography>Your session is locked due to inactivity</Typography>
          </Box>

          <form
            name="loginForm"
            noValidate
            style={{
              marginTop: '24px',
              display: 'flex',
              width: '100%',
              flexDirection: 'column',
              justifyContent: 'center'
            }}
            // onSubmit={handleSubmit(onSubmit)}
          >
            {/* textfield component   */}
            <AuthTextField
              label="Full name"
              placeholder="Enter Name"
              type="text"
              name="name"
              // onChange={formik.handleChange}
              // onBlur={formik.handleBlur}
              // value={formik.values.password}
              // error={formik.touched.password ? formik.errors.password : ('' as any)}
              sx={{
                marginTop: '16px'
              }}
            />
            <AuthTextField
              label="Password"
              placeholder="Enter password"
              type="password"
              name="password"
              // onChange={formik.handleChange}
              // onBlur={formik.handleBlur}
              // value={formik.values.password}
              // error={formik.touched.password ? formik.errors.password : ('' as any)}
              sx={{
                marginTop: '16px'
              }}
            />
            <Button
              variant="contained"
              // color="red"
              sx={{
                marginTop: '16px',
                width: '100%',
                borderRadius: '30px',
                fontSize: '15px',
                textTransform: 'capitalize'
              }}
              aria-label="Sign in"
              type="submit"
            >
              Unlock your session
            </Button>

            <Box
              sx={{
                marginTop: '32px',
                display: 'flex',
                alignItems: 'center'
              }}
            >
              <Box
                sx={{
                  marginTop: '1px' // 1px is equivalent to px

                  // Assuming you want a solid border
                }}
              >
                I&apos;m no
              </Box>
              <MuiLink
                sx={{
                  margin: '8px'
                }}
                href="/"
              >
                Brian Hughes
              </MuiLink>
            </Box>
          </form>
        </Box>
      </Paper>
    </Box>
  );
}

export default UnlockSession;
