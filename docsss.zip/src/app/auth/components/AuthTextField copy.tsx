'use client';
import { TextField } from '@mui/material';
import React, { useState } from 'react';
import { Box, inputLabelClasses } from '@mui/material';
type authFieldProps = {
  label: string;
  type: string;
  name: string;
  placeholder: string;
  //   value: string;
  // onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
};
import IconButton from '@mui/material/IconButton';
import Visibility from '@mui/icons-material/Visibility';
import VisibilityOff from '@mui/icons-material/VisibilityOff';

type handleChangeProps = (e: React.ChangeEvent<HTMLInputElement>) => void;
const AuthTextField = ({
  authField
  // handleChange
}: {
  authField: authFieldProps;
  // handleChange: handleChangeProps;
}) => {
  const { name, label, type, placeholder } = authField;

  const textFieldStyle = {
    inputField: {
      color: (theme: any) =>
        theme.palette.mode === 'light' ? theme?.palette?.title?.light : theme?.palette?.title?.dark,
      marginBottom: '32px',
      '&:hover .MuiOutlinedInput-notchedOutline': {
        borderColor: (theme: any) =>
          theme.palette.mode === 'light'
            ? theme?.palette?.primary?.light
            : theme?.palette?.primary?.dark
      },
      '& .MuiOutlinedInput-root': {
        '&.Mui-focused fieldset': {
          borderColor: (theme: any) =>
            theme.palette.mode === 'light'
              ? theme?.palette?.primary?.light
              : theme?.palette?.primary?.dark
        }
      }
    },
    labelArea: {
      sx: {
        [`&.${inputLabelClasses.shrink}`]: {
          color: (theme: any) =>
            theme.palette.mode === 'light'
              ? theme?.palette?.primary?.light
              : theme?.palette?.primary?.dark
        }
      }
    }
  };
  const [showPassword, setShowPassword] = useState(false);
  const [password, setPassword] = useState('');

  const handleTogglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPassword(e.target.value);
  };
  return (
    <div>
      sdfasdf
      <TextField
        sx={{ ...textFieldStyle.inputField }}
        InputLabelProps={{
          ...textFieldStyle.labelArea
        }}
        variant="outlined"
        required
        fullWidth
        name={name}
        label={label}
        placeholder={placeholder}
        type={type}
        onChange={(e: React.ChangeEvent<HTMLInputElement>) => handleChange(e)}
      />
    </div>
  );
};

export default AuthTextField;
