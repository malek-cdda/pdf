import { AUTH_LOGIN } from '@/lib/endPoints';
import { apiSlice } from '@/redux/features/api/apiSlice';
import { setCookie } from '@/utils/cookies';

export const authApiSlice = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    signIn: builder.mutation({
      query: (data) => ({
        url: AUTH_LOGIN,
        method: 'POST',
        body: data
      }),
      async onQueryStarted(arg, { queryFulfilled, dispatch }) {
        try {
          const { data } = await queryFulfilled;
          const { access, refresh } = data || {};
          setCookie('access', access, { expires: new Date(Date.now() + 1000 * 60 * 15) }); // 15 minutes in milliseconds
          setCookie('refresh', refresh, { expires: new Date(Date.now() + 1000 * 60 * 60 * 24) }); // 24 hours in milliseconds
        } catch (error) {}
      }
    }),
    signOut: builder.mutation({
      query: () => ({
        url: `/auth/logout`,
        method: 'GET'
      })
    })
  })
});

export const { useSignInMutation, useSignOutMutation } = authApiSlice;
