import React from 'react';

const InitLoader = () => {
  return (
    <div className="initLoader">
      {/* <div className="loading-spinner" /> */}
      <div className="loader"></div>
    </div>
  );
};

export default InitLoader;
