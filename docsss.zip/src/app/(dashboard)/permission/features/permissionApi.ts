import { apiSlice } from '@/redux/features/api/apiSlice';

export const permissionApi: any = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    getPermissions: builder.query({
      query: () => ({
        url: `/permissions`
      }),
      providesTags: ['Permissions']
    }),

    getPermissionsWithType: builder.query({
      query: ({ limit = 100000, type }) => ({
        url: `/permissions?type=${type}`
      })
    }),

    getPermission: builder.query({
      query: (uid) => ({
        url: `/permissions/${uid}`
      }),
      providesTags: (result, error, uid) => [{ type: 'Permission', uid }]
    }),

    createPermission: builder.mutation({
      query: (data) => ({
        url: '/permissions',
        method: 'POST',
        body: data
      }),
      invalidatesTags: ['Permissions'],

      async onQueryStarted(arg, { dispatch, queryFulfilled }) {
        // pessimistic cache update
        try {
          const { data: createdRole } = await queryFulfilled;

          console.log(createdRole, 'createdRole');
          // update get tasks cache, when new task is added
          dispatch(
            apiSlice.util.updateQueryData('getPermissions', undefined, (draft: any[]) => {
              draft.push(createdRole);
            })
          );
        } catch (err) {
          console.log(err);
        }
      }
    }),

    editPermission: builder.mutation({
      query: ({ uid, data }) => ({
        url: `/permissions/${uid}`,
        method: 'PUT',
        body: data
      }),
      // In this case, `getPost` will be re-run. `getPosts` *might*  rerun, if this id was under its results.
      invalidatesTags: (result, error, { uid }) => ['Permissions'],

      async onQueryStarted({ uid, data }, { dispatch, queryFulfilled }) {
        try {
          const { data: role } = await queryFulfilled;
          dispatch(
            apiSlice.util.updateQueryData(
              'getPermissions',
              {
                limit: 10,
                type: undefined
              },
              (draft) => {
                console.log(JSON.stringify(draft), 'draft');
                return draft.map((item) => (item?.uid === uid ? role : item));
              }
            )
          );
        } catch (err) {
          console.log(err);
        }
      }
    }),

    deletePermission: builder.mutation({
      query: (uid) => ({
        url: `/permissions/${uid}`,
        method: 'DELETE'
      }),
      invalidatesTags: (result, error, { uid }) => ['Permissions'],
      async onQueryStarted(arg, { dispatch, queryFulfilled }) {
        // optimistic update, update when getTask's cache, when task is deleted
        console.log(apiSlice.util, 'role');
        const patchResult = dispatch(
          apiSlice.util.updateQueryData('getPermission', undefined, (draft) => {
            return draft.filter((role) => role.uid !== arg);
          })
        );

        try {
          await queryFulfilled;
        } catch (err) {
          patchResult.undo();
        }
      }
    }),

    getUserPermissionList: builder.query({
      query: (uid) => ({
        url: `/users/permissions`
      }),
      providesTags: (result, error, uid) => ['UserPermissions']
    }),

    createUserPermission: builder.query({
      query: (uid) => ({
        url: `/users/permissions`
      }),
      invalidatesTags: ['UserPermissions']
    })
  })
});

export const {
  useGetPermissionsQuery,
  useGetPermissionsWithTypeQuery,
  useGetPermissionQuery,
  useCreatePermissionMutation,
  useEditPermissionMutation,
  useDeletePermissionMutation,
  useGetUserPermissionListQuery,
  useCreateUserPermissionMutation
} = permissionApi;
