import { renderInputs } from '@/utils/renderInputs';
import { buildInitialValuesAndValidationSchema } from '@/utils/valuesWithSchema';
import { Button } from '@mui/material';
import { useFormik } from 'formik';
// import { useCreateAgentUserMutation, useUpdateAgentUserMutation } from '../features/ag'
import { useFetchUserRolesQuery } from '../../navigation/features/navEditorApi';
import { MultiSelect, Text } from '@/components/Fields';

import * as Yup from 'yup';
import {
  useCreatePermissionMutation,
  useEditPermissionMutation,
  useGetPermissionsQuery,
  useGetPermissionsWithTypeQuery,
  useGetUserPermissionListQuery
} from '../features/permissionApi';
import { useEffect } from 'react';

const validationSchema = Yup.object().shape({
  roles: Yup.array().min(1, 'At least one role is required'),
  type: Yup.object().required('Type is required'),
  component_name: Yup.string().when('type', {
    is: (value: any) => value.value === 'COMPONENT',
    then: (schema: any) => schema.required('Component name is required'),
    otherwise: (schema: any) => schema
  }),
  api_route: Yup.object().when('type', {
    is: (value: any) => value.value === 'API',
    then: (schema) => schema.required('API Route is required'),
    otherwise: (schema) => schema
  }),
  page_route: Yup.object().when('type', {
    is: (value: any) => value.value === 'PAGE',
    then: (schema) => schema.required('PAGE Route is required'),
    otherwise: (schema) => schema
  }),
  permission_method_list: Yup.array().when('type', {
    is: (value: any) => value.value === 'API',
    then: (schema) => schema.min(1, 'At least one method is required'),
    otherwise: (schema) => schema
  })
});

const AddUserForm = ({ setOpen, isEdit, data: editData, setEditData }: any) => {
  const {
    data: permissioinsData,
    isLoading: isPermissionDataLoading,
    isSuccess: isPermissionDataSuccess
  } = useGetPermissionsWithTypeQuery({ type: 'API' });

  const {
    data: pagePermissionData,
    isLoading: isPagePermissionDataLoading,
    isSuccess: isPagePermissionDataSuccess
  } = useGetPermissionsWithTypeQuery({ type: 'PAGE' });

  const {
    data: rolesData,
    isLoading: isRolesDataLoading,
    isSuccess: isRolesDataSuccess
  } = useFetchUserRolesQuery({});

  const [
    editPermission,
    { isLoading: isEditPermissionLoading, isSuccess: isPermissionEditSuccess }
  ] = useEditPermissionMutation({
    skip: !isEdit
  });

  const {
    data: permissionListData,
    isLoading: isPermissionListDataLoading,
    isSuccess: isPermissionListDataSuccess
  } = useGetUserPermissionListQuery();

  const [
    createPermission,
    { isLoading: isCreatePermissionLoading, isSuccess: isPermissionCreateSuccess }
  ] = useCreatePermissionMutation();

  const editInitialData = {
    type: {
      value: editData?.type,
      label: editData?.type
    },
    component_name: editData?.component_name || '',
    api_route: {
      value: editData?.api_route,
      label: editData?.api_route
    },
    page_route: {
      value: editData?.page_route,
      label: editData?.page_route
    },
    permission_method_list: editData?.permission_method?.map((item: any) => item?.name),
    roles: editData?.roles_read_only?.map((item: any) => item?.role?.name),
    description: editData?.description
  };

  // Define form fields
  const permissionForm = [
    {
      id: '1',
      name: 'roles',
      type: 'select',
      placeholder: 'Select Roles',
      label: 'Select Roles',
      variant: 'outlined', // outlined, filled, standard
      options: rolesData?.map((item: any) => item.name),
      validations: [
        {
          type: 'min',
          value: 1,
          message: 'At least one role is required'
        }
      ],
      multiple: true,
      defaultValue: []
    },
    {
      id: '2',
      name: 'type',
      type: 'select',
      placeholder: 'Select Type',
      label: 'Type',
      variant: 'outlined', // outlined, filled, standard
      defaultValue: {
        value: 'PAGE',
        label: 'Page'
      },
      options: [
        {
          value: 'PAGE',
          label: 'Page'
        },
        {
          value: 'COMPONENT',
          label: 'Component'
        },
        {
          value: 'API',
          label: 'API'
        }
      ],
      validations: [
        {
          type: 'required',
          value: true,
          message: 'Message is required'
        }
      ],
      multiple: false
    },
    {
      id: '3',
      name: 'component_name',
      type: 'text',
      placeholder: 'Enter your component name',
      label: 'Component Name',
      variant: 'outlined', // outlined, filled, standard
      defaultValue: '',
      validations: [
        {
          type: 'when',
          field: 'type',
          is: 'COMPONENT',
          message: 'Component name is required'
        }
      ]
    },
    {
      id: '4',
      name: 'api_route',
      type: 'select',
      placeholder: 'Select API Route',
      label: 'API Route',
      variant: 'outlined', // outlined, filled, standard
      defaultValue: permissioinsData
        ?.filter((item: any) => item?.api_route)
        ?.map((item: any) => ({
          value: item?.api_route,
          label: item?.api_route
        }))?.[0] || {
        value: '',
        label: ''
      },
      options:
        permissioinsData?.length > 0
          ? permissioinsData
              ?.filter((item: any) => item?.api_route)
              ?.map((item: any) => ({
                value: item?.api_route,
                label: item?.api_route
              }))
          : [],
      validations: [
        {
          type: 'required',
          value: true,
          message: 'Message is required'
        }
      ],
      multiple: false
    },

    {
      id: '5',
      name: 'page_route',
      type: 'select',
      placeholder: 'Select API Route',
      label: 'Page Route',
      variant: 'outlined', // outlined, filled, standard
      defaultValue: pagePermissionData
        ?.filter((item: any) => item?.page_route)
        ?.map((item: any) => ({
          value: item?.page_route,
          label: item?.page_route
        }))?.[0],
      options: pagePermissionData
        ?.filter((item: any) => item?.page_route)
        ?.map((item: any) => ({
          value: item?.page_route,
          label: item?.page_route
        })),
      validations: [
        {
          type: 'required',
          value: true,
          message: 'Message is required'
        }
      ],
      multiple: false
    },
    {
      id: '6',
      name: 'permission_method_list',
      type: 'select',
      placeholder: 'Select Method List',
      label: 'Method List',
      variant: 'outlined', // outlined, filled, standard
      defaultValue: ['GET'],
      options: ['GET', 'POST', 'UPDATE', 'DELETE', 'RETRIEVE'],
      validations: [
        {
          type: 'required',
          value: true,
          message: 'Message is required'
        }
      ],
      multiple: true
    },
    {
      id: '7',
      name: 'description',
      type: 'text',
      placeholder: 'Enter your description',
      label: 'Description',
      variant: 'outlined', // outlined, filled, standard
      defaultValue: '',
      validations: []
    }
  ];

  console.log('editInitialData', editInitialData, editData);

  // Build initial values and validation schema
  const { initialValues, validationSchema: nnn } = buildInitialValuesAndValidationSchema({
    fields: permissionForm
  });

  // define formik form with initial values and validation schema
  const formik = useFormik({
    initialValues: isEdit ? editInitialData : initialValues,
    // initialValues,
    validationSchema,
    onSubmit: async (values: any, { setSubmitting }) => {
      try {
        // page data
        const pageData = {
          roles: rolesData
            ?.filter((item: any) => values.roles.includes(item.name))
            ?.map((item: any) => item.uid),
          type: values.type.value,
          page_route: values.page_route.value,
          description: values.description
        };

        // component data
        const componentData = {
          roles: rolesData
            ?.filter((item: any) => values.roles.includes(item.name))
            .map((item: any) => item.uid),
          type: values.type.value,
          component_name: values.component_name,
          description: values.description
        };

        // api data
        const apiData = {
          roles: rolesData
            ?.filter((item: any) => values?.roles?.includes(item.name))
            ?.map((item: any) => item.uid),
          type: values.type.value,
          api_route: values.api_route.value,
          permission_method_list: values.permission_method_list,
          description: values.description
        };

        if (isEdit) {
          await editPermission({
            uid: editData.uid,
            data:
              values.type.value === 'PAGE'
                ? pageData
                : values.type.value === 'COMPONENT'
                  ? componentData
                  : apiData
          });
          // setEditData(null);
          if (isPermissionEditSuccess) {
            formik.resetForm();
          }
        } else {
          await createPermission(
            values.type.value === 'PAGE'
              ? pageData
              : values.type.value === 'COMPONENT'
                ? componentData
                : apiData
          );

          if (isPermissionCreateSuccess) {
            formik.resetForm();
          }
        }
      } catch (error: any) {
        console.log('Error occurred during fetch request:', error);
      }
      // Set formik submitting to false
      setSubmitting(false);
    },
    // Enable reinitialize to update the form values
    enableReinitialize: true
  });

  useEffect(() => {
    if (isPermissionCreateSuccess || isPermissionEditSuccess) {
      setOpen(false);
    }
  }, [isPermissionCreateSuccess, isPermissionEditSuccess, setOpen]);

  // Render the form
  return (
    <form
      onSubmit={formik.handleSubmit}
      style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}
    >
      {/* Type field  */}
      <MultiSelect
        id={permissionForm[1]?.id}
        name={permissionForm[1]?.name}
        formik={formik}
        label={permissionForm[1]?.label}
        options={permissionForm[1]?.options}
        key={permissionForm[1]?.id}
        multiple={permissionForm[1]?.multiple}
        disabled={isEdit}
      />

      {/* Component name field */}
      {formik.values?.type?.value === 'COMPONENT' ? (
        <Text
          formik={formik}
          id={permissionForm[2]?.id}
          label={permissionForm[2]?.label}
          name={permissionForm[2]?.name}
          type={permissionForm[2]?.type}
        />
      ) : null}

      {/* API Routes field */}
      {formik.values?.type?.value === 'API' ? (
        <MultiSelect
          id={permissionForm[3]?.id}
          name={permissionForm[3]?.name}
          formik={formik}
          label={permissionForm[3]?.label}
          options={permissionForm[3]?.options}
          key={permissionForm[3]?.id}
          multiple={permissionForm[3]?.multiple}
        />
      ) : null}
      {/* Page Routes field */}
      {formik.values?.type?.value === 'PAGE' ? (
        <MultiSelect
          id={permissionForm[4]?.id}
          name={permissionForm[4]?.name}
          formik={formik}
          label={permissionForm[4]?.label}
          options={permissionForm[4]?.options}
          key={permissionForm[4]?.id}
          multiple={permissionForm[4]?.multiple}
        />
      ) : null}

      {/* Method list field */}
      {formik.values?.type?.value === 'API' ? (
        <MultiSelect
          id={permissionForm[5]?.id}
          name={permissionForm[5]?.name}
          formik={formik}
          label={permissionForm[5]?.label}
          options={permissionForm[5]?.options}
          key={permissionForm[5]?.id}
          multiple={permissionForm[5]?.multiple}
        />
      ) : null}

      {/* Roles field */}
      <MultiSelect
        id={permissionForm[0]?.id}
        name={permissionForm[0]?.name}
        formik={formik}
        label={permissionForm[0]?.label}
        options={permissionForm[0]?.options}
        key={permissionForm[0]?.id}
        multiple={permissionForm[0]?.multiple}
      />

      {/* Description Field  */}
      <Text
        formik={formik}
        id={permissionForm[6]?.id}
        label={permissionForm[6]?.label}
        name={permissionForm[6]?.name}
        type={permissionForm[6]?.type}
      />

      <Button sx={{ mt: 3 }} type="submit" variant="contained">
        Submit
      </Button>
    </form>
  );
};

export default AddUserForm;
