'use client';

import PageHeader from '@/components/PageHeader/PageHeader';
import { Box, Button, Stack } from '@mui/material';
import React, { useEffect, useState } from 'react';
import PreviewContent from '../PreviewContent';
import EditorPanel from '../../playground/components/editor/Editor';
import {
  useAgreementModelQuery,
  useEditAgreementMutation,
  useGetAgreementQuery,
  useStateAgreementQuery,
  useUserMacrosQuery
} from '../agreement/features/agreementApi';
import MultiSelect from '../components/MultiSelect';
import SingleSelect from '../components/SingleSelect';

const TemplateEditor = ({ params }: { params: { slug: string | any } }) => {
  const [codeValue, setCodeValue] = useState('');
  const [stateValue, setStateValue] = useState([]);
  const [macroValue, setMacroValue] = useState('');
  // state data list for multi select
  const { data: stateListData, isLoading: stateLoading, isError } = useStateAgreementQuery();
  // get macros list
  const {
    data: macrosListData,
    isLoading: macroLoading,
    isError: macroError
  } = useUserMacrosQuery();
  // get models data
  const { data: modelDataList } = useAgreementModelQuery();
  const {
    data: agreement,
    isLoading: agreementLoading,
    isError: agreementError
  } = useGetAgreementQuery(params?.editor);
  console.log(modelDataList, 'modelDataList');
  const handleSchemaValueChange = (value: any) => {
    setCodeValue(value);
  };
  const [editAgreement, { isLoading }] = useEditAgreementMutation();
  // update agreement api data on save
  const handleAgreementUpdate = () => {
    editAgreement({
      uid: params?.editor,
      data: {
        label: 'agreement-1asdas',
        body: codeValue,
        default: false,
        state: stateValue
      }
    });
  };
  const [editorValue, setEditorValue] = useState(agreement?.body || '');

  if (isError || macroError) return <div>Error</div>;
  if (stateLoading || macroLoading) return <div>Loading...</div>;
  return (
    <>
      <PageHeader
        title="Template Editor"
        desc="Contrary to popular belief, Lorem Ipsum is not simply random text"
      />
      {/* multi select component  */}
      <MultiSelect state={stateListData} setStateValue={setStateValue} />
      <SingleSelect macros={macrosListData} setMacro={setStateValue} />
      <Stack height="calc(100vh - 207px)" direction="row" justifyContent="space-between" gap={2}>
        <Box width="50%" height="100%">
          <EditorPanel
            language="html"
            title="Template Editor"
            path="tetst.json"
            defaultValue={agreement?.body}
            onChange={handleSchemaValueChange}
            height="calc(100vh - 230px)"
          />
          <Button
            variant="contained"
            color="primary"
            disabled={isLoading}
            sx={{
              marginTop: '10px',
              marginBottom: '10px'
            }}
            // onClick={() => handleAgreementUpdate()}
          >
            Save
          </Button>
        </Box>
        <Box
          width="50%"
          bgcolor="gray"
          sx={{
            height: '100%',
            overflow: 'auto'
          }}
        >
          <PreviewContent value={codeValue} />
        </Box>
      </Stack>
    </>
  );
};

export default TemplateEditor;
