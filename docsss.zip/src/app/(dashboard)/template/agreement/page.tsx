'use client';
import PageHeader from '@/components/PageHeader/PageHeader';
import React, { useEffect, useState } from 'react';
import List from '../List';
import { Box, Button, Stack, TextField } from '@mui/material';
import PreviewContent from '../PreviewContent';
import {
  useGetAgreementsQuery,
  useGetAgreementQuery,
  useDeleteAgreementMutation,
  useUserMacrosQuery,
  useStateAgreementQuery,
  useCreateAgreementMutation
} from './features/agreementApi';
import GlobalModal from '@/components/Modal/GlobalModal';
import SingleSelect from '../components/SingleSelect';
import MultiSelect from '../components/MultiSelect';
import { set } from 'nprogress';

const Aggrement = () => {
  const [open, setOpen] = useState(false);
  const [stateValue, setStateValue] = useState([]);
  const [agreementUid, setAgreementUid] = React.useState('');
  const [agreementLabel, setAgreementLabel] = useState('');
  const [agreementDescription, setAgreementDescription] = useState('');
  const { data: agreementList, isLoading, isError } = useGetAgreementsQuery();
  const [deleteAgreement] = useDeleteAgreementMutation();
  const {
    data: stateListData,
    isLoading: stateLoading,
    isError: stateError
  } = useStateAgreementQuery();
  const {
    data: agreement,
    isLoading: agreementLoading,
    isError: agreementError
  } = useGetAgreementQuery(agreementUid);
  // create agreement data on save
  const [createAgreement, { isLoading: createLoading, isError: createError }] =
    useCreateAgreementMutation();
  const handleCreate = async (event: any) => {
    event.preventDefault();
    const formData = {
      label: agreementLabel,
      body: agreementDescription,
      state: stateValue,
      default: false
    };
    createAgreement(formData).then((res: any) => {
      setOpen(false);
      setAgreementLabel('');
      setAgreementDescription('');
    });
  };
  useEffect(() => {
    if (agreementList?.length) {
      setAgreementUid(agreementList[0]?.uid);
    }
  }, [agreementList]);
  console.log(deleteAgreement, 'deleteAgreement', agreementUid);
  const handleUid = async (uid: string) => {
    setAgreementUid(uid);
  };

  const handleDeleteAgreement = (uid: string) => {
    deleteAgreement(uid);
  };

  if (isError || stateError) return <div>Error</div>;
  if (isLoading || stateLoading) return <div>Loading...</div>;

  return (
    <Box
      sx={{
        height: 'calc(100vh - 200px)'
      }}
    >
      <Stack direction="row" alignItems="center">
        <PageHeader
          title="Aggrement"
          desc="Contrary to popular belief, Lorem Ipsum is not simply random text"
        />
        <Button
          variant="contained"
          color="primary"
          onClick={() => {
            setOpen(true);
          }}
        >
          Create
        </Button>
      </Stack>
      {agreementList.length && (
        <Box
          sx={{
            height: '100%',
            display: 'flex',
            gap: '20px'
          }}
        >
          <Box
            sx={{
              width: '30%',
              height: '100%',
              display: 'flex',
              flexDirection: 'column',
              gap: '10px',
              overflowY: 'auto'
            }}
          >
            {agreementList.map((item: any, index: number) => (
              <List
                key={item.id}
                item={item}
                handleUid={handleUid}
                handleDeleteAgreement={handleDeleteAgreement}
              />
            ))}
          </Box>
          <Box
            sx={{
              width: '100%',
              height: '100%',
              overflowY: 'auto',
              display: 'flex',
              justifyContent: 'center'
            }}
          >
            <PreviewContent value={agreement?.body} />
          </Box>
        </Box>
      )}
      <GlobalModal open={open} setOpen={setOpen} title="Create Agreement">
        <form onSubmit={handleCreate}>
          <TextField
            fullWidth
            sx={{ marginBottom: '20px' }}
            placeholder="Enter Agreement Label"
            value={agreementLabel}
            onChange={(event) => setAgreementLabel(event.target.value)}
          />
          <TextField
            fullWidth
            sx={{ marginBottom: '20px' }}
            placeholder="Enter Agreement Description"
            value={agreementDescription}
            onChange={(event) => setAgreementDescription(event.target.value)}
          />
          <MultiSelect state={stateListData} setStateValue={setStateValue} />

          <Button type="submit" variant="contained" color="primary">
            Create
          </Button>
        </form>
      </GlobalModal>
    </Box>
  );
};

export default Aggrement;
