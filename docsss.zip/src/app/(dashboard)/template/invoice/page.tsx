import React from 'react'

const InvoiceTemplate = () => {
  return (
    <div>InvoiceTemplate</div>
  )
}

export default InvoiceTemplate