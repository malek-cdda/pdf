import { Box, Typography } from '@mui/material';
import React from 'react';
import PricingCard from './PricingCard';
const pricing = [
  {
    title: 'Starter',
    price: 9.99,
    features: [
      '1 User',
      'Basic Support',
      '10GB Storage',
      'Unlimited Access',
      'Custom Domain',
      'SSL Certificate',
      'Shared Hosting',
      'Email Support'
    ],
    description: 'Ideal for individuals or small businesses getting started online.'
  },
  {
    title: 'Business',
    price: 24.99,
    features: [
      '5 Users',
      'Priority Support',
      '50GB Storage',
      'Unlimited Access',
      'Custom Domain',
      'SSL Certificate',
      'Dedicated Hosting',
      '24/7 Support',
      'Data Migration Assistance',
      'Daily Backups',
      'Regular Updates',
      'Enhanced Security'
    ],
    description: 'Perfect for growing businesses needing more resources and support.'
  },
  {
    title: 'Enterprise',
    price: 49.99,
    features: [
      'Unlimited Users',
      'Dedicated Support Manager',
      '100GB Storage',
      'Unlimited Access',
      'Custom Domain',
      'Extended SSL Certificate',
      'Cloud Hosting',
      'Custom Support SLA',
      'Seamless Data Migration',
      'Automated Backups',
      'Priority Updates',
      'Advanced Security Measures',
      'SEO Optimization',
      'Marketing Assistance',
      'Advertisement Campaigns'
    ],
    description:
      'Tailored for large corporations requiring high-performance infrastructure and personalized service.'
  }
];

function Pricing() {
  return (
    <Box>
      <Typography
        variant="h2"
        sx={{
          textAlign: 'center'
        }}
      >
        Pricing
      </Typography>
      <Box
        sx={{
          display: 'flex',
          alignItems: 'start',
          gap: '1rem',
          padding: '1rem',
          margin: 'auto 15rem'
        }}
      >
        {pricing?.map((item, i) => (
          <PricingCard
            key={i}
            title={item.title}
            price={item.price}
            features={item.features}
            description={item?.description}
          />
        ))}
      </Box>
    </Box>
  );
}

export default Pricing;
