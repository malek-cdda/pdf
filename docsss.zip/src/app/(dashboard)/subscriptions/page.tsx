'use client';

import { Box, Button, Stack, Typography } from '@mui/material';
import React, { useState } from 'react';
import Pricing from './components/Pricing';
import { useGetAvailableSubscriptionQuery } from './features/subscriptionApi';
import { useFormik } from 'formik';
import { buildInitialValuesAndValidationSchema } from '@/utils/valuesWithSchema';
import { renderInputs } from '@/utils/renderInputs';
import HeaderTitle from '@/components/HeaderTitle/HeaderTitle';
import GlobalModal from '@/components/Modal/GlobalModal';
import SubscriptionForm from './components/SubscriptionForm';
import SubscriptionList from './components/SubscriptionList';

function Page() {
  const [open, setOpen] = useState(false);
  const { data, isLoading } = useGetAvailableSubscriptionQuery({});

  const neededData = {
    label: '',
    name: '',
    description: '',
    price: 1200,
    duration: 30,
    metered: true,
    per_request_fee: 10, // if metered true
    trial: true,
    trial_days: 10, // if trial true
    trial_description: '', // if trial true
    icon_image: ''
  };

  console.log(data, 'subscription data');
  return (
    <Box>
      {/* subscriptions page header */}
      <Stack direction="row" justifyContent="space-between" alignItems="center" mb={2}>
        <HeaderTitle
          title={'Subscriptions'}
          description={
            'Manage all the subscriptions here. You can add, edit and delete the subscriptions.'
          }
        />
        <Button variant="contained" onClick={() => setOpen(true)}>
          Add New Subscription
        </Button>
      </Stack>
      {open && (
        <GlobalModal
          title={
            <Typography variant="h5" component="div">
              Add New Subscription
            </Typography>
          }
          setOpen={setOpen}
          open={open}
        >
          {/* // Add Subscription Form */}
          <SubscriptionForm setModalClose={setOpen} />
        </GlobalModal>
      )}
      {/* subscriptions List Table */}
      <SubscriptionList />
      {/* Prcing section */}
      <Pricing />
    </Box>
  );
}

export default Page;
