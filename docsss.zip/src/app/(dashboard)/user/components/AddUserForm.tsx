import { renderInputs } from '@/utils/renderInputs';
import { buildInitialValuesAndValidationSchema } from '@/utils/valuesWithSchema';
import { Button, Typography } from '@mui/material';
// @ts-ignore
import { useFormik } from 'formik';
import * as Yup from 'yup';
import { useFetchUserRolesQuery } from '../../navigation/features/navEditorApi';
import {
  useCreateUserMutation,
  useGetUsersQuery,
  useUpdateUserMutation
} from '../features/userApi';
import { memo, useState } from 'react';
import AddressAutocomplete from '@/components/AddressAutocomplete/AddressAutocomplete';

const AddUserForm = ({ setOpen, isEdit, data: editData, setEditData, mls }: any) => {
  const [createUser, { error: createError }] = useCreateUserMutation();
  const [updateUser, { error: updateError }] = useUpdateUserMutation();
  const { data: roleData } = useFetchUserRolesQuery({});
  const errorData: any = createError || updateError;

  console.log('mls', mls);

  // Get MLS users
  const { data: mlsUser } = useGetUsersQuery({ role__name: 'MLS' });

  // define initial address data
  const [addressData, setAddressData] = useState(
    editData?.address || {
      street: '',
      city: '',
      state: '',
      zip_code: '',
      country: '',
      full_address: '',
      latitude: '',
      longitude: ''
    }
  );

  // Define form fields
  const data = [
    {
      id: 'FirstName',
      name: 'first_name',
      type: 'text',
      placeholder: 'Enter your First Name',
      label: 'First Name',
      variant: 'outlined', // outlined, filled, standard
      defaultValue: '',
      validations: [
        {
          type: 'required',
          value: true,
          message: 'First name is required'
        }
      ]
    },
    {
      id: 'LastName',
      name: 'last_name',
      type: 'text',
      placeholder: 'Enter your Last Name',
      label: 'Last Name',
      variant: 'outlined', // outlined, filled, standard
      defaultValue: '',
      validations: [
        {
          type: 'required',
          value: true,
          message: 'Last name is required'
        }
      ]
    },
    {
      id: 'Email',
      name: 'email',
      type: 'text',
      placeholder: 'Enter your email',
      label: 'Email',
      variant: 'outlined', // outlined, filled, standard
      defaultValue: '',
      validations: [
        {
          type: 'required',
          value: true,
          message: 'Email is required'
        },
        {
          type: 'email',
          value: true,
          message: 'Enter a valid email'
        }
      ]
    },
    {
      id: 'phoneInput',
      name: 'phone',
      type: 'phone',
      placeholder: 'Enter your phone number',
      label: 'Phone',
      variant: 'outlined', // outlined, filled, standard
      defaultCountry: 'US',
      defaultValue: '',
      onlyCountries: ['US'],
      validations: [
        {
          type: 'required',
          value: true,
          message: 'Phone is required'
        }
      ]
    },
    {
      id: 'role',
      name: 'role_uid',
      type: 'select',
      placeholder: 'Select Role',
      label: 'Role',
      variant: 'outlined', // outlined, filled, standard
      options: roleData?.map((obj: any) => ({
        value: obj.uid,
        label: obj.label
      })),
      validations: [
        {
          type: 'required',
          value: true,
          message: 'Message is required'
        }
      ],
      multiple: false
    },
    !mls && {
      id: 'mls',
      name: 'mls_uid',
      type: 'select',
      label: 'MLS Role',
      variant: 'outlined', // outlined, filled, standard
      defaultValue: false,
      // @ts-ignore
      options: mlsUser?.map((obj: any) => ({
        value: obj.uid,
        label: `${obj.first_name} ${obj.last_name}`
      })),
      validations: [
        {
          type: 'required',
          value: true,
          message: 'Message is required'
        }
      ],
      multiple: false
    },
    !isEdit && {
      id: 'password',
      name: 'password',
      type: 'password',
      placeholder: 'Enter your password',
      label: 'Password',
      variant: 'outlined', // outlined, filled, standard
      defaultValue: '',
      validations: [
        {
          type: 'required',
          value: true,
          message: 'Message is required'
        },
        {
          type: 'min',
          value: 8,
          message: 'Password must be greater than 8'
        }
      ]
    }
  ];

  // Build initial values and validation schema
  const { initialValues, validationSchema } = buildInitialValuesAndValidationSchema({
    fields: data
  });

  // Define validation schema for the address object
  const addressSchema = Yup.object().shape({
    street: Yup.string().required('Street is required'),
    city: Yup.string().required('City is required'),
    state: Yup.string().required('State is required'),
    zip_code: Yup.string().required('Zip code is required'),
    country: Yup.string().required('Country is required'),
    full_address: Yup.string().required('Full address is required'),
    latitude: Yup.string().required('Latitude is required'),
    longitude: Yup.string().required('Longitude is required')
  });

  // Merge validation schemas
  const mergedSchema = validationSchema.shape({
    address: addressSchema
  });

  // define formik form with initial values and validation schema
  const initValues = isEdit
    ? {
        first_name: editData.first_name,
        last_name: editData.last_name,
        email: editData.email,
        phone: editData.phone,
        role_uid: editData.role,
        address: addressData,
        ...(!mls && {
          mls_uid: {
            value: editData.parent?.uid,
            label: `${editData.parent?.first_name} ${editData.parent?.last_name}`
          }
        })
      }
    : {
        ...initialValues,
        address: addressData
      };

  // Formik setup
  const formik = useFormik({
    initialValues: initValues,
    validationSchema: mergedSchema,
    onSubmit: async (values: any, { setSubmitting }: any) => {
      try {
        // Call the create user mutation
        const newUser = !mls
          ? {
              ...values,
              phone: values.phone.replace(/\s/g, ''),
              mls_uid: values.mls_uid.value || values.mls_uid.uid,
              role_uid: values.role_uid.value || values.role_uid.uid
            }
          : {
              ...values,
              phone: values.phone.replace(/\s/g, ''),
              role_uid: values.role_uid.value || values.role_uid.uid
            };

        // Call the create user mutation
        const data: any = isEdit
          ? await updateUser({ ...newUser, id: editData.uid })
          : await createUser(newUser);

        if (!data?.error) {
          setOpen(false);
          setEditData({});
        }
      } catch (error: any) {
        console.log('Error occurred during fetch request:', error);
      }
      // Set formik submitting to false
      setSubmitting(false);
    },
    // Enable reinitialize to update the form values
    enableReinitialize: true
  });

  // Render the form
  return (
    <form
      onSubmit={formik.handleSubmit}
      style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}
    >
      {data.map((item) => {
        return renderInputs({ item, formik });
      })}

      <AddressAutocomplete
        formik={formik}
        name="address"
        setAddressData={setAddressData}
        isDetails
      />

      {/* {(createError || updateError) && (
        <Typography
          color="error"
          sx={{
            marginTop: '3px',
            fontSize: '14px',
            fontStyle: 'italic'
          }}
        >
          {createError?.data?.role_uid?.detail || updateError?.data?.detail}
        </Typography>
      )} */}

      {Boolean(errorData) && (
        <Typography
          color="error"
          sx={{
            marginTop: '3px',
            fontSize: '14px',
            fontStyle: 'italic'
          }}
        >
          {Object.entries(errorData?.data || {}).map(([key, value]) => (
            <span key={key}>{(value as string[])[0]}</span>
          ))}
        </Typography>
      )}

      <Button type="submit" variant="contained">
        Submit
      </Button>
    </form>
  );
};

export default memo(AddUserForm);
