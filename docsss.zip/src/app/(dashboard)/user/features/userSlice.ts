// app/userSlice.js
import { createSlice } from '@reduxjs/toolkit';

export const userSlice = createSlice({
  name: 'user',
  initialState: {
    data: null,
    loading: true,
    error: null
  },
  reducers: {
    setUserLoading: (state, action) => {
      state.loading = action.payload;
    },
    setUser: (state, action) => {
      state.loading = false;
      state.error = null;
      state.data = action.payload;
    },
    setUserError: (state, action) => {
      state.loading = false;
      state.error = action.payload;
    }
  }
});

export const { setUserLoading, setUser, setUserError } = userSlice.actions;

export default userSlice.reducer;
