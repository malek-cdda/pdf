import React from 'react';
import Users from '../components/Users';

const MlsUser = () => {
  return (
    <>
      <Users mls />
      {/* <AddressAutocomplete /> */}
    </>
  );
};

export default MlsUser;
