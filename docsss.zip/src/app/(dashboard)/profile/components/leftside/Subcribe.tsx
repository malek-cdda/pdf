import { Box, Typography, alpha } from '@mui/material';
import React from 'react';
import SubItem from './SubItem';

const subcribeItem = [{ name: 'this is test', value: '100/month' }];
function Subcribe() {
  return (
    <Box
      color={(theme: any) =>
        theme.palette.mode === 'light'
          ? alpha(theme.palette.title.light, 0.9)
          : alpha(theme.palette.title.dark, 0.9)
      }
      pt={1}
    >
      <Typography
        variant="subtitle1"
        sx={{
          marginTop: '1rem',
          textTransform: 'uppercase',
          fontSize: '.9rem',
          opacity: 0.7
        }}
        gutterBottom
      >
        Subcription
      </Typography>
      {subcribeItem.map((item, i) => (
        <SubItem key={i} data={item} />
      ))}
    </Box>
  );
}

export default Subcribe;
