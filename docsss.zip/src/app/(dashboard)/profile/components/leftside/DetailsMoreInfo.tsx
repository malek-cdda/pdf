import { Box, Typography, alpha } from '@mui/material';
import React from 'react';
import SubItem from './SubItem';

const userDetails = [
  { name: 'Owner Name', value: 'Test name' },
  { name: 'Company Type', value: 'Private Limited' },
  { name: 'Company Name', value: 'Test Company' },
  { name: 'Company Address', value: 'Test Address' },
  { name: 'Company Phone', value: '1234567890' }
];
function DetailsMoreInfo() {
  return (
    <Box
      color={(theme: any) =>
        theme.palette.mode === 'light'
          ? alpha(theme.palette.title.light, 0.9)
          : alpha(theme.palette.title.dark, 0.9)
      }
    >
      <Typography
        variant="subtitle1"
        sx={{
          marginTop: '1rem',
          textTransform: 'uppercase',
          fontSize: '.9rem',
          opacity: 0.7
        }}
        gutterBottom
      >
        Details
      </Typography>
      {userDetails.map((item, i) => (
        <SubItem key={i} data={item} />
      ))}
    </Box>
  );
}

export default DetailsMoreInfo;
