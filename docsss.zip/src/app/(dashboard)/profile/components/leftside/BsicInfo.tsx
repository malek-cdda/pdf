'use client';
import { Box, Typography, alpha } from '@mui/material';
import SupportAgentIcon from '@mui/icons-material/SupportAgent';
import BusinessCenterIcon from '@mui/icons-material/BusinessCenter';
import React from 'react';

function BsicInfo() {
  return (
    <Box
      color={(theme: any) =>
        theme.palette.mode === 'light'
          ? alpha(theme.palette.title.light, 0.9)
          : alpha(theme.palette.title.dark, 0.9)
      }
      sx={{
        display: 'flex',
        justifyContent: 'space-around',
        gap: '1rem',
        paddingTop: '2rem',
        paddingBottom: '1.5rem',
        borderBottom: '1px solid #ccc'
      }}
    >
      {/* agent */}
      <Box
        sx={{
          display: 'flex',
          alignItems: 'center',
          gap: '.5rem'
        }}
      >
        <Box
          sx={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            width: '40px',
            height: '40px',
            backgroundColor: (theme) => alpha(theme.palette.primary.main, 0.3),
            borderRadius: '5px'
          }}
        >
          <SupportAgentIcon />
        </Box>
        <Box>
          <Typography variant="body2">Agent</Typography>
          <Typography variant="body2">20</Typography>
        </Box>
      </Box>
      {/* buyer */}
      <Box
        sx={{
          display: 'flex',
          alignItems: 'center',
          gap: '.5rem'
        }}
      >
        <Box
          sx={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            width: '40px',
            height: '40px',
            backgroundColor: (theme) => alpha(theme.palette.primary.main, 0.3),
            borderRadius: '5px'
          }}
        >
          <BusinessCenterIcon />
        </Box>
        <Box>
          <Typography variant="body2">Buyer</Typography>
          <Typography variant="body2">100</Typography>
        </Box>
      </Box>
    </Box>
  );
}

export default BsicInfo;
