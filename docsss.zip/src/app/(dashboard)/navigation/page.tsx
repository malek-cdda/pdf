'use client';
import { Autocomplete, Chip, Grid, TextField } from '@mui/material';
import React, { useEffect } from 'react';
import UserRoles from './components/UserRoles';
import Positions from './components/Positions';
import Paths from './components/Paths';
import NavigationEditor from './components/NavigationEditor';
// import {
//   fetchPaths,
//   fetchPositions,
//   fetchUserRoles,
//   selectPosition,
//   selectRole
// } from './features/navigationEditorSlice';
import { pathsData, positionsData, rolesData } from './dummyData';
import { useAppDispatch } from '@/redux/hooks';
import { fetchPaths, fetchPositions, fetchUserRoles } from './features/navEditorSlice';

const Navigation = () => {
  const dispatch = useAppDispatch();
  useEffect(() => {
    dispatch(fetchPositions(positionsData));
  }, [dispatch]);
  return (
    <>
      <Grid
        container
        height={`calc(100vh-170px)`}
        color={(theme: any) =>
          theme.palette.mode === 'light'
            ? theme?.palette?.title?.light
            : theme?.palette?.title?.dark
        }
      >
        {/* <Grid item xs={2} pr={1}>
          <UserRoles />
        </Grid>
        <Grid item px={1} xs={2}>
          <Positions />
        </Grid> */}
        <Grid item px={1} xs={3}>
          <Paths />
        </Grid>
        <Grid item pl={1} xs={9}>
          <NavigationEditor />
        </Grid>
      </Grid>
    </>
  );
};

export default Navigation;
