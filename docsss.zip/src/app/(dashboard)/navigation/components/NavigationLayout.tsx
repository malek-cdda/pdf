import { Box, Stack, Typography, alpha } from '@mui/material';
import React from 'react';

type NavigationLayoutProps = {
  children: React.ReactNode;
  title?: string;
  actions?: React.ReactNode;
};

const NavigationLayout = ({ children, title, actions }: NavigationLayoutProps) => {
  return (
    <Box
      height={'100%'}
      bgcolor={(theme: any) =>
        theme.palette.mode === 'light' ? theme?.palette?.card?.light : theme?.palette?.card?.dark
      }
      sx={{ borderRadius: 1, pt: 1, boxShadow: 1 }}
    >
      <Stack direction={'row'} justifyContent={'space-between'} alignItems={'center'} pb={1}>
        <Typography variant="h5" sx={{ px: 2, textTransform: 'uppercase' }}>
          {title}
        </Typography>
        {actions && actions}
      </Stack>

      <Stack spacing={1} height={'calc(100vh - 195px)'} px={2} overflow={'auto'}>
        {children}
      </Stack>
    </Box>
  );
};

export default NavigationLayout;
