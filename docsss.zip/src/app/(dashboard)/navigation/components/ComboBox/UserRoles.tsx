import { Autocomplete, Chip, TextField } from '@mui/material';
import React from 'react';
import { useAppDispatch, useAppSelector } from '@/redux/hooks';
import { selectRole } from '../../features/navEditorSlice';
import { useFetchUserRolesQuery } from '../../features/navEditorApi';

const UserRoles = () => {
  const dispatch = useAppDispatch();
  const { data: userRoles, isLoading, isError, isSuccess } = useFetchUserRolesQuery({});
  // const userRoles = useAppSelector((state: any) => state.navEditor?.userRoles);
  const selectedRole = useAppSelector((state: any) => state.navEditor?.selectedRole);
  return (
    <>
      <Autocomplete
        disablePortal
        id="combo-box"
        options={isSuccess ? userRoles : []}
        loading={isLoading}
        size="small"
        sx={{
          width: 300,
          '& .MuiOutlinedInput-root': {
            '&:hover fieldset': {
              borderColor: 'primary.main'
            }
          }
        }}
        slotProps={{}}
        // value={selectedRole}
        onChange={(event, newValue: any) => {
          dispatch(selectRole(newValue));
          // setIcon(newValue);
        }}
        // isOptionEqualToValue={(option, value) => option.uid === value.uid}
        renderTags={(value, getTagProps) =>
          value.map((option, index) => (
            <>
              <Chip
                variant="outlined"
                label={option}
                {...getTagProps({ index })}
                // disabled={disabled}
              />
            </>
          ))
        }
        renderInput={(params) => <TextField {...params} label="User Roles" />}
      />
    </>
  );
};

export default UserRoles;
