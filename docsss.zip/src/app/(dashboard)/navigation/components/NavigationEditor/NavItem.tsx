import IconSearch from '@/components/IconHandler/IconSearch';
import { Box, Fab, InputBase, InputLabel, Stack, alpha } from '@mui/material';
import React, { useState } from 'react';
import SaveIcon from '@mui/icons-material/Save';
import BorderColorIcon from '@mui/icons-material/BorderColor';
import DeleteIcon from '@mui/icons-material/Delete';
import SyncIcon from '@mui/icons-material/Sync';
import { useAppDispatch } from '@/redux/hooks';
import { removeNavPath, updateNavPathItem } from '../../features/navEditorSlice';

const NavItem = ({ item }: any) => {
  const dispatch = useAppDispatch();
  const [disabled, setDisabled] = useState(true);
  const [isEdit, setIsEdit] = useState(false);
  const [label, setLabel] = useState(item.label);
  const [icon, setIcon] = useState(item.icon);

  const handleSave = () => {
    const updatedItem = {
      ...item,
      label: label,
      icon: icon
    };
    dispatch(updateNavPathItem(updatedItem));
    setDisabled(true);
    setIsEdit(false);
  };

  return (
    <Box
      component={'div'}
      sx={{
        backgroundColor: (theme) =>
          theme.palette.mode === 'light'
            ? alpha(theme?.palette?.primary?.light, 0.1)
            : alpha(theme?.palette?.primary?.dark, 0.1),
        borderRadius: 1,
        cursor: 'pointer',
        '&:hover': {
          backgroundColor: (theme) =>
            theme.palette.mode === 'light'
              ? alpha(theme?.palette?.primary?.light, 0.2)
              : alpha(theme?.palette?.primary?.dark, 0.2),
          transition: '200ms'
        }
      }}
    >
      <Stack direction="row" spacing={2} p={2} alignItems="center">
        {/* icons combo-box */}
        <Stack direction={'row'} spacing={5} flexGrow={1}>
          <Box>
            <InputLabel
              //   htmlFor={`${item._id}+label`}
              sx={{
                fontSize: '12px',
                fontWeight: '600',
                color: (theme: any) =>
                  theme.palette.mode === 'light'
                    ? alpha(theme.palette.title.light, 0.9)
                    : alpha(theme.palette.title.dark, 0.9)
              }}
            >
              Icon
            </InputLabel>
            <IconSearch selectedIcon={icon} setSelectedIcon={setIcon} disabled={disabled} />
          </Box>
          {/* navigation label  */}
          <Box component={'div'}>
            <InputLabel
              htmlFor={`${item._id}+label`}
              sx={{
                fontSize: '12px',
                fontWeight: '600',
                color: (theme: any) =>
                  theme.palette.mode === 'light'
                    ? alpha(theme.palette.title.light, 0.9)
                    : alpha(theme.palette.title.dark, 0.9)
              }}
            >
              Label
            </InputLabel>
            <InputBase
              type="text"
              id={`${item._id}+label`}
              value={label}
              onChange={(e) => setLabel(e.target.value)}
              disabled={disabled}
              sx={{
                border: '2px solid',
                borderColor: isEdit ? 'primary.main' : '#ccc',
                borderRadius: 1,
                padding: '0.5rem',
                color: (theme: any) =>
                  theme.palette.mode === 'light'
                    ? theme.palette.title.light
                    : theme.palette.title.dark,
                '&:focus': {
                  borderColor: 'red'
                }
                // '& .MuiInputBase-input': {
                //   borderRadius: 4,
                //   position: 'relative',
                //   // backgroundColor: 'red',

                //   fontSize: 16,
                //   width: 'auto',
                //   padding: '10px 12px'
                // }
              }}
            />
          </Box>
        </Stack>
        {/* action buttons */}
        <Stack direction="row" spacing={2} ml="auto">
          {/* save button  */}
          <Fab
            // onClick={() => {
            //   setDisabled(true);
            //   setIsEdit(false);
            // }}
            onClick={handleSave}
            sx={{
              display: disabled ? 'none' : 'block',
              height: 40,
              width: 40,
              borderRadius: 1,
              color: 'primary.contrastText',
              bgcolor: (theme: any) =>
                theme.palette.mode === 'light'
                  ? alpha(theme?.palette?.success?.light, 0.6)
                  : alpha(theme?.palette?.success?.dark, 0.6),
              '&:hover': {
                bgcolor: (theme: any) =>
                  theme.palette.mode === 'light'
                    ? alpha(theme?.palette?.success?.light, 0.8)
                    : alpha(theme?.palette?.success?.dark, 0.8)
              }
            }}
          >
            <SaveIcon />
          </Fab>
          {/* edit button  */}
          <Fab
            onClick={() => {
              setDisabled(false);
              setIsEdit(true);
            }}
            sx={{
              display: disabled ? 'block' : 'none',
              height: 40,
              width: 40,
              borderRadius: 1,
              color: 'primary.contrastText',
              bgcolor: (theme: any) =>
                theme.palette.mode === 'light'
                  ? alpha(theme?.palette?.primary?.light, 0.6)
                  : alpha(theme?.palette?.primary?.dark, 0.6),
              '&:hover': {
                bgcolor: (theme: any) =>
                  theme.palette.mode === 'light'
                    ? alpha(theme?.palette?.primary?.light, 0.8)
                    : alpha(theme?.palette?.primary?.dark, 0.8)
              }
            }}
          >
            <BorderColorIcon />
          </Fab>
          {/* delete button  */}
          <Fab
            onClick={() => dispatch(removeNavPath(item.id))}
            sx={{
              height: 40,
              width: 40,
              borderRadius: 1,
              color: 'primary.contrastText',
              bgcolor: (theme: any) =>
                theme.palette.mode === 'light'
                  ? alpha(theme?.palette?.error?.light, 0.6)
                  : alpha(theme?.palette?.error?.dark, 0.6),
              '&:hover': {
                bgcolor: (theme: any) =>
                  theme.palette.mode === 'light'
                    ? alpha(theme?.palette?.error?.light, 0.8)
                    : alpha(theme?.palette?.error?.dark, 0.8)
              }
            }}
          >
            <DeleteIcon />
          </Fab>
        </Stack>
      </Stack>
    </Box>
  );
};

export default NavItem;
