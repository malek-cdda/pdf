import recursiveFind from './recursiveFind';

//@ts-ignore
const handleUpdateNavigation = async (items, setNavigation) => {
  const deepCopy = JSON.parse(JSON.stringify(items.items));
  setNavigation(items.items);
  const postData = recursiveFind(deepCopy, items.dragItem._id);
};

export default handleUpdateNavigation;
