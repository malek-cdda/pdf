const isPermissionAlreadyAdded = (nav: any, permission: number) => {
  if (nav.permission === permission) {
    return true;
  }
  if (nav.children) {
    for (let i = 0; i < nav.children.length; i++) {
      if (isPermissionAlreadyAdded(nav.children[i], permission)) {
        return true;
      }
    }
  }
  return false;
};

const navPathChecker = (navigationList: any, permissionId: number) => {
  for (let i = 0; i < navigationList.length; i++) {
    if (isPermissionAlreadyAdded(navigationList[i], permissionId)) {
      return true;
    }
  }
  return false;
};

export default navPathChecker;
