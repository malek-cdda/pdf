//@ts-ignore
const recursiveFind = (array, id) => {
  for (let i = 0; i < array.length; i += 1) {
    const node = array[i];
    if (node._id === id) {
      return {
        ...node,
        parent_id: '',
        index: i + 1,
        path: node.path?.['$oid']
      };
    }
    if (node.children?.length > 0) {
      //@ts-ignore
      const found = recursiveFind(node.children, id);
      if (found) {
        //@ts-ignore
        const findAgain = node.children.find((c) => c._id === id);
        return {
          ...found,
          parent_id: node._id,
          index: node.children.indexOf(findAgain) + 1,
          path: node.path?.['$oid']
        };
      }
    }
  }
};

export default recursiveFind;
