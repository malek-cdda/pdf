function updateItem(array: any[], newItem: any) {
  return array.map((item) => {
    if (item.id === newItem.id) {
      return { ...item, ...newItem }; // Merge the existing item with the updated item
    } else if (item.children && item.children.length) {
      // Recursively update the item in children arrays
      item.children = updateItem(item.children, newItem);
    }
    return item; // Return the original item if it's not the one to update
  });
}

export default updateItem;
