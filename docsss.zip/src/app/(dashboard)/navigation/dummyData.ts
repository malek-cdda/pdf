export const navigationsData = [
  {
    _id: '64e73e7318778f60b493d8fe',
    index: 1,
    icon: 'HiArchive',
    label: 'Digital Asset'
  },
  {
    _id: '65cc9154a906978b04b21ed0',
    index: 2,
    icon: 'HiShieldCheck',
    label: 'Check SSL Date'
  },
  {
    _id: '65c08ca0cfe3565cc7b952ea',
    index: 3,
    icon: 'HiAcademicCap',
    label: 'Events'
  },
  {
    _id: '64c8e1434f90f553a0e68280',
    index: 4,
    icon: 'HiClipboardCheck',
    label: 'Matching Funds'
  },
  {
    _id: '658a97c70d939ea2c713be46',
    index: 5,
    icon: 'HiArrowsExpand',
    label: 'Ads'
  },
  {
    _id: '64105f3db44302950de74654',
    index: 6,
    icon: 'HiCash',
    label: 'All Transaction'
  },
  {
    _id: '643817630b78d8a943171b75',
    index: 7,
    icon: 'HiSpeakerphone',
    label: 'Campaigns'
  },
  {
    _id: '63e64c149e0d61880d63598f',
    index: 8,
    icon: 'HiOutlinePhoneMissedCall',
    label: 'Call History'
  },
  {
    _id: '64788c4043af70c88ab8066e',
    index: 9,
    icon: 'HiAnnotation',
    label: 'Sms logs'
  },
  {
    _id: '64788c4243af70c88ab8066f',
    index: 10,
    icon: 'HiOutlineMail',
    label: 'Email logs'
  },
  {
    _id: '65e3eb0b2cfaed1213ecda7a',
    index: 11,
    icon: 'HiArchive',
    label: 'All Buybox'
  },
  {
    _id: '63b3cd00714b685cba99cc3c',
    index: 12,
    icon: 'HiUserGroup',
    label: 'All Partner',
    children: [
      {
        parent_id: '63b3cd00714b685cba99cc3c',
        _id: '63b3cd3c714b685cba99cc3e',
        index: 1,
        icon: 'HiMinusSm',
        label: 'Contact List'
      },
      {
        parent_id: '63b3cd00714b685cba99cc3c',
        _id: '63b3cd22714b685cba99cc3d',
        index: 2,
        icon: 'HiMinusSm',
        label: 'Partners'
      },
      {
        parent_id: '63b3cd00714b685cba99cc3c',
        _id: '65b728bca010f9d742929835',
        index: 3,
        icon: 'HiAcademicCap',
        label: 'Premium Request'
      }
    ]
  },
  {
    _id: '63ff4cd990a23f6bc636c809',
    index: 13,
    icon: 'HiOutlineUserGroup',
    label: 'All Users'
  },
  {
    _id: '656459182b5e1fbc00037900',
    index: 14,
    icon: 'HiBan',
    label: 'Draft Users'
  },
  {
    _id: '63b40cc711682d825ce3469c',
    index: 15,
    icon: 'HiUsers',
    label: 'All Employees'
  },
  {
    _id: '63b2d6214d90fd562725c156',
    index: 16,
    icon: 'HiOfficeBuilding',
    label: 'All Properties'
  },
  {
    _id: '63b2d67c4d90fd562725c172',
    index: 17,
    icon: 'HiChartSquareBar',
    label: 'All Closings'
  },
  {
    _id: '63b3b6b7cc03c411f4a1f3a2',
    index: 18,
    icon: 'HiBadgeCheck',
    label: 'Sales history'
  },
  {
    _id: '6463219735a9036c72df0255',
    index: 19,
    icon: 'HiCash',
    label: 'Funding Company'
  },
  {
    _id: '63ff4ce690a23f6bc636c80b',
    index: 20,
    icon: 'HiOutlineOfficeBuilding',
    label: 'Payouts'
  },
  {
    _id: '63b2d65d4d90fd562725c167',
    index: 21,
    icon: 'HiOutlineCurrencyDollar',
    label: 'Payment Approval'
  },
  {
    _id: '63b2d6a34d90fd562725c17c',
    index: 22,
    icon: 'HiOutlineCurrencyDollar',
    label: 'All Payments'
  },
  {
    _id: '63a4636574fc127b4cff36f2',
    index: 23,
    icon: 'HiMenuAlt1',
    label: 'Menu & Path',
    children: [
      {
        parent_id: '63a4636574fc127b4cff36f2',
        _id: '63a4639374fc127b4cff36f4',
        index: 1,
        icon: '',
        label: 'Role'
      },
      {
        parent_id: '63a4636574fc127b4cff36f2',
        _id: '63a463c174fc127b4cff36f7',
        index: 2,
        icon: '',
        label: 'Enum'
      },
      {
        parent_id: '63a4636574fc127b4cff36f2',
        _id: '63a463b374fc127b4cff36f5',
        index: 3,
        icon: '',
        label: 'Permission'
      },
      {
        parent_id: '63a4636574fc127b4cff36f2',
        _id: '63a463b774fc127b4cff36f6',
        index: 4,
        icon: '',
        label: 'Navigation'
      }
    ]
  },
  {
    _id: '63a45eda5b37c24b890bf2ba',
    index: 24,
    icon: 'HiViewGridAdd',
    label: 'Template & Content',
    children: [
      {
        parent_id: '63a45eda5b37c24b890bf2ba',
        _id: '63ba62f7dad979f6134018e9',
        index: 1,
        icon: '',
        label: 'Agreement'
      },
      {
        parent_id: '63a45eda5b37c24b890bf2ba',
        _id: '63a45fa25b37c24b890bf2bb',
        index: 2,
        icon: '',
        label: 'Email Template'
      },
      {
        parent_id: '63a45eda5b37c24b890bf2ba',
        _id: '63a45fa25b37c24b890bf2bc',
        index: 3,
        icon: '',
        label: 'Contents'
      },
      {
        parent_id: '63a45eda5b37c24b890bf2ba',
        _id: '63a45fac5b37c24b890bf2bd',
        index: 4,
        icon: '',
        label: 'SMS Template'
      }
    ]
  }
];

export const pathsData = [
  {
    _id: {
      $oid: '63a2def8c6935765073bf33e'
    },
    path: '/app/api-docs'
  },
  {
    _id: {
      $oid: '63a2def8c6935765073bf38b'
    },
    path: '/admin/partner/view'
  },
  {
    _id: {
      $oid: '63a2def9c6935765073bf3ac'
    },
    path: '/admin/settings/contents'
  },
  {
    _id: {
      $oid: '63a2def9c6935765073bf550'
    },
    path: '/app/settings/personal'
  },
  {
    _id: {
      $oid: '63a2def9c6935765073bf587'
    },
    path: '/app/settings/signin-security'
  },
  {
    _id: {
      $oid: '63ad3f09c693576507f68206'
    },
    path: '/admin/payout-approval'
  },
  {
    _id: {
      $oid: '63b2b55bc6935765075ef042'
    },
    path: '/admin/properties'
  },
  {
    _id: {
      $oid: '63e64bc8bb119e45bba660b0'
    },
    path: '/call/history'
  },
  {
    _id: {
      $oid: '64380d96df4e42f8b9b10c30'
    },
    path: '/app/announcement'
  },
  {
    _id: {
      $oid: '63a2def8c6935765073bf375'
    },
    path: '/admin/partner/applicant-view'
  },
  {
    _id: {
      $oid: '63a2def9c6935765073bf396'
    },
    path: '/admin/settings/announcment'
  },
  {
    _id: {
      $oid: '63a2def9c6935765073bf3b7'
    },
    path: '/admin/settings/default-setting'
  },
  {
    _id: {
      $oid: '63a2def9c6935765073bf3c2'
    },
    path: '/admin/settings/email-template'
  },
  {
    _id: {
      $oid: '63a2def9c6935765073bf41a'
    },
    path: '/admin/settings/server'
  },
  {
    _id: {
      $oid: '63a3f579975a3377296511d5'
    },
    path: '#'
  },
  {
    _id: {
      $oid: '63b2da03c69357650761eeb3'
    },
    path: '/admin/history'
  },
  {
    _id: {
      $oid: '646f4afc35f2ffa7e98bab72'
    },
    path: '/admin/settings/coupon'
  },
  {
    _id: {
      $oid: '63a2def9c6935765073bf3a1'
    },
    path: '/admin/settings/collection'
  },
  {
    _id: {
      $oid: '63a2def9c6935765073bf3e3'
    },
    path: '/admin/settings/maintenance'
  },
  {
    _id: {
      $oid: '63a2def9c6935765073bf3ee'
    },
    path: '/admin/settings/navigation'
  },
  {
    _id: {
      $oid: '63a2def9c6935765073bf430'
    },
    path: '/admin/settings/third-party-service'
  },
  {
    _id: {
      $oid: '63a2def9c6935765073bf59d'
    },
    path: '/app/support'
  },
  {
    _id: {
      $oid: '63a54ba2c69357650768af06'
    },
    path: '/logout'
  },
  {
    _id: {
      $oid: '63b2d111c693576507613d1a'
    },
    path: '/admin/closings'
  },
  {
    _id: {
      $oid: '63b2e4bbc69357650762ad67'
    },
    path: '/admin/settings/agreement'
  },
  {
    _id: {
      $oid: '63ff489079238d5ab60fa1fb'
    },
    path: '/admin/payout-generate'
  },
  {
    _id: {
      $oid: '6478856bb36d55c861db31a6'
    },
    path: '/admin/sms-logs'
  },
  {
    _id: {
      $oid: '63a2def8c6935765073bf35f'
    },
    path: '/admin/crm'
  },
  {
    _id: {
      $oid: '63a2def8c6935765073bf380'
    },
    path: '/admin/partner'
  },
  {
    _id: {
      $oid: '63a2def9c6935765073bf3cd'
    },
    path: '/admin/settings/enum'
  },
  {
    _id: {
      $oid: '63a2def9c6935765073bf404'
    },
    path: '/admin/settings/permission'
  },
  {
    _id: {
      $oid: '63a2def9c6935765073bf40f'
    },
    path: '/admin/settings/role'
  },
  {
    _id: {
      $oid: '63a2def9c6935765073bf425'
    },
    path: '/admin/settings/sms-template'
  },
  {
    _id: {
      $oid: '63a54ba2c69357650768af2e'
    },
    path: '/admin/user'
  },
  {
    _id: {
      $oid: '63b2d384c693576507616c3b'
    },
    path: '/admin/payments'
  },
  {
    _id: {
      $oid: '63e64a20bb119e45bba660af'
    },
    path: '/app/sell/files'
  },
  {
    _id: {
      $oid: '63ff487f79238d5ab60fa1fa'
    },
    path: '/admin/tenant-user'
  },
  {
    _id: {
      $oid: '64788576b36d55c861db31a7'
    },
    path: '/admin/email-logs'
  },
  {
    _id: {
      $oid: '64b7cb7ebec73d2b9aab2572'
    },
    path: '/admin/bs/matching-funds'
  },
  {
    _id: {
      $oid: '64e3292d361608806bda66cf'
    },
    path: '/app/digital-asset'
  },
  {
    _id: {
      $oid: '6563275016e017be5de80ca3'
    },
    path: '/admin/draft-users'
  },
  {
    _id: {
      $oid: '657ee67e72ff123888fedd5f'
    },
    path: '/admin/ads'
  },
  {
    _id: {
      $oid: '65b23d634eea9ddda0a135db'
    },
    path: '/admin/premium-req'
  },
  {
    _id: {
      $oid: '65b9f4566cc6e79cab3d5d1c'
    },
    path: '/app/all-events'
  },
  {
    _id: {
      $oid: '65cb55d76cc6e79cabd96069'
    },
    path: '/admin/check-ssl-date'
  },
  {
    _id: {
      $oid: '65ddb18d3941f852ce61ddec'
    },
    path: '/admin/buybox'
  }
];
// 'SideNavBottom', 'ProfileMenu'
export const positionsData = [
  {
    label: 'Side Nav Top',
    value: 'SideNavTop'
  },
  {
    label: 'Side Nav Bottom',
    value: 'SideNavBottom'
  },
  {
    label: 'Profile Menu',
    value: 'ProfileMenu'
  }
];

export const rolesData = [
  {
    _id: '6391ddd49cdfa157b07f424c',
    default_redirect_path: '/admin/dashboard',
    label: 'Super Admin',
    department: [
      'general',
      'technical-support',
      'billing',
      'sub-tenant-customer-support',
      'tenant-support'
    ],
    name: 'super-admin',
    management: true,
    permission: [],
    created_at: {
      $date: '2022-12-08T12:45:21.036Z'
    },
    created_by: {
      $oid: '638f0256f57a664b64db38c5'
    },
    prohibited: true,
    revisions: [
      {
        data: {
          add: [
            {
              field_name: 'default_redirect_path',
              value: '/admin/dashboard'
            }
          ]
        },
        created_at: {
          $date: '2022-12-27T05:51:33.345Z'
        },
        modified_by: {
          $oid: '639aff926afd2e74668541bb'
        }
      },
      {
        data: {
          change: [
            {
              department: {
                append_item: ['technical-support', 'billing']
              }
            }
          ]
        },
        created_at: {
          $date: '2023-02-08T05:56:52.834Z'
        },
        modified_by: {
          $oid: '63da60213eda3bdd85a073b9'
        }
      },
      {
        data: {
          change: [
            {
              department: {
                append_item: ['tenant-support', 'sub-tenant-support', 'sub-tenant-customer-support']
              }
            }
          ]
        },
        created_at: {
          $date: '2023-02-14T05:25:47.191Z'
        },
        modified_by: {
          $oid: '639aff926afd2e74668541bb'
        }
      },
      {
        data: {
          change: [
            {
              department: {
                append_item: ['tenant-support']
              }
            }
          ]
        },
        created_at: {
          $date: '2023-06-01T12:45:45.253Z'
        },
        modified_by: {
          $oid: '63da60213eda3bdd85a073b9'
        }
      },
      {
        data: {
          change: [
            {
              department: {
                append_item: ['sub-tenant-support']
              }
            }
          ]
        },
        created_at: {
          $date: '2023-06-06T10:44:27.825Z'
        },
        modified_by: {
          $oid: '63da60213eda3bdd85a073b9'
        }
      },
      {
        data: {
          change: [
            {
              department: {
                remove_item: ['sub-tenant-support']
              }
            }
          ]
        },
        created_at: {
          $date: '2023-06-06T10:44:53.121Z'
        },
        modified_by: {
          $oid: '63da60213eda3bdd85a073b9'
        }
      }
    ]
  },
  {
    _id: '6391dde39cdfa157b07f424d',
    default_redirect_path: '/app/dashboard',
    label: 'Partner Admin',
    name: 'tenant-admin',
    management: false,
    permission: [],
    created_at: {
      $date: '2022-12-08T12:45:21.036Z'
    },
    created_by: {
      $oid: '638f0256f57a664b64db38c5'
    },
    revisions: [
      {
        data: {
          add: [
            {
              field_name: 'default_redirect_path',
              value: '/app/dashboard'
            }
          ]
        },
        created_at: {
          $date: '2022-12-27T05:48:33.368Z'
        },
        modified_by: {
          $oid: '639aff926afd2e74668541bb'
        }
      }
    ]
  },
  {
    _id: '63aaaac515c0f6c9bc80f759',
    default_redirect_path: '/admin/partner',
    label: 'Partner Success Manager',
    department: ['general', 'tenant-support', 'member-support'],
    name: 'tenant-success-manager',
    management: true,
    permission: [],
    created_at: {
      $date: '2022-12-27T08:02:55.048Z'
    },
    created_by: {
      $oid: '639aff926afd2e74668541bb'
    },
    revisions: [
      {
        data: {
          add: [
            {
              field_name: 'department',
              value: ['general']
            }
          ]
        },
        created_at: {
          $date: '2023-01-10T15:37:53.902Z'
        },
        modified_by: {
          $oid: '63ad586e88a13c93f17f2d03'
        }
      },
      {
        data: {
          change: [
            {
              department: {
                append_item: ['tenant-support']
              }
            }
          ]
        },
        created_at: {
          $date: '2023-01-19T17:30:23.637Z'
        },
        modified_by: {
          $oid: '63be543540e938e97f41df8d'
        }
      }
    ]
  },
  {
    _id: '63aaab6115c0f6c9bc80f762',
    default_redirect_path: '/admin/dashboard',
    label: 'Integration Manager',
    department: ['tenant-support'],
    name: 'integration-manager',
    management: true,
    permission: [],
    created_at: {
      $date: '2022-12-27T08:02:55.048Z'
    },
    created_by: {
      $oid: '639aff926afd2e74668541bb'
    },
    revisions: [
      {
        data: {
          add: [
            {
              field_name: 'department',
              value: ['tenant-support', 'sub-tenant-support']
            }
          ]
        },
        created_at: {
          $date: '2023-01-10T15:36:47.273Z'
        },
        modified_by: {
          $oid: '63ad586e88a13c93f17f2d03'
        }
      },
      {
        data: {
          change: [
            {
              department: {
                remove_item: ['sub-tenant-support']
              }
            }
          ]
        },
        created_at: {
          $date: '2023-03-07T16:04:22.070Z'
        },
        modified_by: {
          $oid: '63d10d7d296d3161f8a6e50c'
        }
      },
      {
        data: {
          change: [
            {
              department: {
                append_item: ['sub-tenant-support'],
                remove_item: ['tenant-support']
              }
            }
          ]
        },
        created_at: {
          $date: '2023-06-01T10:20:29.350Z'
        },
        modified_by: {
          $oid: '63be543540e938e97f41df8d'
        }
      },
      {
        data: {
          change: [
            {
              department: {
                append_item: ['tenant-support'],
                remove_item: ['sub-tenant-support']
              }
            }
          ]
        },
        created_at: {
          $date: '2023-06-01T10:49:33.867Z'
        },
        modified_by: {
          $oid: '63be543540e938e97f41df8d'
        }
      }
    ]
  },
  {
    _id: '63aaab0715c0f6c9bc80f75b',
    default_redirect_path: '/admin/partner',
    label: 'Onboard Manager',
    department: ['tenant-support'],
    name: 'network-manager',
    management: true,
    permission: [],
    created_at: {
      $date: '2022-12-27T08:02:55.048Z'
    },
    created_by: {
      $oid: '639aff926afd2e74668541bb'
    },
    revisions: [
      {
        data: {
          add: [
            {
              field_name: 'department',
              value: ['tenant-support']
            }
          ]
        },
        created_at: {
          $date: '2023-01-10T15:38:06.959Z'
        },
        modified_by: {
          $oid: '63ad586e88a13c93f17f2d03'
        }
      },
      {
        data: {
          change: [
            {
              default_redirect_path: {
                old: '/admin/dashboard',
                new: '/admin/partner'
              }
            }
          ]
        },
        created_at: {
          $date: '2023-01-19T19:48:17.873Z'
        },
        modified_by: {
          $oid: '63be543540e938e97f41df8d'
        }
      }
    ]
  },
  {
    _id: '63c7e55a7626e51f2adfdc81',
    default_redirect_path: '/app/api-docs',
    label: 'Api Partner',
    department: ['general'],
    name: 'api-tenant',
    management: true,
    permission: [],
    created_at: {
      $date: '2023-01-18T12:24:59.109Z'
    },
    created_by: {
      $oid: '63be543540e938e97f41df8d'
    },
    revisions: [
      {
        data: {
          change: [
            {
              management: {
                old: false,
                new: true
              }
            }
          ]
        },
        created_at: {
          $date: '2023-01-18T13:09:54.629Z'
        },
        modified_by: {
          $oid: '63be543540e938e97f41df8d'
        }
      }
    ]
  },
  {
    _id: '63aaaae915c0f6c9bc80f75a',
    default_redirect_path: '/admin/dashboard',
    label: 'General Admin',
    department: ['tenant-support'],
    name: 'general-admin',
    management: true,
    permission: [],
    created_at: {
      $date: '2022-12-27T08:02:55.048Z'
    },
    created_by: {
      $oid: '639aff926afd2e74668541bb'
    },
    revisions: [
      {
        data: {
          change: [
            {
              management: {
                old: false,
                new: true
              }
            }
          ]
        },
        created_at: {
          $date: '2022-12-27T08:21:45.980Z'
        },
        modified_by: {
          $oid: '639aff926afd2e74668541bb'
        }
      },
      {
        data: {
          add: [
            {
              field_name: 'department',
              value: ['tenant-support']
            }
          ]
        },
        created_at: {
          $date: '2023-01-10T15:38:01.174Z'
        },
        modified_by: {
          $oid: '63ad586e88a13c93f17f2d03'
        }
      }
    ]
  },
  {
    _id: '6391ddec9cdfa157b07f424e',
    default_redirect_path: '/app/marketplace/find-property',
    label: 'Member Admin',
    name: 'sub-tenant-admin',
    management: false,
    permission: [],
    created_at: {
      $date: '2022-12-08T12:45:21.036Z'
    },
    created_by: {
      $oid: '638f0256f57a664b64db38c5'
    },
    revisions: [
      {
        data: {
          add: [
            {
              field_name: 'default_redirect_path',
              value: '/app/dashboard'
            }
          ]
        },
        created_at: {
          $date: '2022-12-27T05:48:23.355Z'
        },
        modified_by: {
          $oid: '639aff926afd2e74668541bb'
        }
      }
    ]
  },
  {
    _id: '6391ddf69cdfa157b07f424f',
    default_redirect_path: '/',
    label: 'Members Customer',
    name: 'sub-tenant-customer',
    management: false,
    permission: [],
    created_at: {
      $date: '2022-12-08T12:45:21.036Z'
    },
    created_by: {
      $oid: '638f0256f57a664b64db38c5'
    },
    revisions: [
      {
        data: {
          add: [
            {
              field_name: 'default_redirect_path',
              value: '/app/dashboard'
            }
          ]
        },
        created_at: {
          $date: '2022-12-27T05:47:28.794Z'
        },
        modified_by: {
          $oid: '639af65dab2f6d4e6d969f06'
        }
      }
    ]
  },
  {
    _id: '63a2ec71fd4ddc50d15213b5',
    default_redirect_path: '/docs',
    label: 'Api Partner Developer',
    name: 'tenant-developer',
    management: false,
    permission: [],
    created_at: {
      $date: '2022-12-21T11:13:18.399Z'
    },
    created_by: {
      $oid: '639aff926afd2e74668541bb'
    },
    revisions: [
      {
        data: {
          change: [
            {
              name: {
                old: 'tenant-developer',
                new: 'tenant-developerf'
              }
            },
            {
              label: {
                old: 'Tenant Developer',
                new: 'Tenant Developerf'
              }
            }
          ]
        },
        created_at: {
          $date: '2022-12-21T11:22:51.095Z'
        },
        modified_by: {
          $oid: '639aff926afd2e74668541bb'
        }
      },
      {
        data: {
          change: [
            {
              name: {
                old: 'tenant-developerf',
                new: 'tenant-developer'
              }
            },
            {
              label: {
                old: 'Tenant Developerf',
                new: 'Tenant Developer'
              }
            }
          ]
        },
        created_at: {
          $date: '2022-12-21T11:22:59.299Z'
        },
        modified_by: {
          $oid: '639aff926afd2e74668541bb'
        }
      },
      {
        data: {
          add: [
            {
              field_name: 'default_redirect_path',
              value: '/app/dashboard'
            }
          ]
        },
        created_at: {
          $date: '2022-12-27T05:45:12.098Z'
        },
        modified_by: {
          $oid: '639af65dab2f6d4e6d969f06'
        }
      },
      {
        data: {
          change: [
            {
              default_redirect_path: {
                old: '/app/dashboard',
                new: '/docs'
              }
            }
          ]
        },
        created_at: {
          $date: '2022-12-27T05:51:20.607Z'
        },
        modified_by: {
          $oid: '639aff926afd2e74668541bb'
        }
      }
    ]
  },
  {
    _id: '63aaab3a15c0f6c9bc80f75e',
    default_redirect_path: '/admin/dashboard',
    label: 'Payout Manager',
    department: ['sub-tenant-support'],
    name: 'payout-manager',
    management: true,
    permission: [],
    created_at: {
      $date: '2022-12-27T08:02:55.048Z'
    },
    created_by: {
      $oid: '639aff926afd2e74668541bb'
    },
    revisions: [
      {
        data: {
          add: [
            {
              field_name: 'department',
              value: ['sub-tenant-support']
            }
          ]
        },
        created_at: {
          $date: '2023-01-10T15:38:12.761Z'
        },
        modified_by: {
          $oid: '63ad586e88a13c93f17f2d03'
        }
      }
    ]
  },
  {
    _id: '648988bf4af32e2f77f28b88',
    default_redirect_path: '/admin/payment-history',
    label: 'Transition Coordinator',
    department: ['billing'],
    name: 'transition-coordinator',
    management: true,
    permission: [],
    created_at: {
      $date: '2023-06-14T09:21:11.356Z'
    },
    created_by: {
      $oid: '63da60213eda3bdd85a073b9'
    },
    revisions: [
      {
        data: {
          change: [
            {
              management: {
                old: false,
                new: true
              }
            }
          ]
        },
        created_at: {
          $date: '2023-06-14T09:41:42.310Z'
        },
        modified_by: {
          $oid: '63da60143eda3bdd85a073b8'
        }
      }
    ]
  },
  {
    _id: '64aa81de55f091b0a50f8b4c',
    default_redirect_path: '/admin/questions',
    label: 'Compliance Manager',
    department: ['sub-tenant-support'],
    name: 'compliance-manager',
    management: true,
    permission: [],
    created_at: {
      $date: '2023-07-09T09:45:23.934Z'
    },
    created_by: {
      $oid: '63be543540e938e97f41df8d'
    }
  },
  {
    _id: '64b7b5a83aba34b4ae51dbf4',
    default_redirect_path: '/admin/bs/matching-funds',
    label: 'Equity Funds',
    department: ['general'],
    name: 'equity-funds',
    management: true,
    permission: [],
    created_at: {
      $date: '2023-07-19T09:06:30.819Z'
    },
    created_by: {
      $oid: '63da60213eda3bdd85a073b9'
    },
    revisions: [
      {
        data: {
          change: [
            {
              management: {
                old: false,
                new: true
              }
            }
          ]
        },
        created_at: {
          $date: '2023-07-19T10:07:44.304Z'
        },
        modified_by: {
          $oid: '63da60213eda3bdd85a073b9'
        }
      },
      {
        data: {
          change: [
            {
              default_redirect_path: {
                old: '/app/announcement',
                new: '/admin/bs/matching-funds'
              }
            }
          ]
        },
        created_at: {
          $date: '2023-07-19T12:02:33.537Z'
        },
        modified_by: {
          $oid: '63be543540e938e97f41df8d'
        }
      }
    ]
  },
  {
    _id: '659bc045241740ca58d0c3fd',
    default_redirect_path: '/app/sell/my-properties',
    label: 'Agent Member',
    department: [],
    name: 'agent-member',
    management: false,
    permission: [],
    created_at: {
      $date: '2024-01-08T08:56:10.718Z'
    },
    created_by: {
      $oid: '64898befa032d76e9a70b68d'
    }
  }
];
