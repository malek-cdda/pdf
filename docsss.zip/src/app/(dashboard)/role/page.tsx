'use client';

import Table from '@/components/Table/Table';
import { headCellsProps, rowDataProps } from '@/components/Table/types';
import { alpha, Avatar, Badge, Box, Fab, Paper, Typography } from '@mui/material';
import React, { useEffect, useState } from 'react';
import { MdOutlineDeleteOutline } from 'react-icons/md';
import { GrView } from 'react-icons/gr';
import Card from './components/Card';
import { BsThreeDotsVertical } from 'react-icons/bs';
import GlobalModal from '@/components/Modal/GlobalModal';

import ConfirmationModalContext, {
  useConfirmationModalContext
} from '@/providers/ConfirmationModalContext';
import { BiEdit } from 'react-icons/bi';
import { useDeleteRoleMutation, useGetRolesQuery } from './features/roleApi';
import AddEditRole from './components/AddEditRole';
import View from './components/View';
const Home = () => {
  const { data, isSuccess, isLoading } = useGetRolesQuery(80);

  console.log(data, 'role data query');
  // console.log(data, 'data');
  const [deleteRole, { isSuccess: isRoleDeleteSuccess, isLoading: isRoleDeleteLoading }] =
    useDeleteRoleMutation();

  const [open, setOpen] = useState(false);
  const [componentType, setComponentType] = useState(null);
  const [title, setTitle] = useState('');
  const handleOpen = ({ componentType, title = '' }: { componentType: any; title: string }) => {
    setTitle(title);
    setComponentType(componentType);
    setOpen(true);
  };
  // single row data delete
  const handleDeleteAction = (row: any) => {
    showConfirmationModal({
      onConfirm: () => handleDelete(row),
      message: `Do you really want to delete this records? This process cannot be undone.`
    });
    // console.log(row, selectedAction);
  };
  // confirmation modal for bulk delete
  const { showConfirmationModal, closeModal } = useConfirmationModalContext() as unknown as {
    showModal: boolean;
    closeModal: () => void;
    showConfirmationModal: (props: { onConfirm: () => void; message: string }) => void;
  };
  const handleDelete = async (data) => {
    // Your delete logic goes here
    try {
      await deleteRole(data?.uid);
      closeModal();
    } catch (error) {
      console.log(error);
    } // Close the modal after the delete action
  };

  const handleBulkDeleteAction = (row: any, selectedAction: string) => {
    // ConfirmationModal({ open: true });
    // ConfirmationModalContext({ open: true });
    console.log(row, selectedAction);
    showConfirmationModal({
      onConfirm: handleDelete,
      message: `Do you really want to delete this records? This process cannot be undone.`
    });
    console.log(row, selectedAction);
  };

  const headCells: headCellsProps[] = [
    {
      id: 'label',
      numeric: false,
      disablePadding: false,
      label: 'Role',
      option: {
        sortable: false
      },
      render: (user: rowDataProps | any) => {
        // console.log('user', user);
        return (
          <Box
            display="flex"
            alignItems="center"
            color={(theme: any) =>
              theme.palette.mode === 'light'
                ? theme?.palette?.title?.light
                : theme?.palette?.title?.dark
            }
          >
            <Avatar sx={{ width: 38, height: 38 }} alt="Remy Sharp" src={user?.img} />
            <Box marginLeft="10px" display="flex" flexDirection="column">
              <Typography
                sx={{
                  fontSize: '13px'
                }}
              >
                {user?.label}
              </Typography>
              <Typography
                sx={{
                  fontSize: '13px'
                }}
              >
                {user?.title}
              </Typography>
            </Box>
          </Box>
        );
      }
    },
    {
      id: 'description',
      numeric: false,
      disablePadding: false,
      label: 'DESCRIPTION'
    },

    {
      id: 'actions',
      numeric: false,
      disablePadding: false,
      label: 'ACTIONS',
      option: {
        align: 'right'
      },
      render: (row: any) => (
        <Box
          sx={{
            display: 'flex',
            justifyContent: 'end',
            alignItems: 'center',
            width: '100%',
            color: (theme: any) =>
              theme.palette.mode === 'light'
                ? theme?.palette?.title?.light
                : theme?.palette?.title?.dark
          }}
        >
          <Fab
            size="small"
            sx={{
              color: (theme: any) =>
                theme.palette.mode === 'light'
                  ? theme?.palette?.secondary?.light
                  : theme?.palette?.secondary?.dark,
              backgroundColor: 'transparent',
              cursor: 'pointer',
              '&:hover': {
                backgroundColor: (theme: any) =>
                  theme.palette.mode === 'light'
                    ? alpha(theme?.palette?.secondary?.light, 0.4)
                    : alpha(theme?.palette?.secondary?.dark, 0.4)
              }
            }}
            onClick={() => handleOpen({ componentType: <View />, title: '' })}
          >
            <GrView fontSize={20} />
          </Fab>
          <Fab
            size="small"
            sx={{
              color: (theme: any) =>
                theme.palette.mode === 'light'
                  ? theme?.palette?.error?.light
                  : theme?.palette?.error?.dark,
              backgroundColor: 'transparent',
              cursor: 'pointer',
              '&:hover': {
                backgroundColor: (theme: any) =>
                  theme.palette.mode === 'light'
                    ? alpha(theme.palette.error.light, 0.4)
                    : alpha(theme.palette.error.dark, 0.4)
              }
            }}
            onClick={() => handleDeleteAction(row)}
          >
            <MdOutlineDeleteOutline fontSize={20} />
          </Fab>
          <Fab
            size="small"
            sx={{
              color: (theme: any) =>
                theme.palette.mode === 'light'
                  ? theme?.palette?.secondary?.light
                  : theme?.palette?.secondary?.dark,
              backgroundColor: 'transparent',
              cursor: 'pointer',

              padding: '0px',
              '&:hover': {
                backgroundColor: (theme: any) =>
                  theme.palette.mode === 'light'
                    ? alpha(theme?.palette?.secondary?.light, 0.4)
                    : alpha(theme?.palette?.secondary?.dark, 0.4)
              }
            }}
            onClick={() =>
              handleOpen({
                componentType: <AddEditRole data={row} setOpen={setOpen} edit />,
                title: 'Edit Role'
              })
            }
          >
            <BiEdit fontSize={20} />
          </Fab>
        </Box>
      )
    }
  ];
  const [page, setPage] = useState<any>(1);
  const [rowsPerPage, setRowsPerPage] = useState<any>(10);
  const [rowData, setRowData] = useState<any>([]);
  const [count, setCount] = useState<any>(0);
  const [selected, setSelected] = useState<any>({});
  // useEffect(() => {
  //   fetch(`https://dummyjson.com/products?limit=${rowsPerPage}&skip=${page}`)
  //     .then((response) => response.json())
  //     .then((json) => {
  //       setSelected(json);
  //       setCount(Math.ceil(json?.total / json.limit));
  //       setRowData(json?.products);
  //     });
  // }, [page, rowsPerPage]);
  return (
    <>
      {isLoading ? (
        <Box
          sx={{
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            height: '80vh'
          }}
        >
          <Typography
            sx={{
              fontSize: '20px',
              color: (theme: any) =>
                theme.palette.mode === 'light'
                  ? theme?.palette?.title?.light
                  : theme?.palette?.title?.dark,
              textAlign: 'center'
            }}
          >
            Loading...
          </Typography>
        </Box>
      ) : (
        <Card {...{ handleOpen, setOpen, data, handleDeleteAction }} />
      )}
      <br />

      {/* <Table
        headCells={headCells}
        row={data}
        handleOpen={handleOpen}
        filterName
        searchBar
        // dateRange
        // gridView
        // searchFieldNameItem="plan"
        isCheckbox={false}
        handleBulkDelete={handleBulkDeleteAction}
        page={page}
        setPage={setPage}
        rowsPerPage={rowsPerPage}
        setRowsPerPage={setRowsPerPage}
        count={count}
        isLoading={isLoading}
      /> */}
      <GlobalModal setOpen={setOpen} open={open} title={title}>
        {componentType}
      </GlobalModal>
    </>
  );
};

export default Home;
