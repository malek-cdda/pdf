// Author : Dewan Mizanur Rahman

'use client';

import { Button } from '@mui/material';
import { useFormik } from 'formik';
import { renderInputs } from '@/utils/renderInputs';
import { buildInitialValuesAndValidationSchema } from '@/utils/valuesWithSchema';
import { roleForm } from '@/data/roleForm';
import { useCreateRoleMutation, useEditRoleMutation } from '../features/roleApi';
import { useEffect } from 'react';

export default function AddEditRole({
  setOpen,
  edit,
  data = {}
}: {
  setOpen: any;
  edit?: boolean;
  data?: any;
}) {
  const { uid, ...rest } = data;
  const editInitData: any = {};
  for (const key in rest) {
    if (rest[key] !== null) {
      editInitData[key] = rest[key];
    } else {
      editInitData[key] = '';
    }
  }
  // console.log('data', data);
  const { initialValues, validationSchema } = buildInitialValuesAndValidationSchema({
    fields: roleForm
  });
  const [createRole, { data: roleData, isSuccess, isLoading }] = useCreateRoleMutation();
  const [editRole, { data: roleDataEdit, isSuccess: isSuccessEdit, isLoading: isLoadingEdit }] =
    useEditRoleMutation();

  const formik = useFormik({
    initialValues: edit ? editInitData : initialValues,
    validationSchema,
    onSubmit: async (values: any, { setSubmitting }) => {
      console.log('Form values:', values);
      const formData = new FormData();
      // Loop through form values and append them to FormData
      Object.entries(values).forEach(([fieldName, fieldValue]) => {
        // Handle file inputs separately
        if (Array.isArray(fieldValue) && fieldValue.some((item) => item instanceof File)) {
          fieldValue.forEach((file, index) => {
            formData.append(fieldName, file);
          });
        }
      });

      setSubmitting(true);
      // Make a POST request to the server
      try {
        // Set formik submitting to true
        if (edit) {
          await editRole({ uid, data: values });
        } else {
          await createRole(values);
          formik.resetForm();
        }

        // Handle response
      } catch (error: any) {
        if (error.name === 'AbortError') {
          console.log('Fetch request was aborted:', error);
        } else {
          console.error('Error occurred during fetch request:', error);
          // Handle other errors
        }
      }
      // Set formik submitting to false
      setSubmitting(false);
    },
    // Enable reinitialize to update the form values
    enableReinitialize: true
  });

  useEffect(() => {
    if (isSuccess || isSuccessEdit) {
      setOpen(false);
    }
  }, [isSuccess, setOpen, isSuccessEdit]);

  return (
    <main>
      <form
        onSubmit={formik.handleSubmit}
        style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}
      >
        {/* Display form fields */}
        {roleForm.map((item) => {
          return renderInputs({ item, formik });
        })}

        <Button
          sx={{ mt: 3 }}
          type="submit"
          variant="contained"
          disabled={
            // (formik.dirty && formik.isValid ? false : true) ||
            formik.isSubmitting || isLoading || isLoadingEdit
          }
        >
          {/* {!waiting ? 'Save' : 'Saving...'} */}
          {edit ? 'Update' : 'Submit'}
        </Button>
      </form>
    </main>
  );
}

export const dynamic = 'force-dynamic';
