import React from 'react'

const View = () => {
  return (
    <div>
      View
    </div>
  )
}

export default View
