import { apiSlice } from '@/redux/features/api/apiSlice';

export const roleApi: any = apiSlice.injectEndpoints({
  // tagTypes: ['Roles'],
  endpoints: (builder) => ({
    getRoles: builder.query({
      query: () => ({
        url: `/roles`
      }),
      providesTags: (result) =>
        // is result available?
        result
          ? // successful query
            [
              ...result.map(({ uid }: { uid: string }) => ({ type: 'Roles', uid }) as const),
              { type: 'Roles', id: 'LIST' }
            ]
          : // an error occurred, but we still want to refetch this query when `{ type: 'Posts', id: 'LIST' }` is invalidated
            [{ type: 'Roles', id: 'LIST' }]
    }),
    getRole: builder.query({
      query: (uid) => ({
        url: `/roles/${uid}`
      }),
      providesTags: (result, error, uid) => [{ type: 'Roles', uid }]
    }),

    createRole: builder.mutation({
      query: (data) => ({
        url: '/roles',
        method: 'POST',
        body: data
      }),
      invalidatesTags: [{ type: 'Roles', id: 'LIST' }],

      async onQueryStarted(arg, { dispatch, queryFulfilled }) {
        // pessimistic cache update
        try {
          const { data: createdRole } = await queryFulfilled;

          console.log(createdRole, 'createdRole');
          // update get tasks cache, when new task is added
          dispatch(
            apiSlice.util.updateQueryData('getRoles', undefined, (draft: any[]) => {
              draft.push(createdRole);
            })
          );
        } catch (err) {
          console.log(err);
        }
      }
    }),

    editRole: builder.mutation({
      query: ({ uid, data }) => ({
        url: `/roles/${uid}`,
        method: 'PUT',
        body: data
      }),
      // In this case, `getPost` will be re-run. `getPosts` *might*  rerun, if this id was under its results.
      invalidatesTags: (result, error, { uid }) => [{ type: 'Roles', uid }],

      async onQueryStarted({ uid, data }, { dispatch, queryFulfilled }) {
        try {
          const { data: role } = await queryFulfilled;

          // also update getRoles's cache

          dispatch(
            apiSlice.util.updateQueryData('getRoles', undefined, (draft) => {
              return draft.map((item) => (item?.uid === uid ? role : item));
            })
          );
        } catch (err) {
          console.log(err);
        }
      }
    }),

    deleteRole: builder.mutation({
      query: (uid) => ({
        url: `/roles/${uid}`,
        method: 'DELETE'
      }),
      invalidatesTags: (result, error, { uid }) => [{ type: 'Roles', uid }],
      async onQueryStarted(arg, { dispatch, queryFulfilled }) {
        // optimistic update, update when getTask's cache, when task is deleted
        console.log(apiSlice.util, 'role');
        const patchResult = dispatch(
          apiSlice.util.updateQueryData('getRoles', undefined, (draft) => {
            return draft.filter((role) => role.uid !== arg);
          })
        );

        try {
          await queryFulfilled;
        } catch (err) {
          patchResult.undo();
        }
      }
    })
  })
});

export const {
  useGetRolesQuery,
  useGetRoleQuery,
  useCreateRoleMutation,
  useEditRoleMutation,
  useDeleteRoleMutation
} = roleApi;
