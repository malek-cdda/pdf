import { createAppSlice } from '@/redux/createAppSlice';
import type { PayloadAction } from '@reduxjs/toolkit';

export interface PlaygroundState {
  method: string;
  url: string;
  headers: string[];
  params: string[];
  body: string;
  response: string | null;
}

const initialState = {
  method: 'get',
  url: '',
  headers: [],
  params: [],
  body: '',
  response: null
};

export const playgroundSlice = createAppSlice({
  name: 'playground',
  initialState,
  reducers: (create) => ({
    addMethod: create.reducer((state, action: PayloadAction<string>) => {
      console.log('action', action.payload);
      state.method = action.payload;
    }),
    addUrl: create.reducer((state, action: PayloadAction<string>) => {
      state.url = action.payload;
    }),

    addResponse: create.reducer((state, action: PayloadAction<string | null>) => {
      // @ts-ignore
      state.response = action.payload;
    }),
    handleClear: create.reducer((state) => {
      state.method = 'get';
      state.url = '';
      state.headers = [];
      state.params = [];
      state.body = '';
      state.response = null;
    })
  })
});

// Action creators are generated for each case reducer function
export const { addMethod, addUrl, addResponse, handleClear } = playgroundSlice.actions;

// export default playgroundSlice.reducer;
