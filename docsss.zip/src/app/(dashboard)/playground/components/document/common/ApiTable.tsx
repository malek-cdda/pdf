import { alpha, Box, Typography } from '@mui/material';
import React from 'react';

const ApiTable = ({ children, rest }: any) => {
  return (
    <Box
      color={(theme: any) =>
        theme.palette.mode === 'light'
          ? alpha(theme?.palette?.subtitle?.light, 0.9)
          : alpha(theme?.palette?.subtitle?.dark, 0.9)
      }
      sx={{
        fontSize: '16px',
        borderCollapse: 'collapse',
        border: '1px solid rgba(224, 224, 224, 1)',
        // padding: '7px'
        // boxShadow: 1
        borderRadius: '6px',
        // everychild have border-bottom: '1px solid rgba(224, 224, 224, 1)',
        '& > *:not(:last-child)': { borderBottom: '1px solid rgba(224, 224, 224, 1)' },
        ...rest
      }}
    >
      {children}
    </Box>
  );
};

export default ApiTable;
