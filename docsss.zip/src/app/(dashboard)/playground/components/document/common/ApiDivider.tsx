import { Divider } from '@mui/material';
import React from 'react';

const ApiDivider = ({ distance = '30px 0px' }: { distance?: string }) => {
  return (
    <Divider
      sx={{
        margin: distance,
        backgroundColor: (theme: any) =>
          theme.palette.mode === 'light' ? theme.palette.divider.light : theme.palette.divider.dark
      }}
    />
  );
};

export default ApiDivider;
