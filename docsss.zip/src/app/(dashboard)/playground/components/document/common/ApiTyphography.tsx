import { alpha, Box } from '@mui/material';
import React from 'react';

const ApiTypography = ({ children, ...rest }: any) => {
  return (
    <Box
      fontSize={'16px'}
      color={(theme: any) =>
        theme.palette.mode === 'light'
          ? alpha(theme.palette.subtitle.light, 0.9)
          : alpha(theme.palette.subtitle.dark, 0.9)
      }
      {...rest}
    >
      {children}
    </Box>
  );
};

export default ApiTypography;
