import { Box, Button, Fab, Typography } from '@mui/material';
import React, { useRef } from 'react';
import ContentCopyIcon from '@mui/icons-material/ContentCopy';
const ApiResponse = ({ jsonText }: any) => {
  const textRef = useRef<any>(null);

  const handleCopy = () => {
    const range = document.createRange();
    range.selectNode(textRef?.current);
    window?.getSelection()?.removeAllRanges();
    window?.getSelection()?.addRange(range);
    document?.execCommand('copy');
    window?.getSelection()?.removeAllRanges();
  };
  return (
    <Box
      ref={textRef}
      sx={{
        position: 'relative',
        '& :hover > .copyButton': {
          visibility: 'visible'
          //   display: 'block'
        }
      }}
    >
      <Typography
        sx={{
          fontSize: '14px',
          fontWeight: 'bold',
          margin: '5px 0'
        }}
      >
        <Fab
          size="small"
          color="primary"
          aria-label="add"
          onClick={handleCopy}
          //   className="copyButton"
          sx={{
            position: 'absolute',
            right: '10px',
            top: '10px',
            borderRadius: '5px'
            // visibility: 'hidden'
            // display: 'none'
          }}
        >
          <ContentCopyIcon />
        </Fab>
      </Typography>
      <Box
        sx={{
          height: '230px',
          backgroundColor: '#1f1e1b',
          color: '#00ba38',
          borderRadius: '5px',
          padding: '10px',
          overflow: 'auto'
        }}
      >
        {<pre>{JSON.stringify(jsonText, null, 2)}</pre>}
      </Box>
    </Box>
  );
};

export default ApiResponse;
