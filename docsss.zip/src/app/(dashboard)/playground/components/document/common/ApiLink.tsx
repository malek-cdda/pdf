import { Link } from '@mui/material';
import React from 'react';

const ApiLink = ({ href = 'https://www.google.com', children, sx, rest }: any) => {
  return (
    <Link
      href={href}
      target={'_blank'}
      sx={{
        textDecoration: 'underline',
        color: (theme: any) =>
          theme.palette.mode === 'light' ? theme.palette.primary.main : theme.palette.primary.light,
        '&:hover': {
          textDecoration: 'underline'
        },
        ...sx
      }}
      {...rest}
    >
      {children}
    </Link>
  );
};

export default ApiLink;
