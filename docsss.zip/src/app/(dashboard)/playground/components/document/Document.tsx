'use client';
import React from 'react';
import ApiHeader from '../../../playground/components/document/common/ApiHeader';
import ApiTypography from '../../../playground/components/document/common/ApiTyphography';
import {
  alpha,
  Autocomplete,
  Badge,
  Box,
  List,
  ListItem,
  ListItemText,
  Typography
} from '@mui/material';
import ApiDivider from '../../../playground/components/document/common/ApiDivider';
import WatchOutlinedIcon from '@mui/icons-material/WatchOutlined';
import KeyOutlinedIcon from '@mui/icons-material/KeyOutlined';
import ApiLink from '../../../playground/components/document/common/ApiLink';
import ApiTable from '../../../playground/components/document/common/ApiTable';
import KeyboardArrowRightOutlinedIcon from '@mui/icons-material/KeyboardArrowRightOutlined';
import AutoCompleteField from '../../../playground/components/document/common/AutoCompleteField';

const Document = () => {
  return (
    <Box
      padding={'10px'}
      sx={{
        backgroundColor: (theme: any) =>
          theme?.palette?.mode === 'light'
            ? theme?.palette?.card?.light
            : theme?.palette?.card?.dark
      }}
    >
      <ApiHeader>PropGPT API</ApiHeader>
      <ApiTypography
        sx={{
          display: 'flex',
          alignItems: 'center',
          gap: '5px',
          fontSize: '12px',
          padding: '1px 0px',
          borderRadius: '16px',
          marginTop: '10px',
          color: (theme: any) =>
            theme.palette.mode === 'light'
              ? alpha(theme?.palette?.title?.light, 0.9)
              : alpha(theme?.palette?.title?.dark, 0.9)
        }}
      >
        {' '}
        <Badge
          variant="dot"
          // invisible={pathName !== item?.path}
          sx={{
            // marginLeft: 'auto',
            fontSize: '12px',
            padding: '1px 12px',
            borderRadius: '16px',
            color: (theme: any) =>
              theme.palette.mode === 'light'
                ? alpha(theme?.palette?.title?.light, 0.9)
                : alpha(theme?.palette?.title?.dark, 0.9),
            background: (theme) => alpha(theme?.palette?.primary?.main, 0.4)
          }}
        >
          POST
        </Badge>
        <Typography component="span" fontSize={13}>
          https://api.realestateapi.com/v2/PropGPT
        </Typography>
      </ApiTypography>

      <ApiTypography sx={{ padding: '10px 0px 0px 0px' }}>
        Check out the functionality of this endpoint at <ApiLink>https://www.propgpt.com</ApiLink>
      </ApiTypography>
      <ApiDivider distance="20px 0px" />
      <ApiTypography
        sx={{
          padding: '0px 0px 0px 0px',
          display: 'flex',
          gap: '5px',
          justifyContent: 'flex-start',
          alignItems: 'center',
          paddingBottom: '10px'
        }}
      >
        {' '}
        <KeyOutlinedIcon
          sx={{
            fontSize: '16px'
          }}
        />{' '}
        <Typography component={'span'} fontSize={'12px'}>
          LOG IN TO SEE FULL REQUEST HISTORY
        </Typography>
      </ApiTypography>
      <ApiTable>
        <Box display={'flex'} padding={'6px'}>
          <Typography width={'20%'}>TIME</Typography>
          <Typography width={'20%'}> STATUS</Typography>
          <Typography width={'30%'}>USER AGENT</Typography>
        </Box>

        <Typography textAlign="center" padding="10px .3px">
          Make a request to see history.
        </Typography>
        <Typography textAlign="left" padding="5px 0px 5px 20px">
          0 Requests This Month
        </Typography>
      </ApiTable>
      <ApiHeader padding="10px 0px 0px 0px">
        How to Get an OpenAI API Key for Using PropGPT API
      </ApiHeader>
      <ApiTypography sx={{ padding: '10px 0px 0px 0px' }}>
        Visit <ApiLink>https://www.propgpt.com</ApiLink> and create an account.
      </ApiTypography>
      <ApiTypography sx={{ padding: '10px 0px 0px 0px' }}>
        Once your account is created you can follow this OpenAI help article that directs you to
        where to find your secret key <ApiLink>https://www.propgpt.com</ApiLink>
      </ApiTypography>
      <ApiHeader padding="10px 0px 0px 0px">Why do I need to include my OpenAI Key?</ApiHeader>
      <ApiTypography sx={{ padding: '10px 0px 0px 0px' }}>
        <Typography component={'span'}>
          There are two reasons why we need to have your OpenAI key in order to fulfill PropGPT API
          Requests:
        </Typography>
        <List sx={{ listStyle: 'decimal', pl: 4 }}>
          <ListItem sx={{ display: 'list-item', paddingLeft: '0px' }}>
            <ListItemText
              sx={{
                padding: '0px ',
                '.MuiListItemText-root': {
                  padding: 0 // Set padding to 0 to remove the default padding
                }
              }}
            >
              Accurate tracking of tokens that will get billed to your OpenAI account balance
            </ListItemText>
          </ListItem>
          <ListItem sx={{ display: 'list-item', paddingLeft: '0px' }}>
            <ListItemText
              sx={{
                padding: '0px ',
                '.MuiListItemText-root': {
                  padding: 0 // Set padding to 0 to remove the default padding
                }
              }}
            >
              OpenAI data use compliance
            </ListItemText>
          </ListItem>
        </List>
      </ApiTypography>
      <ApiHeader padding="5px 0px 10px 0px" fontSize={'16px'}>
        BODY PARAMS
      </ApiHeader>
      <ApiTable>
        <ApiTypography
          sx={{
            padding: '10px 10px 0px 10px',
            // display: 'flex',
            gap: '5px',
            // justifyContent: 'space-between',
            // alignItems: 'center',
            paddingBottom: '10px',
            '&:hover': {
              background: (theme: any) => alpha(theme.palette.primary.main, 0.1)
            }
          }}
        >
          {' '}
          <Box display={'flex'} flexDirection={'row'} gap={'5px'}>
            <Typography component={'span'} fontSize={'12px'}>
              Size
            </Typography>
            <Typography
              color={(theme) => alpha(theme?.palette?.primary?.main, 0.5)}
              component={'span'}
              fontSize={'12px'}
            >
              int32
            </Typography>
          </Box>
          <Typography
            color={(theme) => alpha(theme?.palette?.primary?.main, 0.5)}
            component={'span'}
            fontSize={'12px'}
          >
            Maximum of 250
          </Typography>
        </ApiTypography>
        <ApiTypography
          sx={{
            padding: '10px 10px 0px 10px',
            // display: 'flex',
            gap: '5px',
            // justifyContent: 'space-between',
            alignItems: 'center',
            paddingBottom: '10px',
            '&:hover': {
              background: (theme: any) => alpha(theme.palette.primary.main, 0.1)
            }
          }}
        >
          {' '}
          <Box display={'flex'} flexDirection={'row'} gap={'5px'}>
            <Typography component={'span'} fontSize={'12px'}>
              query
            </Typography>
            <Typography
              color={(theme) => alpha(theme?.palette?.primary?.main, 0.5)}
              component={'span'}
              fontSize={'12px'}
            >
              string
            </Typography>
            <Typography
              color={(theme) => alpha(theme?.palette?.error?.main, 0.7)}
              component={'span'}
              fontSize={'12px'}
            >
              required
            </Typography>
          </Box>
          <Typography component={'span'} fontSize={'12px'}>
            A natural language string that references data points in the Property Search API in
            order to retrieve a list of properties.
          </Typography>
        </ApiTypography>
      </ApiTable>

      {/* headers section api  */}
      <ApiHeader padding="15px 0px 10px 0px" fontSize={'16px'}>
        HEADERS
      </ApiHeader>
      <ApiTable>
        <ApiTypography
          sx={{
            padding: '10px 10px 0px 10px',
            display: 'flex',
            gap: '5px',
            justifyContent: 'space-between',
            alignItems: 'center',
            paddingBottom: '10px',
            '&:hover': {
              background: (theme: any) => alpha(theme.palette.primary.main, 0.1)
            }
          }}
        >
          {' '}
          <Box display={'flex'} flexDirection={'row'} gap={'5px'}>
            <Typography component={'span'} fontSize={'12px'}>
              x-api-key
            </Typography>
            <Typography
              color={(theme) => alpha(theme?.palette?.primary?.main, 0.5)}
              component={'span'}
              fontSize={'12px'}
            >
              string
            </Typography>
            <Typography
              color={(theme) => alpha(theme?.palette?.error?.main, 0.7)}
              component={'span'}
              fontSize={'12px'}
            >
              required
            </Typography>
          </Box>
        </ApiTypography>
        <ApiTypography
          sx={{
            padding: '10px 10px 0px 10px',
            display: 'flex',
            gap: '5px',
            justifyContent: 'space-between',
            alignItems: 'center',
            paddingBottom: '10px',
            '&:hover': {
              background: (theme: any) => alpha(theme.palette.primary.main, 0.1)
            }
          }}
        >
          {' '}
          <Box display={'flex'} flexDirection={'row'} gap={'5px'}>
            <Typography component={'span'} fontSize={'12px'}>
              x-user-id
            </Typography>
            <Typography
              color={(theme) => alpha(theme?.palette?.primary?.main, 0.5)}
              component={'span'}
              fontSize={'12px'}
            >
              string
            </Typography>
          </Box>
        </ApiTypography>

        <ApiTypography
          sx={{
            padding: '10px 10px 0px 10px',
            display: 'flex',
            gap: '5px',
            justifyContent: 'space-between',
            alignItems: 'center',
            paddingBottom: '10px',
            '&:hover': {
              background: (theme: any) => alpha(theme.palette.primary.main, 0.1)
            }
          }}
        >
          {' '}
          <Box display={'flex'} flexDirection={'row'} gap={'5px'}>
            <Typography component={'span'} fontSize={'12px'}>
              x-openai-key
            </Typography>
            <Typography
              color={(theme) => alpha(theme?.palette?.primary?.main, 0.5)}
              component={'span'}
              fontSize={'12px'}
            >
              string
            </Typography>
            <Typography
              color={(theme) => alpha(theme?.palette?.error?.main, 0.7)}
              component={'span'}
              fontSize={'12px'}
            >
              required
            </Typography>
          </Box>
        </ApiTypography>
      </ApiTable>
      {/* body params  */}
      <ApiDivider distance="0px 0px 10px 0px" />
      <ApiHeader padding="1px 0px 0px 0px" fontSize={'16px'}>
        RESPONSE
      </ApiHeader>
      <ApiTable>
        <ApiTypography
          sx={{
            padding: '10px 10px 0px 10px',
            display: 'flex',
            gap: '5px',
            justifyContent: 'space-between',
            alignItems: 'center',
            paddingBottom: '10px',
            '&:hover': {
              background: (theme: any) => alpha(theme.palette.primary.main, 0.1)
            }
          }}
        >
          {' '}
          <Box display={'flex'} flexDirection={'column'}>
            <Typography component={'span'} fontSize={'12px'}>
              <Badge
                variant="dot"
                // invisible={pathName !== item?.path}
                sx={{
                  // marginLeft: 'auto',
                  fontSize: '12px',
                  padding: '4px',
                  borderRadius: '50%',
                  color: (theme: any) =>
                    theme.palette.mode === 'light'
                      ? alpha(theme?.palette?.title?.light, 0.9)
                      : alpha(theme?.palette?.title?.dark, 0.9),
                  background: (theme) => alpha(theme?.palette?.primary?.main, 0.4)
                }}
              ></Badge>{' '}
              200
            </Typography>
            <Typography component={'span'} fontSize={'12px'}>
              200
            </Typography>
          </Box>
          <KeyboardArrowRightOutlinedIcon
            sx={{
              fontSize: '16px'
            }}
          />{' '}
        </ApiTypography>
      </ApiTable>
      <ApiTypography
        sx={{
          display: 'flex',
          gap: '5px',
          justifyContent: 'flex-start',
          alignItems: 'center',
          padding: '10px 0px 10px 0px'
        }}
      >
        {' '}
        <WatchOutlinedIcon
          sx={{
            fontSize: '16px'
          }}
        />{' '}
        <Typography component={'span'} fontSize={'12px'}>
          Updated 8 months ago
        </Typography>
      </ApiTypography>
      <ApiDivider distance="0px 0px 10px 0px" />
    </Box>
  );
};

export default Document;
