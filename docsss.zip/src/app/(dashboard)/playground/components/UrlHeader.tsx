import { PlaygroundState, addMethod, addUrl, handleClear } from '../features/playgroundSlice';
import {
  Box,
  FormControl,
  InputAdornment,
  InputLabel,
  MenuItem,
  Select,
  TextField,
  Button
} from '@mui/material';
import React from 'react';
import { useDispatch, useSelector } from 'react-redux';

const UrlHeader = ({ handleSubmit }: { handleSubmit: () => void }) => {
  const dispatch = useDispatch();
  const { method, url } = useSelector((state: PlaygroundState | any) => state.playground) || {};

  const apiMethod = [
    {
      value: 'get',
      label: 'GET'
    },
    {
      value: 'post',
      label: 'POST'
    },
    {
      value: 'put',
      label: 'PUT'
    },
    {
      value: 'del',
      label: 'DELETE'
    }
  ];

  const apiServer = [
    {
      value: 'https://jsonplaceholder.typicode.com/todos/1'
    },
    {
      value: 'https://api.cdda.com'
    },
    {
      value: 'https://api.cddb.com'
    },
    {
      value: 'https://api.cddc.com'
    },
    {
      value: 'https://api.cddd.com'
    }
  ];

  return (
    <Box
      sx={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        padding: '10px',
        gap: '10px'
      }}
    >
      <FormControl
        size="small"
        sx={{
          minWidth: '100px'
        }}
      >
        <InputLabel id="demo-simple-select-label">Method</InputLabel>
        <Select
          labelId="demo-simple-select-label"
          id="demo-simple-select"
          value={method}
          label="Method"
          onChange={(e) => {
            dispatch(addMethod(e.target.value as string));
          }}
        >
          {apiMethod.map((item) => (
            <MenuItem
              key={item.value}
              sx={{
                fontSize: '14px'
              }}
              value={item.value}
            >
              {item.label}
            </MenuItem>
          ))}
        </Select>
      </FormControl>
      <FormControl
        fullWidth
        size="small"
        sx={{
          minWidth: '100px'
        }}
      >
        <InputLabel id="demo-simple-select-label1">Server</InputLabel>
        <Select
          labelId="demo-simple-select-label1"
          id="demo-simple-select1"
          value={url}
          label="Server"
          onChange={(e) => {
            dispatch(addUrl(e.target.value));
          }}
        >
          {apiServer.map((item) => (
            <MenuItem
              key={item.value}
              sx={{
                fontSize: '14px'
              }}
              value={item.value}
            >
              {item.value}
            </MenuItem>
          ))}
        </Select>
      </FormControl>
      <Button
        onClick={handleSubmit}
        variant="contained"
        sx={{
          padding: '10px 20px'
        }}
      >
        SEND
      </Button>
      <Button
        onClick={() => {
          dispatch(handleClear());
        }}
        variant="outlined"
        sx={{
          padding: '10px 20px'
        }}
      >
        CLEAR
      </Button>
    </Box>
  );
};

export default UrlHeader;
