import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Box } from '@mui/material';
// @ts-ignore
import Editor, { useMonaco } from '@monaco-editor/react';
// @ts-ignore
import dirtyJson from 'dirty-json';
import useToggle from '@/hooks/useToogle';
import { downloadJsonFile } from './utils/file';
import { minifyJsonString, parseJsonSchemaString, prettifyJsonString } from './utils/json-string';
import ToolBar from './Toolbar';

interface JSONEditorProps {
  language: string;
  defaultValue: string;
  schemaValue?: string; // Adjust the type here based on your schema structure
  title?: string;
  path?: string;
  isSchemaSampleDataOn?: boolean;
  onChange?: (value: string) => void;
  height?: string;
}

const EditorPanel = ({
  language,
  height,
  defaultValue,
  schemaValue,
  title,
  path = '',
  isSchemaSampleDataOn,
  onChange
}: JSONEditorProps) => {
  const monaco = useMonaco();
  const [errors, setErrors] = useState<string[]>([]);
  const [isAutoPrettifyOn, toggleAutoPrettifyOn] = useToggle(false);
  const [isValidJson, setIsValidJson] = useState(false);
  const editorRef = useRef<any>(null);

  const updateEditorLayout = useCallback(() => {
    const editor = editorRef.current;
    if (!editor) return;
    editor.layout({
      width: 'auto',
      height: 'auto'
    });
    const editorEl = editor._domElement;
    if (!editorEl) return;
    const { width, height } = editorEl.getBoundingClientRect();
    editor.layout({
      width,
      height
    });
  }, []);

  const handleJsonSchemasUpdate = useCallback(() => {
    monaco?.languages.json.jsonDefaults.setDiagnosticsOptions({
      validate: true,
      schemas: schemaValue
        ? [
            {
              uri: window.location.href,
              fileMatch: ['*'],
              schema: {
                ...parseJsonSchemaString(schemaValue)
              }
            }
          ]
        : undefined
    });
  }, [schemaValue, monaco]);

  const handleEditorPrettify = useCallback(() => {
    editorRef.current?.getAction('editor.action.formatDocument')?.run();
  }, []);

  const handleEditorUpdateValue = useCallback((value: any) => {
    const editor = editorRef.current;
    if (!editor) return;
    editor.setValue(value || '');
    value && editor?.getAction('editor.action.formatDocument')?.run();
  }, []);

  const handleClearClick = () => editorRef.current?.setValue('');

  const handleEditorWillMount = () => handleJsonSchemasUpdate();

  const handleEditorDidMount = (editor: any) => {
    editorRef.current = editor;

    editor.getModel()?.updateOptions({ tabSize: 2, insertSpaces: false });
    updateEditorLayout();

    window.addEventListener('resize', () => {
      updateEditorLayout();
    });

    defaultValue && handleEditorUpdateValue(prettifyJsonString(defaultValue));
  };

  useEffect(() => {
    handleEditorUpdateValue(defaultValue);
  }, [defaultValue, handleEditorUpdateValue]);

  useEffect(() => {
    handleJsonSchemasUpdate();
  }, [schemaValue, handleJsonSchemasUpdate]);

  useEffect(() => {
    updateEditorLayout();
  }, [isSchemaSampleDataOn, updateEditorLayout]);

  useEffect(() => {
    isAutoPrettifyOn && handleEditorPrettify();
  }, [isAutoPrettifyOn, handleEditorPrettify]);

  const handleEditorValidation = useCallback((markers: any) => {
    const errorMessage = markers.map(
      ({ startLineNumber, message }: any) => `line ${startLineNumber}: ${message}`
    );
    const hasContent = editorRef.current?.getValue();
    const hasError = errorMessage.length > 0;
    setIsValidJson(!!hasContent && !hasError);
    setErrors(errorMessage);
  }, []);

  const handleMinifyClick = () => {
    const editor = editorRef.current;
    if (!editor) return;
    const value = editor.getValue();
    const minifiedValue = minifyJsonString(value);
    editor.setValue(minifiedValue);
  };

  const handleUploadClick = (file: any) => {
    const fileReader = new FileReader();
    fileReader.onload = () => {
      const result = fileReader.result;
      handleEditorUpdateValue(result);
    };
    fileReader.readAsText(file);
  };

  const handleDownloadClick = () => {
    const value = editorRef.current?.getValue();
    value && downloadJsonFile(value);
  };

  const handleEditorChange = useCallback(
    (value: any) => {
      isAutoPrettifyOn && handleEditorPrettify();
      onChange && onChange(value);
    },
    [isAutoPrettifyOn, handleEditorPrettify, onChange]
  );

  const handleFixClick = () => {
    const editor = editorRef.current;
    const value = editor && editor.getValue();
    const fixedValue = value && dirtyJson.parse(value);
    const formattedValue = fixedValue && prettifyJsonString(JSON.stringify(fixedValue));
    editor && editor.setValue(formattedValue);
  };

  return (
    <div>
      <ToolBar
        title={title}
        isValidJson={isValidJson}
        isAutoPrettifyOn={isAutoPrettifyOn}
        onAutoPrettifyChange={toggleAutoPrettifyOn}
        onClearClick={handleClearClick}
        onDownloadClick={handleDownloadClick}
        onMinifyClick={handleMinifyClick}
        onPrettifyClick={handleEditorPrettify}
        onUploadClick={handleUploadClick}
        onFixClick={handleFixClick}
      />
      <Box
        sx={{
          height: height || 'calc(100vh - 68vh)'
        }}
      >
        <Editor
          // @ts-ignore
          language={language}
          path={path}
          theme="vs-dark"
          options={{
            automaticLayout: true,
            autoClosingBrackets: 'always',
            autoClosingQuotes: 'always',
            formatOnPaste: true,
            formatOnType: true,
            scrollBeyondLastLine: true,
            wordWrap: 'on', // Enable word wrapping if needed
            minimap: {
              enabled: false // Disable minimap if not needed
            }
          }}
          onMount={handleEditorDidMount}
          onChange={handleEditorChange}
          beforeMount={handleEditorWillMount}
          onValidate={handleEditorValidation}
        />
      </Box>
    </div>
  );
};

export default EditorPanel;
