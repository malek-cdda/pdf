// ToolBar.js

import { AiOutlineCloudUpload } from 'react-icons/ai';
import { CiLineHeight } from 'react-icons/ci';
import { IoCloudDownloadOutline } from 'react-icons/io5';
import { MdOutlineAutoFixHigh } from 'react-icons/md';
import { RiDeleteBin6Line } from 'react-icons/ri';
import { SiPrettier } from 'react-icons/si';
import { useRef } from 'react';
import { Stack, Typography } from '@mui/material';

interface ToolBarProps {
  onMinifyClick: () => void;
  onPrettifyClick: () => void;
  isAutoPrettifyOn: any;
  onAutoPrettifyChange: any;
  onClearClick: () => void;
  onDownloadClick: () => void;
  onUploadClick: (file: File) => void;
  onFixClick: () => void;
  isValidJson: boolean;
  title?: string;
}

const ToolBar = ({
  onMinifyClick,
  onPrettifyClick,
  isAutoPrettifyOn,
  onAutoPrettifyChange,
  onClearClick,
  onDownloadClick,
  onUploadClick,
  onFixClick,
  isValidJson,
  title
}: ToolBarProps) => {
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files) return;
    const fileUploaded = e.target.files[0];
    onUploadClick(fileUploaded);
  };

  const fileInputRef: any = useRef(null);

  const handleUploadClick = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  return (
    <Stack direction="row" justifyContent="space-between" padding="0 0 5px 0">
      <Typography fontSize={12}>{title || 'Editor'}</Typography>
      <Stack direction="row" gap={2}>
        <AiOutlineCloudUpload
          style={{
            cursor: 'pointer'
          }}
          size={20}
          onClick={handleUploadClick}
        />
        <IoCloudDownloadOutline
          style={{
            cursor: 'pointer'
          }}
          size={18}
          onClick={onDownloadClick}
        />
        <RiDeleteBin6Line
          style={{
            cursor: 'pointer'
          }}
          size={17}
          onClick={onClearClick}
        />
        <MdOutlineAutoFixHigh
          style={{
            cursor: 'pointer'
          }}
          size={17}
          onClick={onFixClick}
        />
        <SiPrettier
          style={{
            cursor: 'pointer'
          }}
          size={15}
          onClick={onPrettifyClick}
        />
        <CiLineHeight
          style={{
            cursor: 'pointer'
          }}
          size={16}
          onClick={onMinifyClick}
        />
        <input
          id="fileInput"
          ref={fileInputRef}
          style={{ display: 'none' }}
          onChange={handleFileChange}
          type="file"
          accept="application/json"
        />
      </Stack>
    </Stack>
  );
};

export default ToolBar;
