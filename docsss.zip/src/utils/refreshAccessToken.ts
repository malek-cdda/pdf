interface RefreshResult {
  success: boolean;
  accessToken?: string;
  error?: string;
}

export async function refreshAccessToken(refreshToken: string | undefined): Promise<RefreshResult> {
  try {
    const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/auth/login`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ refresh: refreshToken })
    });

    if (!response.ok) {
      const error = await response.json();
      return { success: false, error: error.message };
    }
    const data = await response.json();
    const { access } = data;
    return { success: true, accessToken: access };
  } catch (error) {
    return { success: false, error: 'Error refreshing access token' };
  }
}
