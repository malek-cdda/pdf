// let map: google.maps.Map;
// // map return promise so we use another side is async await
// export async function mapDeclare(params: any) {
//   map = new google.maps.Map(document.getElementById('map') as HTMLElement, {
//     center: new google.maps.LatLng(params.lat, params.lng),
//     zoom: 10,
//     mapId: '15431d2b469f209dsfdsfsde',
//     disableDefaultUI: true,
//     minZoom: 2
//   });
//   let marker = (await google.maps.importLibrary('marker')) as google.maps.MarkerLibrary;
//   let { PinElement, AdvancedMarkerElement } = marker;

//   return { map, PinElement, AdvancedMarkerElement, marker };
// }

// export function customScript() {
//   const script = document.createElement('script');
//   script.src = `https://maps.googleapis.com/maps/api/js?key=${process.env.NEXT_PUBLIC_MAP_API_KEY}&libraries=places`;
//   script.async = true;
//   script.defer = true;
//   document.head.appendChild(script);
//   return script;
// }
