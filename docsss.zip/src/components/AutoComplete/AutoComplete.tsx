import { TextField } from '@mui/material';
import React, { useEffect, useState } from 'react';
// import { customScript, mapDeclare } from './map';

const AutoComplete = () => {
  // const [map, setMap] = useState<any>(null);
  // const [astor, setAstor] = useState({ lat: 40.7128, lng: -74.006 });
  // useEffect(() => {
  //   const script = customScript();
  //   script.onload = initializeMap;
  //   return () => {
  //     document.head.removeChild(script);
  //   };
  // }, []);
  // const initializeMap = async () => {
  //   const { map } = await mapDeclare(astor);
  //   setMap(map);
  // };
  return (
    <div>
      <TextField id="inputs" />
    </div>
  );
};

export default AutoComplete;
