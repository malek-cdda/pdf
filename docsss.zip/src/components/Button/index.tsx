'use client';

import withPermission from '@/hooks/withPermission';
import { Button } from '@mui/material';
import React from 'react';

const CustomButton = () => {
  return <Button variant="contained">STARTED</Button>;
};

export default withPermission(CustomButton, ['superadmin', 'manager'], 'CustomButton');

// permisstion/check?component=hgfdgfdhg
