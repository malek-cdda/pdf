import * as React from 'react';
import Button from '@mui/material/Button';
import Snackbar from '@mui/material/Snackbar';
import Alert from '@mui/material/Alert';

export default function ToastAlert({
  color = 'white',
  bgColor = 'red',
  duration = 500000000,
  message = '',
  verticalAlign = 'top',
  horizontalAlign = 'right'
}) {
  const [open, setOpen] = React.useState(true);

  const handleClose = (event?: React.SyntheticEvent | Event, reason?: string) => {
    if (reason === 'clickaway') {
      return;
    }

    setOpen(false);
  };
  const [state, setState] = React.useState<any>({
    open: false,
    vertical: verticalAlign,
    horizontal: horizontalAlign
  });
  const { vertical, horizontal } = state;
  return (
    <div>
      <Snackbar
        open={open}
        autoHideDuration={duration}
        onClose={handleClose}
        action={null}
        anchorOrigin={{ vertical, horizontal }}
      >
        <Alert
          onClose={handleClose}
          variant="filled"
          sx={{ width: '100%', color: color, background: bgColor }}
        >
          {message}
        </Alert>
      </Snackbar>
    </div>
  );
}
