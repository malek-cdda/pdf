import { Stack, Typography } from '@mui/material';
import React from 'react';

const DataNotAvailabel = () => {
  return (
    <Stack
      sx={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        height: '100%'
      }}
    >
      <Typography variant="h6" color="text.secondary">
        Data Not Available
      </Typography>
      <Typography color="text.secondary">The requested data does not Exist</Typography>
    </Stack>
  );
};

export default DataNotAvailabel;
