import {
  Collapse,
  List,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Typography,
  alpha
} from '@mui/material';
import { Key, useEffect, useState } from 'react';
import ExpandLessOutlinedIcon from '@mui/icons-material/ExpandLessOutlined';
import ExpandMoreOutlinedIcon from '@mui/icons-material/ExpandMoreOutlined';
import SidebarItem from './SidebarItem';

type Props = {
  item: any;
};

const SidebarItemCollapse = ({ item }: Props) => {
  const [open, setOpen] = useState(true);

  //   const { appState } = useSelector((state: RootState) => state.appState);

  //   useEffect(() => {
  //     if (appState.includes(item.state)) {
  //       setOpen(true);
  //     }
  //   }, [appState, item]);

  return item.sidebarProps ? (
    <>
      <ListItemButton
        onClick={() => setOpen(!open)}
        sx={{
          '&: hover': {
            backgroundColor: (theme) => alpha(theme.palette.primary.main, 0.4)
          },
          paddingY: '12px'
          // paddingX: '20px'
        }}
      >
        <ListItemIcon
          sx={{
            color: (theme: any) =>
              theme.palette.mode === 'light'
                ? alpha(theme.palette.title.light, 0.9)
                : alpha(theme.palette.title.dark, 0.9)
          }}
        >
          {item.sidebarProps.icon && item.sidebarProps.icon}
        </ListItemIcon>
        <ListItemText
          disableTypography
          primary={
            <Typography
              sx={{
                color: (theme: any) =>
                  theme.palette.mode === 'light'
                    ? alpha(theme.palette.title.light, 0.9)
                    : alpha(theme.palette.title.dark, 0.9),
                fontWeight: 600
              }}
            >
              {item.sidebarProps.displayText}
            </Typography>
          }
        />
        {open ? <ExpandLessOutlinedIcon /> : <ExpandMoreOutlinedIcon />}
      </ListItemButton>
      <Collapse in={open} timeout="auto">
        <List sx={{ ml: 2 }}>
          {item.child?.map(
            (route: { sidebarProps: any; child: any }, index: Key | null | undefined) =>
              route.sidebarProps ? (
                route.child ? (
                  <SidebarItemCollapse item={route} key={index} />
                ) : (
                  <SidebarItem item={route} key={index} />
                )
              ) : null
          )}
        </List>
      </Collapse>
    </>
  ) : null;
};

export default SidebarItemCollapse;
