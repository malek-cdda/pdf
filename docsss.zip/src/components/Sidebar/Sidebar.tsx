import { Box, List, Stack, Toolbar } from '@mui/material';
import React from 'react';
import { alpha, styled } from '@mui/material/styles';
import MuiDrawer from '@mui/material/Drawer';
import SidebarItem from './SidebarItem';
import DashboardOutlinedIcon from '@mui/icons-material/DashboardOutlined';
import ArticleOutlinedIcon from '@mui/icons-material/ArticleOutlined';
import SidebarItemCollapse from './SidebarItemCollapse';
import TripOriginIcon from '@mui/icons-material/TripOrigin';
import RemoveIcon from '@mui/icons-material/Remove';
import SettingsSuggestIcon from '@mui/icons-material/SettingsSuggest';
import CollectionsBookmarkIcon from '@mui/icons-material/CollectionsBookmark';
import { CiPlay1 } from 'react-icons/ci';

type SideBarProps = {
  open: boolean;
};

const drawerWidth: number = 240;

const Drawer = styled(MuiDrawer, { shouldForwardProp: (prop) => prop !== 'open' })(
  ({ theme, open }: any) => ({
    '& .MuiDrawer-paper': {
      position: 'relative',
      whiteSpace: 'nowrap',
      boxShadow: theme.shadows[1],
      width: drawerWidth,
      transition: theme.transitions.create('width', {
        easing: theme.transitions.easing.sharp,
        duration: theme.transitions.duration.enteringScreen
      }),
      boxSizing: 'border-box',
      backgroundColor:
        theme.palette.mode === 'light' ? theme.palette.sidebar.light : theme.palette.sidebar.dark,
      color:
        theme.palette.mode === 'light'
          ? alpha(theme.palette.title.light, 0.9)
          : alpha(theme.palette.title.dark, 0.9),
      borderRight: '1px solid rgba(173, 173, 173, 0.12)',
      ...(!open && {
        overflowX: 'hidden',
        transition: theme.transitions.create('width', {
          easing: theme.transitions.easing.sharp,
          duration: theme.transitions.duration.leavingScreen
        }),
        width: theme.spacing(7),
        [theme.breakpoints.up('sm')]: {
          width: theme.spacing(9)
        }
      })
    }
  })
);

export const appRoutes = [
  {
    // path: '/dashboard',
    sidebarProps: {
      displayText: 'Dashboard',
      icon: <DashboardOutlinedIcon />
    },
    child: [
      {
        path: '/user/mls-group',
        sidebarProps: {
          displayText: 'MLS Group',
          icon: <RemoveIcon sx={{ width: 12, height: 12 }} />
        }
      },
      {
        path: '/user/agent',
        sidebarProps: {
          displayText: 'Agent',
          icon: <RemoveIcon sx={{ width: 12, height: 12 }} />
        }
      },
      {
        path: '/user/buyer',
        sidebarProps: {
          displayText: 'Buyer',
          icon: <RemoveIcon sx={{ width: 12, height: 12 }} />
        }
      },
      {
        path: '/agreement',
        sidebarProps: {
          displayText: 'Agreement',
          icon: <RemoveIcon sx={{ width: 12, height: 12 }} />
        }
      },
      {
        path: '/invoice',
        sidebarProps: {
          displayText: 'Invoice',
          icon: <RemoveIcon sx={{ width: 12, height: 12 }} />
        }
      },
      {
        path: '/tax',
        sidebarProps: {
          displayText: 'Tax',
          icon: <RemoveIcon sx={{ width: 12, height: 12 }} />
        }
      }
    ]
  },
  {
    // path: '/system',
    sidebarProps: {
      displayText: 'System',
      icon: <SettingsSuggestIcon />
    },
    child: [
      {
        path: '/role',
        sidebarProps: {
          displayText: 'Role',
          icon: <RemoveIcon sx={{ width: 12, height: 12 }} />
        }
      },
      {
        path: '/permission',
        sidebarProps: {
          displayText: 'Permission',
          icon: <RemoveIcon sx={{ width: 12, height: 12 }} />
        }
      },
      {
        path: '/navigation',
        sidebarProps: {
          displayText: 'Navigation',
          icon: <RemoveIcon sx={{ width: 12, height: 12 }} />
        }
      },
      {
        path: '/user-list',
        sidebarProps: {
          displayText: 'User',
          icon: <RemoveIcon sx={{ width: 12, height: 12 }} />
        }
      },
      {
        path: '/template',
        sidebarProps: {
          displayText: 'Template',
          icon: <CollectionsBookmarkIcon />
        },
        child: [
          {
            path: '/template/agreement',
            sidebarProps: {
              displayText: 'Agreement',
              icon: <TripOriginIcon sx={{ width: 10, height: 10 }} />
            }
          },
          {
            path: '/template/email',
            sidebarProps: {
              displayText: 'Email',
              icon: <TripOriginIcon sx={{ width: 10, height: 10 }} />
            }
          },
          {
            path: '/template/sms',
            sidebarProps: {
              displayText: 'SMS',
              icon: <TripOriginIcon sx={{ width: 10, height: 10 }} />
            }
          },
          {
            path: '/template/invoice',
            sidebarProps: {
              displayText: 'Invoice',
              icon: <TripOriginIcon sx={{ width: 10, height: 10 }} />
            }
          }
        ]
      }
    ]
  },
  {
    path: '/subscriptions',
    sidebarProps: {
      displayText: 'Subscriptions',
      icon: <ArticleOutlinedIcon />
    }
  },
  {
    path: '/playground',
    sidebarProps: {
      displayText: 'Api Playground',
      icon: <CiPlay1 />
    }
  }
];

const Sidebar = ({ open }: SideBarProps) => {
  return (
    <Drawer variant="permanent" open={open}>
      <Toolbar
        sx={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'flex-end',
          px: [1]
        }}
      >
        {/* logo  */}
        <Stack
          component="div"
          width={'100%'}
          direction="row"
          justifyContent={'center'}
          alignItems={'center'}
          fontSize={20}
          fontWeight={'bold'}
        >
          CS Logo
        </Stack>
      </Toolbar>
      {/* <Divider /> */}
      <Box
        component={'div'}
        height={`calc(100vh - 65px)`}
        sx={{
          // height: '92vh',
          overflowY: 'auto'
          // '&::-webkit-scrollbar': { display: 'none' }
        }}
      >
        <List component="nav">
          {appRoutes.map((route, index) =>
            route.sidebarProps ? (
              route.child ? (
                <SidebarItemCollapse item={route} key={index} />
              ) : (
                <SidebarItem item={route} key={index} />
              )
            ) : null
          )}
        </List>
      </Box>
    </Drawer>
  );
};

export default Sidebar;
