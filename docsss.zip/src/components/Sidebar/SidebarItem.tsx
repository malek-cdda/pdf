import { ListItemButton, ListItemIcon, alpha } from '@mui/material';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import React from 'react';
type Props = {
  item: any;
};
const SidebarItem = ({ item }: Props) => {
  const pathName = usePathname();
  return (
    <ListItemButton
      component={Link}
      href={item.path}
      // to={item.path}
      sx={{
        backgroundColor:
          pathName === item.path
            ? (theme) =>
                theme.palette.mode === 'light'
                  ? alpha(theme.palette.common.black, 0.05)
                  : alpha(theme.palette.common.white, 0.05)
            : 'transparent',
        '&: hover': {
          backgroundColor: (theme) =>
            theme.palette.mode === 'light'
              ? alpha(theme.palette.common.black, 0.05)
              : alpha(theme.palette.common.white, 0.05)
          // alpha(theme.palette.secondary.main, 1)
          // color: (theme) => theme.palette.common.white
        },
        borderTopLeftRadius: '8px',
        borderBottomLeftRadius: '8px',
        paddingY: '8px'
      }}
    >
      <ListItemIcon
        sx={{
          justifyContent: 'center',
          alignItems: 'center',
          color: 'inherit'
        }}
      >
        {item.sidebarProps.icon ? item.sidebarProps.icon : '-'}
      </ListItemIcon>
      {item.sidebarProps.displayText}
    </ListItemButton>
  );
};

export default SidebarItem;
