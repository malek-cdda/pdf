import React, { useEffect, useState } from 'react';
import { alpha, styled } from '@mui/material/styles';
import { InputBase } from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import SearchModal from './Search/SearchModal';

const SearchBar = () => {
  const [search, setSearch] = useState(false);

  // Keyboard shortcut
  useEffect(() => {
    const kbd: any = (e: React.KeyboardEvent<HTMLDivElement>) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        setSearch(true);
      }
      if (e.key === 'Escape') {
        setSearch(false);
      }
    };

    const ignore: any = (e: React.KeyboardEvent<HTMLDivElement>) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
      }
    };

    window.addEventListener('keyup', kbd);
    window.addEventListener('keydown', ignore);

    return () => {
      window.removeEventListener('keydown', kbd);
      window.removeEventListener('keyup', ignore);
    };
  }, []);

  // Styles for the search bar component
  const Search = styled('div')(({ theme }: any) => ({
    position: 'relative',
    borderRadius: theme.shape.borderRadius,
    backgroundColor:
      theme.palette.mode === 'light'
        ? alpha(theme?.palette?.common?.black, 0.05)
        : alpha(theme?.palette?.common?.black, 1),
    marginRight: theme.spacing(2),
    color:
      theme?.palette?.mode === 'light'
        ? alpha(theme?.palette?.title?.light, 0.9)
        : alpha(theme?.palette?.title?.dark, 0.9),

    width: '100%',
    [theme.breakpoints.up('sm')]: {
      width: 'auto'
    }
  }));

  // Styles for the search icon
  const SearchIconWrapper = styled('div')(({ theme }) => ({
    padding: theme.spacing(0, 2),
    height: '100%',
    position: 'absolute',
    pointerEvents: 'none',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center'
  }));

  // Styles for the input base
  const StyledInputBase = styled(InputBase)(({ theme }) => ({
    color: 'inherit',
    '& .MuiInputBase-input': {
      padding: theme.spacing(1, 1, 1, 0),
      // vertical padding + font size from searchIcon
      paddingLeft: `calc(1em + ${theme.spacing(4)})`,
      transition: theme.transitions.create('width'),
      width: '100%',
      [theme.breakpoints.up('md')]: {
        width: '20ch'
      }
    }
  }));
  return (
    <>
      <Search>
        <SearchIconWrapper>
          <SearchIcon />
        </SearchIconWrapper>
        <StyledInputBase
          onClick={() => setSearch(true)}
          placeholder="Search…"
          inputProps={{ 'aria-label': 'search' }}
          endAdornment={
            <pre
              style={{
                padding: '0 0.8rem 0 0',
                fontSize: '0.75rem'
              }}
            >
              Ctrl+k
            </pre>
          }
        />
      </Search>
      <SearchModal open={search} setOpen={setSearch} />
    </>
  );
};

export default SearchBar;
