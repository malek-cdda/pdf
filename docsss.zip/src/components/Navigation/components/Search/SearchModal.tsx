import React, { useState, useEffect, useRef } from 'react';
import Dialog from '@mui/material/Dialog';
import DialogContent from '@mui/material/DialogContent';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';
import {
  DialogActions,
  FormControl,
  InputAdornment,
  Stack,
  TextField,
  styled
} from '@mui/material';
import Search from '@mui/icons-material/Search';
import { appRoutes } from '@/components/Sidebar/Sidebar';
import SearchItem from './SearchItem';

// Route interface
interface Route {
  path: string;
  sidebarProps: {
    displayText: string;
    icon: JSX.Element;
  };
  child?: Route[];
}

const BootstrapDialog = styled(Dialog)(({ theme }) => ({
  '& .MuiDialogContent-root': {
    padding: theme.spacing(2)
  },
  '& .MuiDialogActions-root': {
    padding: theme.spacing(1)
  }
}));

const SearchModal = ({ open, setOpen }: any) => {
  const [searchResults, setSearchResults] = useState<any[]>([]);

  // SEARCH FUNCTIONALITY
  const searchMenu = (keyword: string, routes: Route[], parentPath: string = ''): any[] => {
    const results: any[] = [];
    routes.forEach((route) => {
      if (
        route.path &&
        route.sidebarProps.displayText.toLowerCase().includes(keyword.toLowerCase())
      ) {
        results.push({
          category: parentPath || 'Top Level',
          path: route.path,
          displayText: route.sidebarProps.displayText
        });
      }

      if (route.child) {
        results.push(...searchMenu(keyword, route.child, route.sidebarProps.displayText));
      }
    });

    return results;
  };

  // HANDLE SEARCH CHANGE
  const handleSearchChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const { value } = event.target;
    if (value) {
      const results = searchMenu(value, appRoutes as any);
      setSearchResults(results);
    } else {
      setSearchResults([]);
    }
  };
  // CLOSE MODAL
  const handleClose = () => {
    setOpen(false);
  };

  return (
    <React.Fragment>
      <BootstrapDialog
        scroll="paper"
        sx={{
          '& .MuiDialog-container': {
            alignItems: 'flex-start'
          }
        }}
        fullWidth
        onClose={handleClose}
        aria-labelledby="customized-dialog-title"
        open={open}
      >
        <Stack
          direction="row"
          justifyContent="space-between"
          alignItems="center"
          p={2}
          alignContent="center"
          justifyItems={'center'}
        >
          <FormControl>
            <TextField
              autoFocus
              size="small"
              variant="outlined"
              placeholder="What are you looking for?"
              onChange={handleSearchChange}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <Search />
                  </InputAdornment>
                )
              }}
            />
          </FormControl>
          <IconButton
            aria-label="close"
            onClick={handleClose}
            sx={{
              color: (theme) => theme.palette.grey[500]
            }}
          >
            <CloseIcon />
          </IconButton>
        </Stack>

        <DialogContent dividers>
          {searchResults.length > 0 ? (
            <SearchItem results={searchResults} setOpen={setOpen} />
          ) : (
            <pre>No results found</pre>
          )}
        </DialogContent>
        <DialogActions>
          Search by <pre> Pyreactor</pre>
        </DialogActions>
      </BootstrapDialog>
    </React.Fragment>
  );
};

export default SearchModal;
