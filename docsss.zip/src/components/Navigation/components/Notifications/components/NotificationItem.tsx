import { stringAvatar } from '@/utils/avatarString';
import { Avatar, Box, Stack, Typography, alpha } from '@mui/material';
import styled from '@mui/material/styles/styled';
import React from 'react';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import Link from 'next/link';
const ItemLink = styled(Link)({
  textDecoration: 'none',
  color: 'inherit'
});
const NotificationItem = () => {
  return (
    <ItemLink href={'/'}>
      <Stack
        sx={{
          '&:hover': {
            backgroundColor: (theme) =>
              theme.palette.mode === 'light'
                ? alpha(theme.palette.common.black, 0.05)
                : alpha(theme.palette.common.white, 0.05)
          }
        }}
        p={1}
        direction={'row'}
      >
        {/* avatar */}
        <Avatar
          sx={{
            width: 30,
            height: 30,
            fontSize: 15
          }}
          {...stringAvatar('Kent Dodds')}
        />
        <Box
          sx={{
            display: 'flex',
            flexDirection: 'column',
            gap: 0.5
          }}
        >
          <Typography variant="body2">Angela Bernier </Typography>
          <Typography variant="subtitle2">
            Answerd your comment on the cash flow foreacsts graph 🔔
          </Typography>
          <Stack spacing={1} direction={'row'} alignItems={'center'} color={'subtitle.main'}>
            <AccessTimeIcon sx={{ height: 18, width: 18 }} />
            <Typography variant="subtitle2">2 min ago</Typography>
          </Stack>
        </Box>
      </Stack>
    </ItemLink>
  );
};

export default NotificationItem;
