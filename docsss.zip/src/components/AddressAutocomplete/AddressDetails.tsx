import React from 'react';
import { TextField, Typography, Grid } from '@mui/material';
import { useTheme } from '@mui/material/styles';

const AddressDetails = ({ formik }: any) => {

  return (
    <Grid container spacing={2}>
      <Grid item xs={12} sm={6}>
        <TextField
          fullWidth
          label="Street"
          name="address.street"
          value={formik.values.address?.street}
          onChange={formik.handleChange}
          error={formik.touched.address?.street && Boolean(formik.errors.address?.street)}
        />
      </Grid>
      <Grid item xs={12} sm={6}>
        <TextField
          fullWidth
          label="City"
          name="address.city"
          value={formik.values.address?.city}
          onChange={formik.handleChange}
          error={formik.touched.address?.city && Boolean(formik.errors.address?.city)}
        />
      </Grid>
      <Grid item xs={12} sm={6}>
        <TextField
          fullWidth
          label="State"
          name="address.state"
          value={formik.values.address?.state}
          onChange={formik.handleChange}
          error={formik.touched.address?.state && Boolean(formik.errors.address?.state)}
        />
      </Grid>
      <Grid item xs={12} sm={6}>
        <TextField
          fullWidth
          label="Zip Code"
          name="address.zip_code"
          value={formik.values.address?.zip_code}
          onChange={formik.handleChange}
          error={formik.touched.address?.zip_code && Boolean(formik.errors.address?.zip_code)}
        />
      </Grid>
      <Grid item xs={12} sm={6}>
        <TextField
          fullWidth
          label="Country"
          name="address.country"
          value={formik.values.address?.country}
          onChange={formik.handleChange}
          error={formik.touched.address?.country && Boolean(formik.errors.address?.country)}
        />
      </Grid>
      <Grid item xs={12} sm={6}>
        <TextField
          fullWidth
          label="Latitude"
          name="address.latitude"
          value={formik.values.address?.latitude}
          onChange={formik.handleChange}
          error={formik.touched.address?.latitude && Boolean(formik.errors.address?.latitude)}
        />
      </Grid>
      <Grid item xs={12} sm={6}>
        <TextField
          fullWidth
          label="Longitude"
          name="address.longitude"
          value={formik.values.address?.longitude}
          onChange={formik.handleChange}
          error={formik.touched.address?.longitude && Boolean(formik.errors.address?.longitude)}
        />
      </Grid>
    </Grid>
  );
};

export default AddressDetails;
