'use client';

import React from 'react';
import { buildInitialValuesAndValidationSchema } from '@/utils/valuesWithSchema';
// @ts-ignore
import { useFormik } from 'formik';
import { Button } from '@mui/material';
import * as Yup from 'yup';
import AddressAutocomplete from './AddressAutocomplete';

const Usage = () => {
  // initial address data
  const [addressData, setAddressData] = React.useState({
    street: '',
    city: '',
    state: '',
    zip_code: '',
    country: '',
    full_address: '',
    latitude: '',
    longitude: ''
  } as any);

  // Test data for rendering input fields
  const testData: any = [];

  // Build initial values and validation schema
  const { initialValues, validationSchema } = buildInitialValuesAndValidationSchema({
    fields: testData
  });
  // Define validation schema for the address object
  const addressSchema = Yup.object().shape({
    street: Yup.string().required('Street is required'),
    city: Yup.string().required('City is required'),
    state: Yup.string().required('State is required'),
    zip_code: Yup.string().required('Zip code is required'),
    country: Yup.string().required('Country is required'),
    full_address: Yup.string().required('Full address is required'),
    latitude: Yup.string().required('Latitude is required'),
    longitude: Yup.string().required('Longitude is required')
  });

  // Merge validation schemas
  const mergedSchema = validationSchema.shape({
    address: addressSchema
  });

  // Formik setup
  const formik = useFormik({
    initialValues: {
      ...initialValues,
      address: addressData
    },
    validationSchema: mergedSchema,
    onSubmit: async (values: any, { setSubmitting }: any) => {
      try {
        console.log('Formik values:', values);
      } catch (error) {
        console.log('Error occurred during fetch request:', error);
      }
      setSubmitting(false);
    },
    enableReinitialize: true
  });

  return (
    <form
      onSubmit={formik.handleSubmit}
      style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}
    >
      {/* {testData.map((item: any) => renderInputs({ item, formik }))} */}
      <AddressAutocomplete
        formik={formik}
        name="address"
        setAddressData={setAddressData}
        isDetails
      />
      <Button type="submit" variant="contained">
        Submit
      </Button>
    </form>
  );
};

export default Usage;
