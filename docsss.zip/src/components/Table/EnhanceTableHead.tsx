import TableCell from '@mui/material/TableCell';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Checkbox from '@mui/material/Checkbox';
import { headCellsProps } from './types';
const EnhanceTableHead = ({
  headCells,
  onSelectAllClick,
  rowCount,
  numSelected,
  handleSort,
  sortConfig,
  isCheckbox
}: {
  headCells: headCellsProps[];
  onSelectAllClick: any;
  rowCount: number;
  numSelected: any;
  handleSort: any;
  sortConfig: any;
  isCheckbox: boolean;
}) => {
  return (
    <TableHead>
      <TableRow>
        {isCheckbox && (
          <TableCell padding="checkbox">
            <Checkbox
              size="small"
              indeterminate={numSelected > 0 && numSelected < rowCount}
              checked={rowCount > 0 && numSelected === rowCount}
              onChange={onSelectAllClick}
              inputProps={{
                'aria-label': 'select all desserts'
              }}
              sx={{
                color: (theme: any) =>
                  theme.palette.mode === 'light'
                    ? theme?.palette?.primary?.light
                    : theme?.palette?.primary?.dark,
                '&.Mui-checked': {
                  color: (theme: any) =>
                    theme.palette.mode === 'light'
                      ? theme?.palette?.primary?.light
                      : theme?.palette?.primary?.dark
                }
              }}
            />
          </TableCell>
        )}
        {headCells.map((headCell: headCellsProps, index: number) => {
          return (
            <TableCell
              key={headCell.id}
              sx={{
                padding: '12px 9.5px',
                textAlign: headCell?.option?.align ? headCell?.option?.align : 'left',
                fontWeight: 500,
                color: (theme: any) =>
                  theme.palette.mode === 'light'
                    ? theme?.palette?.title?.light
                    : theme?.palette?.title?.dark
              }}
            >
              {headCell.label}
              {/* for sorting process this div is working  */}
              {headCell?.option?.sortable && (
                <span>
                  {' '}
                  {sortConfig[headCell?.id]?.key === headCell?.id && (
                    <span>
                      {sortConfig[headCell?.id].direction === 'asc' ? (
                        <span onClick={() => handleSort(headCell?.id)}>▲</span>
                      ) : (
                        <span onClick={() => handleSort(headCell?.id)}>▼</span>
                      )}
                    </span>
                  )}
                </span>
              )}
            </TableCell>
          );
        })}
      </TableRow>
    </TableHead>
  );
};

export default EnhanceTableHead;
