export interface headCellsProps {
  id: string;
  numeric: boolean;
  disablePadding: boolean;
  label: string;
  option?: {
    align?: string;
    sortable?: boolean;
  };
  render?: any;
  role?: string;
}
export interface rowDataProps {
  img?: string;
  id?: number;
  name?: string;
  address?: string;
  status?: string;
  join?: string;
  agent?: string;
  buyer?: string;
  role?: string;
  route?: string;
  email?: string;
  plan?: string;
  billing?: string;
  active?: string;
  type?: string;
  permission?: string | number;
}
