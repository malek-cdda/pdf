'use client';
import * as React from 'react';
import Box from '@mui/material/Box';
import Modal from '@mui/material/Modal';
import Typography from '@mui/material/Typography';

const style = {
  position: 'absolute',
  // maxHeight: 'calc(100vh - 50px)',
  overflow: 'hidden',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: 400,
  bgcolor: 'background.paper',
  border: '1px solid gray',
  borderRadius: '6px',
  boxShadow: (theme: any) => theme?.shadows[1],
  p: 4
};

export default function GlobalModal({
  open = false,
  setOpen = () => {},
  children,
  title = 'Modal'
}: any) {
  const handleClose = () => setOpen(false);
  return (
    <div>
      <Modal
        keepMounted
        open={open}
        onClose={handleClose}
        aria-labelledby="keep-mounted-modal-title"
        aria-describedby="keep-mounted-modal-description"
        disableEnforceFocus={false}
      >
        <Box sx={style}>
          <Typography id="keep-mounted-modal-title" variant="h4" component="h2">
            {title}
          </Typography>
          <Box
            sx={{
              py: 2,
              maxHeight: 'calc(100vh - 150px)',
              overflowY: 'auto',
              '&::-webkit-scrollbar': {
                width: '0'
              }
            }}
          >
            {children}
          </Box>
        </Box>
      </Modal>
    </div>
  );
}
