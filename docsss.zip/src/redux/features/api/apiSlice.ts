import { getCookie, setCookie } from '@/utils/cookies';
import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';
import type { BaseQueryFn, FetchArgs, FetchBaseQueryError } from '@reduxjs/toolkit/query';
import { refreshAccessToken } from '@/utils/refreshAccessToken';
import { Mutex } from 'async-mutex';

const mutex = new Mutex();

// Create a function to retrieve the access token synchronously
const getAccessToken = () => getCookie('access');

const baseQuery = fetchBaseQuery({
  baseUrl: process.env.NEXT_PUBLIC_API_URL,
  prepareHeaders: (headers, { getState }) => {
    // Retrieve the access token synchronously
    const token = getAccessToken();
    if (token) {
      headers.set('authorization', `Bearer ${token}`);
    }
    return headers;
  }
});

// const baseQueryWithReauth: BaseQueryFn<string | FetchArgs, unknown, FetchBaseQueryError> = async (
//   args,
//   api,
//   extraOptions
// ) => {
//   let result = await baseQuery(args, api, extraOptions);

//   console.log('Result:', result);

//   if (result.error && result.error.status === 401) {
//     console.log('Access token expired');

//     const refreshToken = getCookie('refresh');
//     if (refreshToken) {
//       const refreshResult: any = await refreshAccessToken(refreshToken);
//       if (refreshResult.success) {
//         setCookie('access', refreshResult?.accessToken, {
//           expires: new Date(Date.now() + 1000 * 60 * 15)
//         }); // 15 minutes in milliseconds
//         result = await baseQuery(args, api, extraOptions);
//       } else {
//         console.log('Error refreshing access token:', refreshResult.error);
//       }
//     }
//   }
//   return result;
// };

const baseQueryWithReauth: BaseQueryFn<string | FetchArgs, unknown, FetchBaseQueryError> = async (
  args,
  api,
  extraOptions
) => {
  await mutex.waitForUnlock();

  let result = await baseQuery(args, api, extraOptions);

  if (result.error && result.error.status === 401) {
    // Try to get a new token
    if (!mutex.isLocked()) {
      const release = await mutex.acquire();
      try {
        const refreshToken = getCookie('refresh');
        if (refreshToken) {
          const refreshResult: any = await refreshAccessToken(refreshToken);
          if (refreshResult.success) {
            setCookie('access', refreshResult?.accessToken, {
              expires: new Date(Date.now() + 1000 * 60 * 15)
            }); // 15 minutes in milliseconds
            result = await baseQuery(args, api, extraOptions);
          } else {
            console.log('Error refreshing access token:', refreshResult.error);
          }
        }
      } finally {
        release();
      }
    } else {
      // Wait until the mutex is released
      await mutex.waitForUnlock();
      result = await baseQuery(args, api, extraOptions);
    }
  }
  return result;
};

export const apiSlice = createApi({
  reducerPath: 'api',
  baseQuery: baseQueryWithReauth,
  endpoints: (build) => ({})
});
