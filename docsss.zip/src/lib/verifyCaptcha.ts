export const verifyCaptcha = async (token: string) => {
  try {
    const response = await fetch('https://www.google.com/recaptcha/api/siteverify', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      body: `secret=${process.env.RECAPTCHA_SECRET_KEY}&response=${token}`
    });

    if (!response.ok) {
      throw new Error('Failed to verify captcha');
    }

    const data = await response.json();
    return { success: data.success, error: null };
  } catch (error: any) {
    return { success: false, error: error.message };
  }
};
