export const roleForm = [
  {
    id: 'Label',
    name: 'label',
    type: 'text',
    placeholder: 'Enter label',
    label: 'Label',
    variant: 'outlined', // outlined, filled, standard
    defaultValue: '',
    validations: [
      {
        type: 'required',
        value: true,
        message: 'Email is required'
      }
      //   {
      //     type: "email",
      //     value: true,
      //     message: "Enter a valid email",
      //   },
    ]
  },
  {
    id: 'Name',
    name: 'name',
    type: 'text',
    placeholder: 'Enter name',
    label: 'Name',
    variant: 'outlined', // outlined, filled, standard
    defaultValue: '',
    validations: [
      {
        type: 'required',
        value: true,
        message: 'Email is required'
      }
      //   {
      //     type: "email",
      //     value: true,
      //     message: "Enter a valid email",
      //   },
    ]
  },
  {
    id: 'Description',
    name: 'description',
    type: 'text',
    placeholder: 'Enter description',
    label: 'Description',
    variant: 'outlined', // outlined, filled, standard
    defaultValue: '',
    validations: []
  }
];
